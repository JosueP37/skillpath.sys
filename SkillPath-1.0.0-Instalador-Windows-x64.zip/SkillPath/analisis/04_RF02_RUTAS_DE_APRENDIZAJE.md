# Incremento RF-02: rutas de aprendizaje

> Actualización del 8 de octubre: progreso, reevaluación vinculada y panel de demo implementados en `05_RF03_RF07_PANEL_Y_PROGRESO.md`. Los pendientes de este registro corresponden al cierre del 7 de octubre.

Fecha: 7 de octubre de 2026. El usuario autorizó continuar con otro RF; se eligió RF-02 por ser la continuación del diagnóstico RF-01.

## Comportamiento implementado

Al completar una evaluación o abrirla desde el historial, la interfaz solicita una ruta. El servidor utiliza el diagnóstico guardado en MongoDB, selecciona recursos de las competencias con brecha y guarda una única ruta por evaluación. Las consultas posteriores recuperan esa ruta conservando sus recursos y reglas originales.

La vista muestra actividades ordenadas, nivel, fuente, enlaces, práctica sugerida, duración estimada y explicación de selección. Si no hay brechas, no asigna formación de refuerzo. Si falta un recurso adecuado, identifica las competencias pendientes sin afirmar cobertura completa. Un error al obtener la ruta mantiene visible el diagnóstico y ofrece reintento.

## Reglas del catálogo de demostración

1. Prioridad = brecha relativa porcentual × criticidad del puesto; desempate por brecha en puntos descendente y competencia ID ascendente.
2. Criticidades de ejemplo: junior Python/SQL/HTTP = 1/1/1; intermedio = 2/2/3. Se guardan en el snapshot de la evaluación. Evaluaciones anteriores sin este campo usan 1, sin reinterpretar su perfil con datos actuales.
3. Se consideran recursos aprobados para esta demo y con nivel objetivo suficiente para el requisito del puesto. Se elige el menor objetivo suficiente, luego menor duración y finalmente recurso ID.
4. Recursos de fundamentos: entrada 0, objetivo de catálogo 70. Profundización: entrada 50, objetivo 100. Estas cifras son reglas ilustrativas de selección; no predicen la puntuación que obtendrá una persona después de leer.
5. Si la puntuación actual no alcanza el nivel de entrada, las bases se insertan antes del recurso principal. Todos los prerrequisitos deben pertenecer a la misma competencia con brecha. Se rechazan relaciones con otras competencias, recursos no aprobados, dependencias ausentes o ciclos necesarios para la ruta.
6. No se repiten actividades. La cobertura cuenta competencias con recursos asignados; no equivale a competencias aprendidas ni a brechas cerradas.

Catálogo estático en `backend/app/learning_catalog.py`: seis actividades de lectura y práctica, dos por competencia. Los materiales enlazados se revisaron en [Python Docs](https://docs.python.org/3/tutorial/), [el tutorial de SQL](https://www.postgresql.org/docs/current/tutorial-sql.html) y [MDN HTTP](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview). Los títulos de las actividades, ejercicios, duraciones y niveles son elaboración para la demo, no cursos certificados ni datos aprobados por iCloudFlex. Los enlaces de SQL son material de estudio; MongoDB sigue siendo la base de la aplicación.

## Persistencia y API

Colección `learning_paths`: UUID, evaluación de origen, fecha UTC, `schema_version=1`, versión `gap-path-1`, catálogo `learning-demo-1`, snapshot del diagnóstico y de las reglas, prioridades, recursos seleccionados con su snapshot, explicaciones, duración y competencias sin recurso. Índice único en `evaluation_id` para evitar duplicados incluso con solicitudes simultáneas.

- `POST /api/evaluations/{id}/learning-path`: crea una ruta (201) o devuelve la existente (200). No recibe puntuaciones desde el navegador.
- `GET /api/evaluations/{id}/learning-path`: consulta la ruta guardada; devuelve 404 si aún no existe.
- Estados: `ready`, `partial`, `uncovered`, `no_gaps`.

La fecha de salida se expresa con precisión de milisegundos para conservar el mismo valor antes y después de la serialización en MongoDB. La generación guarda un documento completo; no necesita transacciones entre colecciones. No se implementó regeneración ni edición de rutas anteriores.

## Verificación realizada

- 26 pruebas pytest aprobadas: las 13 previas de RF-01 y 13 adicionales de RF-02. Cubren nivel, exclusión de competencias alcanzadas, prioridad, orden de bases, ausencia de brechas, contenido faltante, recursos no aprobados, ciclos, dependencias ausentes, compatibilidad con snapshots anteriores y conservación de recursos.
- Integración con MongoDB real: cuatro solicitudes simultáneas producen una sola ruta; se recupera con una nueva conexión y se conserva aunque después cambie el catálogo en memoria. Las bases de prueba son aisladas y se eliminan solo esas bases.
- TypeScript y compilación Vite aprobados.
- Navegador Edge con Playwright: flujo RF-01/RF-02, cinco actividades esperadas, 390 minutos estimados, explicaciones, enlaces, CSV, persistencia tras recarga, fallo 503 con reintento, evaluación sin brechas y móvil de 390 px sin desbordamiento ni errores JavaScript.
- Capturas de escritorio y móvil inspeccionadas visualmente. Evidencia local en `.logs/qa/`, incluida `rf02-ui.json`.
- Se corrigieron los scripts de operación: lectura de registros vacíos, comparación de fechas por ticks y cierre del proceso hijo de Uvicorn. El apagado verificó que los tres puertos quedaran cerrados antes de reiniciar.

- Reinicio real final de MongoDB, API y frontend: se conservaron las siete evaluaciones y tres rutas de demostración, con igualdad de la ruta de referencia. Evidencia en `.logs/qa/reinicio-rf02.json`. La demo quedó disponible tras el reinicio.

Permanece una advertencia de deprecación de TestClient/HTTPX; no causó fallos.

## Guion breve de demostración

1. Abrir la demo local y elegir backend intermedio.
2. Responder incorrectamente Python y HTTP; acertar solo la tercera pregunta SQL.
3. El diagnóstico muestra SQL 50/80, brecha 30 puntos y 37,5 % relativo.
4. La ruta propone HTTP base → HTTP profundización → Python base → Python profundización → SQL profundización: cinco actividades, 6 h 30 min estimadas. SQL no requiere base porque el nivel actual ya alcanza la entrada de 50.
5. Desplegar las explicaciones, recargar y recuperar la ruta desde el historial.
6. Una evaluación con todas las respuestas correctas muestra una ruta sin actividades de refuerzo.

## Límites y próximos pasos

RF-02 está implementado para la demostración con reglas explícitas. No se entrenó un modelo de machine learning. Quedan por validar criticidades, niveles, contenidos, tiempos y pertinencia con el cliente. Faltan autenticación/RBAC, administración del catálogo, registro de progreso, reevaluación vinculada y reportes por equipo. No se publicó el sistema ni se usaron datos reales.

