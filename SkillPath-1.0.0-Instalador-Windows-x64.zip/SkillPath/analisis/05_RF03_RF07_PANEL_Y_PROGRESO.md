# Incremento RF-03 y RF-07: panel y seguimiento

Fecha: 8 de octubre de 2026, America/Lima. El usuario pidió continuar desde los Markdown, avanzar al menos dos requisitos y mejorar la presentación del software.

## Alcance implementado

**RF-03**: panel de seguimiento con evaluaciones, puntuación promedio, brechas por competencia, rutas generadas, estados de formación y avance de actividades. Incluye filtro por puesto, actualización, diagnósticos recientes, definiciones de indicadores y reintento independiente. Todos los valores se calculan en el servidor desde MongoDB; el historial de 20 evaluaciones no limita el total del panel.

**RF-07**: registro por actividad de pendiente, en curso o completada; nota de práctica, porcentaje de la ruta, tiempo pendiente estimado e historial de cambios. Reevaluación vinculada al diagnóstico previo del mismo puesto, con comparación de puntuaciones y competencias con brecha.

Ambos requisitos se implementan en el **entorno compartido de demostración**. No se ha implementado RF-06/autenticación, RBAC, asignación a personas ni separación de equipos. El panel demuestra las funciones analíticas previstas para jefatura, pero todavía no permite un piloto con resultados privados de colaboradores.

## Reglas y persistencia

- Progreso = actividades completadas / actividades asignadas × 100, redondeado a dos decimales. Sin actividades, porcentaje nulo y estado sin actividades; no se inventa un avance del 100 %.
- Estados de una ruta: pendiente si no se inició ninguna actividad; en curso si alguna está iniciada o completada; completada cuando todas las actividades asignadas están completas. Se permite volver a pendiente y el evento queda registrado.
- Marcar completada requiere una nota no vacía de hasta 1000 caracteres. La nota es una declaración de práctica, no una validación de jefatura ni un certificado.
- Lecturas de rutas antiguas sin progreso devuelven actividades pendientes. No reescriben el snapshot de la ruta ni el diagnóstico.
- Colección `learning_progress`: un documento por evaluación, índice único, versión, estado y nota por recurso, fecha UTC, contador de eventos y últimos 500 eventos.
- Actualización atómica en un solo documento: estados, versión y evento se guardan juntos. Se comprueba `expected_version`; modificaciones simultáneas reciben 409 para evitar sobrescribir otra ventana. Guardar los mismos valores no duplica eventos.
- Historial visual de los últimos 10 cambios, indicando el límite conservado de 500. La bitácora es de demostración; no identifica actores porque aún no existen sesiones.
- Completar recursos no modifica puntuaciones ni brechas. La reevaluación crea otro diagnóstico y conserva el anterior y su progreso.
- Reevaluaciones del mismo puesto conservan el ID de origen y una comparación. Solo se muestran cambios numéricos cuando coinciden versión del cuestionario, algoritmo, competencias y niveles requeridos. Si cambiaron, se conserva la relación pero se indica que no son comparables.
- Se normalizó la salida temporal de evaluaciones a milisegundos para que la creación y lectura posterior coincidan con la precisión MongoDB.
- El panel cuenta evaluaciones y actividades, **no personas únicas**. Diagnósticos repetidos cuentan por separado. El filtro incluye todo el registro local del puesto seleccionado. El tiempo corresponde a estimaciones del catálogo.

## API nueva

| Método | Ruta | Comportamiento |
| --- | --- | --- |
| GET | `/api/dashboard?profile_id=backend-junior` | Indicadores filtrados; omitir el parámetro para todos los puestos |
| GET | `/api/evaluations/{id}/progress` | Progreso y eventos; requiere una ruta guardada |
| PUT | `/api/evaluations/{id}/progress/{resource_id}` | Actualiza estado y nota, comprobando versión |

PUT recibe `status`, `note` y `expected_version`; rechaza campos adicionales, estados ajenos, versiones inválidas y actividades que no pertenecen a la ruta. POST de evaluaciones acepta `previous_evaluation_id` opcional para vincular una reevaluación.

## Presentación del software

- Inicio en Mi panel, con navegación a Evaluación e Historial.
- Barra lateral verde, tarjetas de métricas, mapa de competencias y anillo de avance.
- Mayor tamaño de texto, mejor contraste, controles etiquetados, foco visible y adaptación móvil.
- Actividades completadas distinguidas visualmente, controles de estado/práctica y confirmación de guardado.
- Comparación antes/ahora y acceso al diagnóstico anterior desde la reevaluación.
- Se mantiene CSS propio; no se instaló ECharts ni otra biblioteca de gráficos. Los indicadores visuales utilizan HTML/CSS con texto accesible.
- No se modificaron los documentos originales de la carpeta superior ni se creó una presentación PPTX; la mejora corresponde a la interfaz del software.

## Verificación realizada

- **36 pruebas pytest aprobadas**: 26 anteriores y 10 nuevas con MongoDB real, usando bases aisladas `test_skillpath_*`.
- Las pruebas nuevas verifican avance, reapertura, notas, validación, actualización simultánea (200/409), conservación del diagnóstico/ruta, nuevas conexiones, rutas sin actividades, métricas/filtros/denominadores, total mayor que el historial de 20 y comparación de reevaluaciones.
- Compilación TypeScript/Vite aprobada.
- `scripts/probar_interfaz.cjs`: RF-01/RF-02, cálculo conocido, prioridades, bases, persistencia, 503/reintento, exportación y móvil, sin errores JavaScript.
- `scripts/probar_seguimiento.cjs`: panel contra API, filtro, 503/reintento del panel y del guardado, nota obligatoria, conflicto 409 entre ventanas, recarga de avance, persistencia tras recarga, diagnóstico sin modificaciones y reevaluación de 0 a 100.
- Caso nuevo de navegador: ruta de seis actividades, tres completadas y una en curso; avance 50 %. La reevaluación vinculada conserva este progreso y muestra +100 puntos, de tres competencias con brecha a cero.
- Escritorio 1440 px y móvil 390 px sin desbordamiento horizontal ni errores JavaScript. Capturas inspeccionadas: `.logs/qa/rf03-panel-desktop.png`, `rf03-panel-movil.png`, `rf07-actividad-movil.png` y `rf07-reevaluacion.png`. Evidencia estructurada: `rf03-rf07-ui.json`.
- Se corrigió una carrera en `DETENER_DEMO.ps1`: el cierre ahora espera la salida efectiva del proceso MongoDB antes de permitir el reinicio.
- Reinicio real final verificado: las 12 evaluaciones, 8 rutas y 1 registro de progreso conservaron diagnóstico, ruta, notas, eventos, versión, comparación y métricas. Evidencia: `.logs/qa/reinicio-rf03-rf07.json`. La demo quedó ejecutándose en localhost.
- Permanece la advertencia de deprecación TestClient/HTTPX existente, sin fallos en la suite.
- Las pruebas de navegador añaden únicamente registros de ejemplo al entorno de demostración.

## Guion de demostración

1. Abrir el panel, revisar métricas y filtrar un puesto.
2. Abrir un diagnóstico con brechas y consultar la ruta.
3. Marcar una actividad en curso, luego completada con nota, y guardar.
4. Verificar porcentaje e historial; recargar y comprobar persistencia.
5. Volver al panel y revisar que las métricas reflejen el avance.
6. Reevaluar el mismo puesto, responder y comparar antes/ahora. Consultar el diagnóstico anterior para comprobar que mantiene su resultado y progreso.

## Pendientes

Autenticación/RBAC y autorización por objeto/equipo (RF-06), matriz y catálogo administrables (RF-04), validación de pertinencia (RF-05), reportes de equipo (RF-08), actores y evidencias revisadas por jefatura. El panel usa registros de demo y no acredita beneficios empresariales, pertinencia del catálogo, productividad ni cierre validado de brechas. No se publicaron servicios ni se usaron datos reales.
