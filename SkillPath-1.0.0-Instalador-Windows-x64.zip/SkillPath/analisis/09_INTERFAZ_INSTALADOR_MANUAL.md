# Interfaz, instalación portable y manual de uso

Fecha: 22 de octubre de 2026, America/Lima. Petición del usuario: revisar mejoras posibles, buscar referencias en Internet, mejorar la interfaz y facilitar la instalación en otra PC con un manual de uso.

## Referencias consultadas y adaptación

- [Dashboard de Moodle](https://docs.moodle.org/501/en/Dashboard): progreso y acceso a elementos recientes como referencia para una página de aprendizaje. SkillPath conserva sus propios datos, reglas y navegación.
- [Carbon Design System de IBM](https://www.carbondesignsystem.com/building-blocks/data-visualization/overview): visualizaciones legibles con etiquetas y valores. Se mantuvieron gráficos HTML/CSS y la biblioteca de iconos ya instalada.
- [Perfil de Microsoft Learn](https://learn.microsoft.com/en-us/training/support/learn-profile-manage): referencia de seguimiento personal del aprendizaje.
- [MongoDB 8.0 para Windows](https://www.mongodb.com/docs/v8.0/tutorial/install-mongodb-on-windows/): la guía de destino explicita Windows 11 x64; el proveedor también enumera Windows Server 2022. No se promete soporte de Windows 10 o ARM64.
- [CPython mediante NuGet](https://docs.python.org/3.12/using/windows.html#the-nuget-org-packages), [versiones Node LTS](https://nodejs.org/en/about/previous-releases) y manifiesto oficial `https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt`: fuentes de los runtimes portables.

La adaptación es una decisión de implementación dentro de la mejora autorizada. No se copió código, imágenes ni componentes de esos productos y no se añadieron dependencias frontend.

## Cambios de interfaz implementados

- Panel personal con saludo y acción «Continuar mi aprendizaje»: abre una ruta reciente pendiente/en curso o un diagnóstico cuya ruta todavía debe generarse. Usa los resultados reales del panel de la cuenta. El texto y los indicadores no atribuyen un aprendizaje validado ni confunden actividades con puntuación.
- Jerarquía visual, botones, contraste, tipografía y espaciado revisados. Identidad verde conservada; estados y barras con sus valores visibles.
- «Mi equipo»: resumen de personas, personas evaluadas, actividades y avance agregado con denominadores. Búsqueda por nombre/correo/categoría sin sensibilidad a tildes, filtro por actividades completadas (sin completadas, avance parcial o 100 %), orden por nombre o menor avance, estado sin coincidencias y restablecimiento.
- Tarjetas de personas con último diagnóstico y barra de actividades. El agregado del equipo se calcula sobre actividades, no como promedio sin ponderar de porcentajes personales.
- Navegación móvil desplegable con etiquetas completas, cierre al seleccionar una sección y con Escape. Enlace para saltar al contenido y respeto de movimiento reducido.
- «Ayuda y manual» con recorrido según rol, preguntas frecuentes y apertura/descarga del manual. También existe un acceso al manual desde la pantalla de inicio de sesión.

Archivos principales: `frontend/src/refresh.css`, `App.tsx`, `Dashboard.tsx`, `TeamPanel.tsx`, `HelpPanel.tsx` y `AuthGate.tsx`. `refresh.css` se carga después de los estilos históricos; la inspección móvil detectó y corrigió una regla antigua que colocaba el menú en horizontal.

## Instalación y operación implementadas

- `INSTALAR_Y_ABRIR.cmd`: preparación, inicio, carga idempotente de cuentas ficticias y apertura del navegador.
- Bootstrap `scripts/herramientas_windows.ps1`: herramientas existentes compatibles o Python 3.12.10 y Node 22.23.4 portables dentro de `.tools`. SHA256 fijado, firma del editor antes de ejecutar y comprobación de rutas del ZIP.
- La versión Node 22.23.4 y su SHA256 se consultaron en el manifiesto oficial el 22 de octubre. SHA256: `cbc74b5e0982c9dbb41525fd8fb5dcd32fbee237863f7829072f4639a1ce5f20`.
- Etapas de preparación, transcript de instalación, `pip check`, cachés locales, reintentos y archivos parciales. Python, Node y MongoDB no se instalan como servicios; el PATH solo cambia en el proceso.
- `-HerramientasLocales` permite forzar herramientas portables; `-CacheDir` reutiliza archivos con huella comprobada; `-RecrearEntorno` conserva el venv anterior como respaldo y crea otro. `-Comprobar` revisa sin descargar ni reinstalar.
- Protección contra reinstalación con la copia abierta y rechazo de puertos ocupados por servicios no registrados de esa carpeta. Se registra cada proceso nuevo inmediatamente y se espera salud de la API antes de abrir Vite.
- La verificación detectó una diferencia de enumeración de arrays JSON de PowerShell 5.1; se corrigió asignando el resultado de `ConvertFrom-Json` antes de iterar. Se volvió a comprobar el bloqueo en la versión real usada por los accesos.
- `ABRIR_MANUAL.cmd`, `MANUAL_DE_USO.md` y HTML autónomo con índice, capturas incrustadas e impresión desde el navegador. `scripts/generar_manual.py` genera el HTML raíz y la copia que sirve Vite. La versión HTML se puede consultar sin servicios ni conexión.
- Empaquetador actualizado con los nuevos accesos, manuales y bootstrap. Sigue excluyendo datos, sesiones, herramientas, paquetes, entornos, logs y secretos `.env`.

## Verificación realizada

- **103 pruebas del backend aprobadas** en 177,23 segundos; una advertencia de deprecación TestClient/httpx sin fallos. Evidencia: `.logs/qa/oct22-interfaz-backend-pytest.xml`.
- Build TypeScript/Vite aprobado después de los cambios; 25 paquetes npm, auditoría de instalación sin vulnerabilidades reportadas en esa ejecución.
- Navegador integrado: búsqueda con tilde, filtros, ausencia de coincidencias y limpieza, orden por avance, ficha de evolución, login de administrador/usuario, acceso del panel a la ruta real de seis actividades y ayuda desplegable.
- Pantallas móviles de 390 y 360 px: menú con etiquetas, cierre con Escape, panel personal, equipo, ayuda y reportes sin desbordamiento horizontal de la página. El reporte conserva su scroll interno de tabla. Evidencia: `.logs/qa/oct22-interfaz-ui.json` y capturas `oct22-*.png`.
- Manual visualmente inspeccionado: nueve capítulos, dos capturas cargadas y ningún destino roto en el índice. No se generó ni se verificó un PDF exportado; se incluye la opción de impresión del navegador.
- Instalación limpia en `.logs/qa/instalacion-oct22-85bb5709/SkillPath`, forzando herramientas portables. Python oficial y firma comprobados; Node 22.23.4 descargado oficialmente y verificado; pip, npm ci, build y `-Comprobar` aprobados. Se reutilizó únicamente la distribución MongoDB previamente descargada, volviendo a comprobar su SHA256. No se copiaron venv ni node_modules.
- Arranque real desde esa carpeta con ejecutables de los tres servicios dentro de la copia nueva. Login, equipo, reporte, CSV y manual HTTP aprobados. Preparación con copia activa bloqueada; puertos de otra copia rechazados; cierre mediante `DETENER_DEMO.cmd` aprobado.
- Reparación `-RecrearEntorno` verificada en la copia detenida de prueba: se creó otro entorno funcional y se conservó exactamente una carpeta adicional de respaldo del venv anterior. Evidencia: `.logs/qa/oct22-recrear-entorno-verificado.json`.
- Un ZIP de prueba con una entrada `../...` fue rechazado antes de la extracción; no se creó ningún archivo fuera del destino. Evidencia: `.logs/qa/oct22-zip-rutas-verificado.json`.
- Copia original restaurada: huellas intactas de **5 cuentas, 6 diagnósticos, 6 rutas, 3 documentos de progreso y catálogos vacíos**. La sesión de la comprobación sobrevivió y la demo quedó funcionando. Evidencia: `.logs/qa/oct22-portabilidad-verificada.json` y registro de arranque asociado.

La prueba se hizo en una carpeta nueva de esta misma PC; no se probó una segunda computadora física. La instalación inicial sigue requiriendo Internet. Los puertos, las firmas, el espacio y las políticas del equipo destinatario se deben comprobar allí.

## Alcance y siguientes mejoras propuestas

Este incremento mejora experiencia, ayuda y operación; no eleva automáticamente el 80 % funcional interno ni cierra los criterios pendientes de los RF. La siguiente ampliación funcional con mayor relación con los pendientes documentados es un editor de nuevas competencias y preguntas de RF-04, acompañado de validación del banco por el cliente. Es una propuesta posterior, no una función incorporada ni un nuevo requisito confirmado.

La autenticación, relación administrador-usuarios, cálculo, catálogos y contratos de la API se conservan. No se implementaron chatbot, IA, certificados, gestión de contraseñas, publicación por red ni un sistema de respaldos lógicos en este incremento.
