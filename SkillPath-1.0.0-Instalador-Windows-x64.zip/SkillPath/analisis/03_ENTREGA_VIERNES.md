# Primera funcionalidad para el viernes 9 de octubre de 2026

> Registro histórico del primer incremento. Estado actualizado: RF-02 en `04_RF02_RUTAS_DE_APRENDIZAJE.md`; RF-03/RF-07 en `05_RF03_RF07_PANEL_Y_PROGRESO.md`.

El usuario pidió al menos una funcionalidad implementada para esa fecha. El incremento se implementó y verificó el 7 de octubre: evaluación de competencias y cálculo de brechas, correspondiente a RF-01 del informe.

## Qué se puede demostrar

1. Abrir SkillPath y elegir un puesto objetivo entre los dos ejemplos.
2. Responder las nueve preguntas de Python, SQL y HTTP.
3. Navegar entre pasos conservando las respuestas.
4. Enviar la evaluación y ver puntuación, nivel requerido, brecha en puntos y brecha relativa.
5. Exportar el diagnóstico como CSV.
6. Recargar la página y recuperar el resultado desde el historial.

La interfaz utiliza React/TypeScript, la API FastAPI/Pydantic y el almacenamiento MongoDB real. Las respuestas no se califican en el navegador. No hay modelo entrenado ni llamadas a proveedores de IA.

## Ejemplo verificable de cálculo

Para el perfil backend intermedio, la competencia SQL requiere 80/100. Si únicamente se acierta la pregunta SQL de peso 3, de un total de 6 puntos de peso, se obtiene 50/100. La brecha es de 30 puntos y la brecha relativa de 37,5 %. Esta condición se comprobó tanto en las pruebas como en el navegador.

## Validación realizada

| Comprobación | Resultado |
| --- | --- |
| Cálculo ponderado, puntuación completa, puntuación cero y unidades de brecha | Correcto |
| Rechazo de respuestas faltantes, duplicadas, preguntas ajenas, opciones inválidas y versión antigua | Correcto |
| Cuestionario público sin claves de respuesta | Correcto |
| Inserción y consulta de evaluación en MongoDB real | Correcto |
| Consulta después de cerrar y abrir una conexión de aplicación | Correcto |
| Apagado ordenado y reinicio real de MongoDB | Se conservaron las dos evaluaciones de demostración |
| Pruebas pytest | 13 aprobadas |
| Compilación TypeScript y build Vite | Aprobados |
| Flujo completo en navegador y vuelta entre pasos | Aprobado |
| Historial después de recarga y exportación CSV | Aprobados |
| Vista móvil de 390 px y ausencia de desbordamiento horizontal | Aprobada |
| Errores JavaScript durante el flujo probado | Ninguno |

Las pruebas de integración utilizan bases aisladas y no borran la base de demostración. Las capturas se inspeccionaron en escritorio y móvil. La prueba de navegador dejó evaluaciones de ejemplo en el historial.

## Límites de esta entrega

- Banco de nueve preguntas y perfiles fijos de demostración, pendientes de validación curricular.
- No se han implementado autenticación ni RBAC. El historial es compartido dentro de la demo local y no se usa información real.
- RF-02 (rutas), seguimiento de aprendizaje y tablero de equipo todavía están pendientes.
- No se afirma que exista una mejora de productividad, pertinencia o aceptación empresarial: eso requiere un piloto y mediciones.
- MongoDB se ejecuta localmente; no hay publicación ni una cuenta de Atlas creada.

## Guion breve de presentación

«Este primer incremento implementa la evaluación paramétrica de competencias. El colaborador elige un puesto, responde preguntas técnicas y el backend calcula la puntuación ponderada. Esa puntuación se compara con el nivel requerido para identificar las competencias por fortalecer. El diagnóstico se almacena en MongoDB, conserva sus parámetros y puede recuperarse desde el historial. Los perfiles y preguntas utilizados son datos de ejemplo que deberán validarse con la organización antes del piloto. El siguiente incremento incorporará accesos por rol y catálogos configurables, seguido por la generación de rutas de aprendizaje.»
