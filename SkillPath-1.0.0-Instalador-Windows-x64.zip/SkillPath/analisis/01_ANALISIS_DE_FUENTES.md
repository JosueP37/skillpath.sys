# Análisis de la información entregada sobre SkillPath

Fecha: 7 de octubre de 2026. Este análisis distingue lo que dicen las fuentes de las decisiones técnicas propuestas. Los originales se conservan en la carpeta superior.

## Conclusión

SkillPath es una aplicación web interna para el área de TI de iCloudFlex. Su flujo principal es asignar un puesto objetivo, evaluar competencias, calcular brechas, recomendar recursos de aprendizaje y seguir el progreso. La complejidad principal está en la calidad del catálogo y las evaluaciones, la lógica de recomendación, el historial y los permisos.

La información permite iniciar un módulo de evaluación y cálculo de brechas con datos de ejemplo. Para un piloto real todavía se necesitan la matriz de competencias por puesto, el banco de preguntas validado, el catálogo de recursos y los participantes autorizados. El usuario confirmó después de la revisión inicial que MongoDB es obligatorio; esta indicación tiene prioridad sobre las menciones de PostgreSQL en los archivos. La arquitectura vigente se desarrolla en `02_ARQUITECTURA_PROPUESTA.md`.

## Fuentes revisadas

| Fuente original | Contenido útil | Observación |
| --- | --- | --- |
| `2026-1 ISC-Capstone Project Sistemas.docx` | Borrador principal, objetivos, RF-01 a RF-08, RNF, tecnologías, indicadores, gestión y estructura del informe | Mezcla contenido del proyecto con instrucciones de plantilla y resultados redactados en pasado |
| `GRUPO5_Modelo_Negocio_2026(1).docx` | Usuarios, propuesta de valor, adopción, continuidad y supuestos | El formato conserva textos de ejemplo y adaptación |
| `GRUPO5_Viabilidad 2026(1).docx` | MVP, exclusiones, metas de cobertura y pertinencia, condiciones del piloto | La decisión y las evidencias aún requieren confirmación |
| `Capstone Project - Identificación de Brechas y Rutas de Aprendizaje.pdf` | Presentación de 22 páginas que resume el informe, arquitectura y EDT ampliada | PDF de imágenes; lectura por OCR con inspección visual de páginas técnicas y diagramas |
| `Presentación Capstone Project-SkillPath(1).pdf` | Presentación de 7 páginas, problema, objetivos, alternativas de stack y criterios | PDF de imágenes; stack distinto del informe largo |
| `C_PLAN DE GESTION DE RIESGOS.xlsx` | Riesgos de datos, pertinencia, RBAC, integración, rendimiento, pruebas y despliegue | Fecha final: 4 de diciembre de 2026 |
| `PLAN_DE_INVOLUCRAMIENTO_INTERESADOS_iCloudFlex_2026 (1).xlsx` | Contraparte TI, talento, infraestructura, usuarios y equipo | El responsable funcional debe validar perfiles y reglas |
| `PRESUPUESTO DEL PROYECTO.xlsx` | React, Python/FastAPI, PostgreSQL, MongoDB Atlas y Render Free | Presenta errores de totales y fechas; no representa gasto verificado |
| `EDT.png` | EDT centrada en evaluación, rutas, BI, pruebas y puesta en producción | Diferente numeración y alcance frente a la EDT del PDF largo |
| `EDT en Miro.docx` | Enlace de invitación a Miro | Se tomó la imagen local como evidencia de EDT; no se modificó ni validó el tablero remoto |
| `Presentación sin título.pptx` | Una diapositiva sin texto útil ni imágenes incrustadas | No aporta requisitos adicionales |

Las extracciones y el OCR están en `_fuentes/`. El OCR es apoyo para la lectura y puede alterar símbolos o porcentajes. Los datos relevantes se contrastaron con el DOCX y con las páginas renderizadas.

## Alcance que coincide entre documentos

1. Acceso autenticado y permisos por rol.
2. Gestión de colaboradores, puestos y competencias requeridas.
3. Evaluación del nivel actual de competencias.
4. Cálculo de brechas entre nivel obtenido y nivel requerido.
5. Catálogo de cursos, módulos o recursos asociados a competencias.
6. Generación de rutas personalizadas para las brechas detectadas.
7. Registro del avance y de nuevas evaluaciones.
8. Panel del colaborador y tablero de seguimiento para jefatura/RRHH.
9. Reportes y registros que permitan evaluar el producto y el piloto.

La viabilidad excluye inicialmente app móvil nativa, integración automática con todas las plataformas de capacitación, evaluación automática del desempeño laboral y predicción de promociones o remuneraciones.

## Roles propuestos a partir de las fuentes

| Rol | Alcance |
| --- | --- |
| Administrador funcional / RRHH | Mantener puestos, competencias, recursos y asignaciones |
| Jefatura / supervisor TI | Consultar exclusivamente su equipo y validar rutas, progreso y pertinencia |
| Colaborador | Evaluarse y consultar exclusivamente sus resultados y aprendizaje |
| Administrador técnico | Gestionar accesos, configuración y operación; separar sus permisos del acceso irrestricto a resultados |

La distinción entre administrador funcional y técnico es una propuesta. El informe agrupa algunas de estas funciones. Ocultar menús no satisface RBAC: el backend debe comprobar rol, propietario y equipo en cada acceso.

## Requisitos e indicadores que afectan al diseño

| Referencia | Necesidad | Consecuencia para la implementación |
| --- | --- | --- |
| RF-01 | Evaluar y calcular brechas | Preguntas vinculadas a competencias, puntuación y cálculo en servidor, versiones y resultados almacenados |
| RF-02, RF-05 | Generar rutas pertinentes | Relación explícita recurso-competencia, requisitos previos y explicación de cada recomendación |
| RF-03, RF-08 | Panel y reportes coherentes | Métricas calculadas sobre registros persistentes, con filtros y denominadores visibles |
| RF-04 | Gestionar matriz por puesto | Catálogo normalizado y versiones del nivel requerido |
| RF-06, RNF-01 | Privacidad y permisos | Autenticación, autorización por objeto y separación de equipos |
| RF-07 | Registrar avance | Historial de actividades y reevaluaciones; terminar un curso no demuestra automáticamente dominio |
| RNF-02 | Dashboard en aproximadamente 3 segundos | Definir equipo, red, carga, datos, percentil y condiciones de medición antes de comprobarlo |

El informe principal plantea cobertura de al menos 90 %, pertinencia de al menos 80 %, aceptación y reducción del tiempo frente al proceso manual. La presentación corta introduce 80 % de precisión y 90 % de coincidencia/trazabilidad. Son indicadores distintos: se deben unificar y definir su referencia de validación. Un algoritmo aritmético debe coincidir exactamente con los casos esperados; eso no demuestra por sí solo la validez de la evaluación de competencias.

La población de 45 colaboradores y las 120 incidencias aparecen en el borrador. No se encontraron registros primarios que permitan corroborarlas. Deben tratarse como cifras declaradas por los autores, pendientes de evidencia, y no como datos medidos por nosotros.

## Inconsistencias que conviene corregir

| Hallazgo | Evidencia | Tratamiento propuesto |
| --- | --- | --- |
| Dos arquitecturas de backend | Tabla 8 del informe y PDF largo p. 13: NestJS + FastAPI. Presupuesto fila 12 y PDF corto p. 5: Python/FastAPI | Adoptar un backend FastAPI modular y actualizar la documentación, salvo exigencia explícita de conservar NestJS |
| Base de datos mal descrita | Tabla 8: «MongoDBL» bajo RDBMS, con descripción de JSONB; otras secciones dicen PostgreSQL | Unificar la selección final en MongoDB por requisito confirmado del usuario. Corregir descripción, modelo e indicadores, sin conservar afirmaciones sobre JSONB |
| Dos bases sin necesidad documentada | Presupuesto filas 20 y 21 | Usar MongoDB como única base inicial y retirar PostgreSQL del stack propuesto |
| Dos bibliotecas de gráficos | Tabla 8: ECharts integrado con Chart.js | Elegir ECharts para el tablero y evitar duplicar bibliotecas |
| Chatbot fuera del MVP trazado | PDF largo p. 19 lo incluye en EDT, pero no tiene RF ni criterio de aceptación | Pasarlo a una mejora pendiente de validación de alcance |
| Diagrama ajeno al proyecto | PDF largo p. 17 contiene sensores, PLC/SCADA y mantenimiento industrial | Sustituirlo por el flujo real de SkillPath en una futura edición autorizada |
| Sprint y semestre confundidos | PDF corto p. 5 dice «Sprints de 16 semanas»; informe plantea sprints de dos semanas | Mantener iteraciones de dos semanas dentro del periodo académico |
| Fechas mezcladas | XLSX presupuesto E10 = 2026-11-09 y G10 = 09/30/2026; E12 = 2026-01-10; G16 = 2026-05-12 | Normalizar fechas y confirmar calendario; algunas tareas terminan antes de iniciar según el valor almacenado |
| Totales duplicados | Presupuesto S22 = SUM(S8:S21) = 23 040 incluye cabeceras de fase y detalle | Sumar solo tareas finales: 11 520 en los valores registrados. La moneda no queda unificada: encabezados «$» frente a S/ del informe |
| Total real mal referenciado | T22 = SUM(I22:Q22), en lugar de las tareas de T | No usar el balance de 11 520 como ahorro real. Los valores «REAL» ya copian presupuestos para tareas no iniciadas |
| Dos presupuestos incompatibles | Informe: S/ 30 000. Excel: valores de detalle 11 520 | Definir una única estimación vigente y separar esfuerzo valorizado de desembolsos |
| Dos fechas de cierre | Riesgos: 4/12/2026. Presupuesto: 15/12/2026 | Usuario confirmó diciembre; queda pendiente el día final exacto |
| Herramienta de pruebas mal clasificada | Plan de calidad: Selenium como pruebas unitarias | Usar pytest para lógica/API, Vitest para componentes y Playwright para flujo de navegador |
| Métricas y referencias incompletas | «N° de defectos en producción: 5», referencias vacías, confiabilidad con umbral vacío en DOCX | Definir metas y adjuntar evidencias; no presentar resultados anticipados |
| Datos de autores inconsistentes | Algunas secciones del informe dicen Becerra; portada y matriz dicen Vargas | Unificar con los datos confirmados del equipo |

No se han corregido los archivos originales. La revisión de existencia, metodología y cifras de los antecedentes bibliográficos queda fuera de esta primera revisión técnica y continúa pendiente.

## Información pendiente del cliente

- Matriz validada: puesto, competencia, escala, nivel requerido y criticidad.
- Banco de preguntas y reglas de puntuación, con validación técnica.
- Catálogo de recursos, duración, nivel, relación con competencias y prerrequisitos.
- Identificación de validadores y tamaño real del piloto.
- Línea base del proceso manual y definición de autonomía laboral para Time-to-Productivity.
- Política de acceso, finalidad, conservación y autorización para tratar información real.
- Entorno de alojamiento y presupuesto operativo. Licencias gratuitas no significan alojamiento gratuito.
- Confirmación de si NestJS también fue exigido o si basta FastAPI. MongoDB sí es obligatorio según el usuario.

## Prioridad acordada con el usuario

El 7 de octubre de 2026, el usuario indicó que la entrega final corresponde a diciembre y que necesita al menos una funcionalidad implementada para el viernes 9 de octubre. Se prioriza RF-01: selección de puesto de ejemplo, evaluación técnica, resultados y cálculo de brechas persistido en MongoDB. Los datos iniciales serán de demostración y no se presentarán como información real de iCloudFlex. La idea de que MongoDB implica machine learning fue una suposición del usuario, no un requisito confirmado de entrenar un modelo.
