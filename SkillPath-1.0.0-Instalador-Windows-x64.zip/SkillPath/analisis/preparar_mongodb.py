"""MongoDB portable oficial, con checksum fijado y rutas relativas al proyecto."""
from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile
import hashlib
import json
import os
import shutil
from uuid import uuid4

root = Path(__file__).resolve().parents[1]
destination = root / '.tools' / 'mongodb'
destination.mkdir(parents=True, exist_ok=True)
version = '8.0.32'
url = f'https://fastdl.mongodb.org/windows/mongodb-windows-x86_64-{version}.zip'
# Huella oficial comprobada al preparar la distribución de la demo.
checksum = '5a0675fdec49b544cd5d374ad50a9a594cf5b3278b5ace658aa51cbb4df17177'
archive = destination / f'mongodb-{version}.zip'
candidates = list(destination.glob(f'*{version}/bin/mongod.exe'))
if not candidates:
    def valid(path):
        if not path.is_file():
            return False
        with path.open('rb') as source:
            return hashlib.file_digest(source, 'sha256').hexdigest() == checksum

    if archive.exists() and not valid(archive):
        archive.rename(archive.with_name(archive.name + '.invalido-' + uuid4().hex))
    cache_dir = os.getenv('SKILLPATH_DOWNLOAD_CACHE')
    if not archive.exists() and cache_dir:
        for cached in [Path(cache_dir) / archive.name, Path(cache_dir) / 'mongodb' / archive.name, Path(cache_dir) / 'downloads' / archive.name]:
            if valid(cached):
                shutil.copyfile(cached, archive)
                print('Cache MongoDB verificada.', flush=True)
                break
    if not archive.exists():
        partial = archive.with_suffix('.zip.partial')
        for attempt in range(1, 4):
            try:
                print(f'Descargando MongoDB oficial, intento {attempt}/3...', flush=True)
                with urlopen(url, timeout=60) as response, partial.open('wb') as output:
                    received = 0
                    while chunk := response.read(1024 * 1024):
                        output.write(chunk)
                        received += len(chunk)
                        if received % (64 * 1024 * 1024) == 0:
                            print(f'MongoDB: {received // (1024 * 1024)} MB descargados.', flush=True)
                if not valid(partial):
                    raise RuntimeError('La descarga no coincide con la huella SHA256 fijada.')
                partial.replace(archive)
                break
            except Exception:
                if attempt == 3:
                    raise
                print('Descarga interrumpida; se reintentara sin usar el archivo parcial.', flush=True)
    with archive.open('rb') as source:
        digest = hashlib.file_digest(source, 'sha256').hexdigest()
    if digest != checksum:
        raise RuntimeError('El ZIP no coincide con la huella oficial fijada. No se extrae ni ejecuta.')
    with ZipFile(archive) as zipped:
        for entry in zipped.infolist():
            target = (destination / entry.filename).resolve()
            if not target.is_relative_to(destination.resolve()):
                raise RuntimeError('Ruta no permitida en el archivo ZIP')
        zipped.extractall(destination)
    candidates = list(destination.glob(f'*{version}/bin/mongod.exe'))
if len(candidates) != 1:
    raise RuntimeError('No se encontró una única distribución de MongoDB compatible.')
executable = candidates[0]
metadata = {'version': version, 'source': url, 'sha256': checksum, 'executable': executable.relative_to(root).as_posix()}
(destination / 'origen.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
print(json.dumps(metadata, indent=2))
