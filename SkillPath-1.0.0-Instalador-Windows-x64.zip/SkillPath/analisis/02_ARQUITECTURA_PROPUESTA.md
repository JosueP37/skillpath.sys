# Arquitectura propuesta para SkillPath

Fecha: 7 de octubre de 2026. MongoDB es un requisito obligatorio confirmado por el usuario. Las otras tecnologías son una propuesta para el desarrollo autorizado; no consta exigencia de conservar NestJS.

## Decisión recomendada

Aplicación web con frontend React y TypeScript, API FastAPI en Python y MongoDB como única base de datos. Organizar el backend como un monolito modular: cada módulo posee su lógica y contratos, pero todos se despliegan como una única aplicación. El motor de brechas y recomendación es un módulo interno.

Esta decisión incorpora la indicación obligatoria del usuario y reduce integración, despliegues y puntos de fallo para un piloto pequeño. La [documentación de FastAPI](https://fastapi.tiangolo.com/tutorial/bigger-applications/) permite separar rutas y dependencias en módulos. La elección del monolito es nuestro criterio de diseño, no una obligación de FastAPI. MongoDB almacena datos documentales; esa elección no obliga a usar machine learning.

```mermaid
flowchart LR
    U[Colaborador, jefatura y RRHH] --> WEB[React + TypeScript]
    WEB -->|HTTPS / API REST| API[FastAPI]
    subgraph APP[Backend modular]
      API --> IAM[Identidad y permisos]
      API --> CAT[Puestos y competencias]
      API --> EVA[Evaluaciones y brechas]
      EVA --> REC[Recomendación de rutas]
      API --> PRO[Progreso y validación]
      API --> REP[Indicadores y auditoría]
    end
    APP --> DB[(MongoDB)]
    DB --> BK[Respaldo y restauración]
```

## Tecnologías

| Componente | Propuesta | Motivo |
| --- | --- | --- |
| Interfaz | React + TypeScript + Vite | Aplicación interna con formularios, navegación y resultados interactivos |
| Estilos | CSS en el primer módulo; Tailwind CSS cuando se consolide el diseño | Permite una demostración cuidada sin retrasar la lógica de negocio |
| API | Python + FastAPI + Pydantic | Validación, contratos OpenAPI y cálculo en un solo backend |
| Datos | MongoDB + PyMongo + Pydantic | Base obligatoria, driver oficial, documentos validados y evolución por versiones |
| Recomendación inicial | Reglas y puntuaciones explícitas en Python | Explicable y verificable sin dataset de entrenamiento |
| BI | Apache ECharts cuando se implemente el tablero | Una sola biblioteca para gráficos interactivos |
| Pruebas | pytest + HTTPX; Vitest; Playwright; JMeter/Lighthouse para rendimiento | Separar comprobación de lógica, API, interfaz y carga |
| Entornos | Docker Compose cuando esté disponible, variables de entorno y migraciones | Desarrollo y piloto reproducibles |
| Código y automatización | Git, GitHub y GitHub Actions | Historial, revisión y comprobaciones automáticas |

La [guía de React](https://react.dev/learn/build-a-react-app-from-scratch) describe Vite entre las opciones para una aplicación construida desde cero. Para una aplicación interna sin necesidad de posicionamiento público, una SPA es una elección razonable. No se necesitan SSR, GraphQL, Kubernetes, Redis ni microservicios en el alcance conocido.

Versiones exactas: fijar las efectivamente instaladas en los archivos de dependencias y lockfiles. Evitar copiar Node 18 del informe: figura fuera de soporte en la [tabla oficial de Node.js](https://nodejs.org/en/about/previous-releases). Para nuevos entornos se recomienda Node 24 LTS; puede utilizarse Node 22 LTS si cumple los requisitos de la versión de Vite instalada. Python 3.12 es una base inicial compatible que se verificará con las dependencias.

## Módulos y modelo de datos previsto

| Módulo | Entidades principales |
| --- | --- |
| Identidad | Usuario, rol, sesión, equipo, relación supervisor-colaborador |
| Catálogos | Puesto, competencia, versión del perfil, requisito por competencia |
| Evaluación | Versión del cuestionario, pregunta, opciones, intento, respuesta, resultado por competencia |
| Brechas | Diagnóstico ligado a la versión de puesto y evaluación |
| Recursos | Recurso formativo, competencia que cubre, nivel, duración, prerrequisitos |
| Rutas | Ruta, versión de reglas, elementos ordenados y explicación de selección |
| Progreso | Actividad, evidencia, estado y reevaluación |
| Validación | Revisión de pertinencia, encuesta de aceptación y mediciones del piloto |
| Auditoría | Evento, actor, objeto, fecha y resultado de la acción |

Relaciones importantes: un puesto exige varias competencias; una competencia puede ser cubierta por varios recursos; una evaluación produce un resultado por competencia; una ruta conserva el diagnóstico que la originó. Mantener colecciones `users`, `job_profiles`, `competencies`, `questionnaires`, `evaluations`, `learning_resources`, `learning_paths`, `progress_events` y `audit_events`. Los intentos contendrán respuestas y resultados de tamaño acotado en un mismo documento.

Un cambio de puesto, escala, cuestionario o reglas no debe reescribir resultados anteriores. Conservar versiones y snapshots de los parámetros utilizados para reconstruir cada diagnóstico. PyMongo permite insertar documentos mediante el [driver oficial](https://www.mongodb.com/docs/languages/python/pymongo-driver/current/crud/insert/). Usar validación Pydantic y validadores de colecciones, índices únicos para identidades y asociaciones, e índices según consultas reales. Las referencias entre colecciones no equivalen a claves foráneas: la aplicación debe comprobar existencia e integridad. Documentar migraciones de `schema_version`.

En el primer módulo, la inserción de una evaluación incluye respuestas, requisitos, pesos, puntuaciones y versiones en un documento. Esto evita estados parciales entre respuesta y resultado. En el piloto, las actualizaciones que abarquen documentos distintos deberán diseñarse para consistencia; si requieren transacciones, usar una topología MongoDB que las soporte. Los logs o eventos que crecen indefinidamente tendrán colecciones separadas.

El informe no debe describir MongoDB como RDBMS ni atribuirle JSONB. MongoDB Community se distribuye bajo [SSPL](https://www.mongodb.com/legal/licensing/community-edition), por lo que se debe identificar su licencia concreta en la documentación, sin agrupar todo el stack indiscriminadamente como «open source».

## Cálculo propuesto de la primera funcionalidad

Para la demostración se utilizará una escala continua de 0 a 100 basada en aciertos ponderados. Es una propuesta pendiente de validación por iCloudFlex:

```text
puntaje_competencia = 100 * suma(peso de preguntas correctas) / suma(peso de preguntas de esa competencia)
brecha_en_puntos = max(nivel_requerido - puntaje_competencia, 0)
brecha_relativa_porcentual = 100 * brecha_en_puntos / nivel_requerido
```

El nivel requerido debe ser mayor que cero. El backend valida que todas las preguntas del perfil tengan exactamente una respuesta válida. El cálculo utiliza valores sin redondear; el redondeo se aplica al resultado presentado.

Ejemplo: requerido 80/100 y obtenido 50/100 dan una brecha de 30 puntos y una brecha relativa de 37,5 %. Son unidades diferentes y deben nombrarse claramente. Competencia con puntuación suficiente: brecha cero. No existe evaluación: estado pendiente, nunca nivel cero por defecto.

La demostración debe usar preguntas de conocimientos. Un formulario de autoevaluación puede ser evidencia complementaria, pero no sustituye automáticamente el diagnóstico técnico. Un banco pequeño de ejemplo demuestra el flujo y el cálculo; no constituye un instrumento validado para medir capacidad laboral.

## Recomendación de rutas implementada para la demostración

RF-02 se implementó el 7 de octubre. La lógica está en `backend/app/recommendation.py`, el catálogo de seis actividades en `learning_catalog.py` y los endpoints en `learning_paths.py`. Guarda una única ruta por evaluación en MongoDB, con snapshots y versión de reglas. La interfaz la genera al consultar el diagnóstico. Detalle y verificaciones en `04_RF02_RUTAS_DE_APRENDIZAJE.md`.

1. Tomar solo competencias con brecha y ordenar según criticidad del puesto y magnitud de la brecha.
2. Filtrar recursos aprobados que cubran dichas competencias y se ajusten al nivel actual.
3. Incluir prerrequisitos de la misma competencia con brecha cuando el nivel actual no alcance la entrada del recurso principal, explicando su función. En esta demo se rechazan prerrequisitos de otras competencias.
4. Evitar ciclos en prerrequisitos y repeticiones de recursos.
5. Guardar la explicación, la versión de reglas y la cobertura de la ruta.
6. Si falta contenido, informar qué competencia queda sin recurso. No inventar cursos ni afirmar cobertura completa.

La viabilidad y el informe permiten comenzar con reglas y ponderaciones. El entrenamiento de modelos o un chatbot solo se justificarán con un objetivo adicional, datos adecuados y una evaluación de mejora. El sistema inicial no depende de una API de IA ni de costos por tokens.

## Seguridad y operación previstas para el piloto

- Autenticación y sesión revocable; definir integración corporativa si existe.
- Autorización en servidor por rol, propietario del registro y equipo.
- Contraseñas protegidas con un algoritmo adecuado, cookies seguras si se elige sesión web y protección CSRF en las operaciones que la requieran.
- HTTPS, validación de entradas, consultas parametrizadas y secretos fuera del repositorio.
- Registro de eventos con minimización de datos; no registrar contraseñas ni respuestas completas innecesarias en logs.
- Respaldo con restauración comprobada y acceso limitado.
- Política de conservación y autorización para datos reales antes del piloto.

Estos controles están previstos. No se consideran implementados por crear una interfaz o una API de demostración. La primera funcionalidad se ejecutará en localhost con datos de ejemplo.

## Despliegue y rendimiento

Desarrollo: frontend, API y MongoDB locales. Piloto: frontend estático, API persistente y MongoDB con autenticación y respaldo, alojados en infraestructura autorizada por la organización o un servicio con recursos adecuados. MongoDB Atlas es una opción pendiente de validar junto con sus límites y condiciones vigentes. Confirmar proveedor y costos antes de publicar.

El presupuesto menciona Render Free, pero su [documentación oficial](https://render.com/docs/free) indica suspensión de servicios por 15 minutos de inactividad. No debe prometerse respuesta inicial en tres segundos usando ese plan sin cambios. La base PostgreSQL gratuita allí también expira a los 30 días; es un problema del presupuesto previo, pero PostgreSQL ya no forma parte del stack vigente. La demo local no depende de ese hosting.

El dimensionamiento de 4 vCPU/8 GB del borrador no está respaldado por pruebas. Medir con el volumen del piloto, índices adecuados y percentil 95; documentar tanto cargas normales como arranque del servicio. Escalar a partir de evidencia.

## Orden de trabajo

1. Hasta viernes 9 de octubre: módulo de evaluación y cálculo de brechas con persistencia y demostración local.
2. Identidad/RBAC y catálogos configurables con datos validados.
3. Administración de recursos y validación de rutas; generación explicable ya implementada para la demo.
4. Registro de avance, reevaluación y tablero por rol.
5. Validación con usuarios, indicadores y preparación de despliegue.
6. Consolidación de evidencias, manuales e informe para diciembre.

La fecha exacta de cierre y la distribución en iteraciones deben reconciliarse con el cronograma vigente. No se han comprometido fechas para los incrementos posteriores.

