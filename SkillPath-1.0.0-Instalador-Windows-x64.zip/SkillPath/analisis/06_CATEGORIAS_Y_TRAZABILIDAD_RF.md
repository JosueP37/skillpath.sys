# Cuatro categorías y trazabilidad de requisitos

Fecha: 10 de octubre de 2026, America/Bogota.

## Decisión confirmada

El usuario confirmó las categorías de la captura de iCloudFlex para sustituir los perfiles de ejemplo junior/intermedio:

1. Soporte TI 24/7/365.
2. Desarrollo Web Moderno.
3. Infraestructura y Virtualización.
4. Redes y Ciberseguridad.

Son áreas de servicio, no niveles de seniority ni puestos individuales validados. Los nombres y su uso en la selección están confirmados. Las competencias, preguntas, pesos, niveles, criticidades y tiempos implementados son contenido de demostración pendiente de validación funcional.

## Matriz de demostración

| Categoría | Competencias y requisito sobre 100 | Criticidades, en el mismo orden |
| --- | --- | --- |
| Soporte TI 24/7/365 | Diagnóstico de incidencias: 80; gestión del servicio y continuidad: 75; sistemas y atención segura: 75 | 3, 2, 2 |
| Desarrollo Web Moderno | HTML, CSS y accesibilidad: 85; JavaScript y aplicaciones web: 80; APIs y protocolo HTTP: 85 | 2, 2, 3 |
| Infraestructura y Virtualización | Virtualización y recursos: 80; respaldo y recuperación: 85; disponibilidad y monitoreo: 75 | 2, 3, 2 |
| Redes y Ciberseguridad | Redes y conectividad: 80; identidad y control de acceso: 85; protección y respuesta a incidentes: 85 | 2, 3, 3 |

Cada categoría tiene nueve preguntas, tres por competencia, con pesos 1, 2 y 3. Son 12 competencias y 36 preguntas; HTTP conserva las preguntas previas. El servidor calcula la puntuación ponderada y las brechas con las reglas de RF-01.

Hay 24 actividades aplicables a las categorías actuales, dos por competencia. Las reglas de RF-02 mantienen la prioridad por brecha relativa × criticidad y las bases necesarias antes de profundizar. Una evaluación de cero puntos recibe seis actividades; una de 100 no recibe refuerzo. Las actividades contienen enlaces y prácticas de laboratorio o casos ficticios, sin requerir contratar servicios de nube.

Se consultaron las fuentes nuevas al preparar el incremento: [HTML en MDN](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content), [JavaScript en MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide), [incidencias en Microsoft Learn](https://learn.microsoft.com/en-us/azure/well-architected/operational-excellence/incident-response), [Hyper-V](https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/overview), [redes virtuales](https://learn.microsoft.com/en-us/azure/virtual-network/virtual-networks-overview) y [respuesta a incidentes en NIST](https://csrc.nist.gov/pubs/sp/800/61/r3/final).

El indicador `approved` permite usar un recurso en el algoritmo de demostración. No acredita aprobación del cliente ni pertinencia empresarial medida.

## Interfaz y conservación del historial

- Cuatro tarjetas con iconos, descripción, competencias y preguntas. Ninguna categoría se preselecciona al abrir la aplicación.
- El panel filtra por las categorías actuales y cuenta todos sus diagnósticos persistidos, sin limitarse a las últimas 20 evaluaciones del historial.
- Los perfiles anteriores se cuentan aparte y se conservan en Historial con la etiqueta «Perfil anterior»; sus resultados no se reasignan ni se recalculan.
- Las rutas y el progreso previos siguen siendo consultables. Se mantienen los recursos Python/SQL para recuperar o generar rutas de diagnósticos anteriores.
- La reevaluación se permite dentro de una categoría vigente. En perfiles retirados se deshabilita; comenzar otra categoría no produce una comparación ficticia.
- Continúan la exportación CSV del diagnóstico y el registro de avance.

## Versiones y API

`backend/app/category_catalog.json` contiene categorías, matriz y preguntas con versión `categories-demo-2`. `backend/app/learning_resources.json` contiene recursos con versión `learning-categories-2`. Son archivos de configuración, no catálogos administrables desde la aplicación.

Se conserva el contrato `/api/profiles`, `profile_id` y `profile_name`; sus perfiles activos ahora representan categorías. El catálogo público incluye competencias y cantidad de preguntas. Los resultados incluyen `category_active`; el panel incluye `archived_evaluation_count`.

Las claves de corrección permanecen en el backend. Se guarda un snapshot únicamente de las nueve preguntas de la categoría evaluada. Se rechazan respuestas de otras categorías, perfiles retirados y versiones antiguas.

## Trazabilidad de RF

| RF | Adaptación realizada | Pendiente |
| --- | --- | --- |
| RF-01: evaluación y brechas | Cuestionarios propios para las cuatro categorías, validación y snapshots | Validación funcional de la matriz y preguntas |
| RF-02: rutas | Recursos por competencia, prioridades, bases, explicación y persistencia | Catálogo real y niveles validados |
| RF-03: panel | Filtros, denominadores y privacidad por usuario/equipo en RF-06 | Validación empresarial de indicadores |
| RF-04: matriz por puesto | Matriz de demo por categoría organizada y versionada en JSON | Puestos reales y administración autenticada desde la aplicación |
| RF-05: pertinencia | Relación competencia-recurso y explicación técnica | Validación de jefatura y medición de pertinencia |
| RF-06: permisos | Login, registro con administrador, sesiones y permisos por propietario/equipo; documento 07 | Otras variantes de roles y gestión de identidades para piloto |
| RF-07: avance | Notas, estados, historial, conflicto de versiones y reevaluación dentro de la categoría | Actores identificados y revisión de evidencias por jefatura |
| RF-08: reportes | CSV individual, métricas privadas y evolución de usuarios asignados | Reportes formales de equipo y su exportación |

Se mantienen y extienden las funciones de demostración RF-01, RF-02, RF-03 y RF-07. No se declaran terminados todos los RF. Referencias: `01_ANALISIS_DE_FUENTES.md`, `04_RF02_RUTAS_DE_APRENDIZAJE.md` y `05_RF03_RF07_PANEL_Y_PROGRESO.md`.

## Verificación realizada

- 36 pruebas existentes aprobadas después de adaptar sus datos al nuevo catálogo.
- 11 pruebas nuevas aprobadas con MongoDB real y bases aisladas: cuatro flujos completos, preguntas cruzadas, versión antigua y conservación del formato anterior.
- Compilación TypeScript/Vite aprobada.
- `scripts/probar_interfaz.cjs`: cálculo ponderado conocido, ruta web de cinco actividades/390 minutos, navegación, persistencia, CSV, reintento 503, caso sin brechas y móvil.
- `scripts/probar_seguimiento.cjs`: filtros, métricas, notas, 503, conflicto 409, recarga y reevaluación de 0 a 100 conservando el progreso. Se ajustaron esperas para comprobar el estado tras la respuesta y su representación.
- `scripts/probar_categorias.cjs`: cuatro tarjetas sin preselección; nueve preguntas propias, tres brechas y seis actividades por categoría; avance 16,67 %, filtros, historial y perfil anterior legible sin reevaluación.
- Capturas de escritorio y móvil inspeccionadas. Sin desbordamiento horizontal en 390 px ni errores JavaScript en los recorridos.
- Huellas SHA256 verificaron la conservación exacta de los documentos anteriores: 15 evaluaciones, 11 rutas y un registro de progreso.
- Reinicio real final aprobado: 25 evaluaciones, 21 rutas y siete registros de progreso conservaron sus huellas. La API recuperó diagnósticos, rutas y avance 16,67 % de las cuatro categorías; salud `ok`. La demo quedó ejecutándose.

Las pruebas de navegador añaden registros ficticios a la demo. Evidencias actuales en `.logs/qa/categorias-ui.json`, `rf02-ui.json`, `rf03-rf07-ui.json`, `categorias-desktop.png`, `categorias-movil.png` y `categorias-datos-anteriores-verificado.json` y `categorias-reinicio-verificado.json`. `scripts/verificar_categorias_reinicio.py` compara huellas sin modificar MongoDB.

## Siguiente trabajo

RF-06 incorpora acceso privado y equipos; detalle en `07_RF06_LOGIN_Y_EQUIPOS.md`. Ahora corresponde la administración de matriz/puestos de RF-04 y los reportes de equipo de RF-08. El cliente debe validar el contenido específico de sus cuatro áreas.

El comportamiento histórico descrito corresponde al incremento previo al login. Desde RF-06, los anónimos permanecen intactos en MongoDB fuera del historial autenticado; los registros con propietario conocido conservan acceso autorizado.

## Estado vigente al 19 de octubre

La tabla anterior describe incrementos previos. Se incorporaron puestos administrables dentro de las cuatro categorías, asociación de competencias/niveles, catálogo de recursos y reportes de equipo exportables. La numeración se corrigió contra la fuente: RF-05 asocia recursos; RF-06 es panel privado. Ver ../AVANCE_REQUISITOS.md y 08_CATALOGOS_REPORTES_INSTALACION.md para el estado actual y pendientes.
