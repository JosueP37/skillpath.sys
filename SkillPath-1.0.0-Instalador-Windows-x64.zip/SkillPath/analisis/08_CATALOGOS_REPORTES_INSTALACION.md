# Incremento: puestos, recursos, reportes e instalación

Fecha: 19 de octubre de 2026. Responde a la petición de continuar con los RF, alcanzar al menos 70 % y dejar instalación en otra máquina.

## Alcance decidido para la implementación

Se mantienen las cuatro categorías confirmadas. Los nuevos puestos son registros dentro de una categoría, no nuevas categorías. Un puesto asocia entre una y tres de las competencias existentes de su categoría, con nivel requerido 1–100 y criticidad 1–5.

Los catálogos de puestos y recursos son comunes a la organización y los mantienen los administradores. Es una decisión técnica de este incremento, no un requisito adicional atribuido al cliente. Las evaluaciones, actividades e informes continúan restringidos al propietario o equipo asignado. Un administrador no modifica el avance por su usuario.

## RF-04: puestos y matriz

- Colección `job_profiles`, identificador UUID, nombre único normalizado por categoría, descripción, estado, asociación de competencias, revisión y autor.
- Alta/consulta/edición y retiro lógico desde «Puestos». Historial de hasta 100 configuraciones por registro. Sin eliminación física de resultados.
- Actualización atómica por revisión esperada; una ventana obsoleta recibe 409. Se rechaza asociación cruzada, repetida o sin competencias y valores fuera de rango.
- El usuario elige categoría y opcionalmente un puesto activo; si no lo elige conserva el diagnóstico general.
- El backend deriva un catálogo por solicitud para ese puesto. Se aplican solo sus preguntas y niveles; no se modifica el catálogo global en memoria.
- Evaluación conserva puesto, revisión, requisitos, preguntas y claves. Una edición invalida cuestionarios antiguos para nuevas entregas y no reescribe diagnósticos/rutas anteriores.
- La reevaluación debe usar la misma categoría y puesto. Versiones distintas quedan marcadas como no comparables. Las series de evolución también incluyen puesto e instrumento.

No se incorporó todavía un editor de altas de competencias/banco de preguntas: se utilizan las 12 competencias y 36 preguntas existentes. No presentar RF-04 como catálogo libre sin esta limitación.

## RF-05: recursos

- Catálogo inicial copiado de forma idempotente a `resource_catalog`, documento único con revisión y lista de recursos, máximo 200.
- Alta/consulta/edición y retiro (`approved=false`, mostrado como «Disponible para rutas» en UI). Ese indicador no significa validación del cliente.
- Se validan competencia, tiempo, niveles, enlaces HTTP/HTTPS sin credenciales, prerrequisitos existentes de la misma competencia, niveles de entrada y ausencia de ciclos.
- Motivo y autor quedan en un historial de hasta 100 cambios con snapshot del recurso. Control atómico de revisión/409.
- Al generar una ruta nueva se usa la versión persistida del catálogo. Rutas existentes conservan sus snapshots y progreso, incluso si se cambia o retira un recurso.

Las competencias históricas Python/SQL y sus recursos se conservan para diagnósticos previos con propietario. Los enlaces no se rastrean automáticamente para certificar disponibilidad o calidad.

## RF-08: reportes

- JSON y CSV privados del equipo del administrador; filtros por persona, categoría y fechas.
- Una fila por persona/instrumento comparable. Cuenta todos los diagnósticos del filtro, no solo los 20 del historial.
- Último diagnóstico de cada serie: puntuación, competencias con brecha, detalle de brechas y alcanzadas; inicial/actual solo dentro del mismo instrumento.
- Rutas y avance suman actividades de los diagnósticos filtrados; el porcentaje sin actividades es nulo. Personas sin evaluación se muestran sin puntuación, no como cero.
- Fechas incluyen días completos en UTC-05:00; se filtra la fecha del diagnóstico. El progreso mostrado es el estado actual de esas rutas.
- CSV UTF-8 con BOM, separador `;`, filtros/fecha de generación y neutralización de textos que podrían convertirse en fórmulas en Excel.
- Se consulta exclusivamente el equipo actual; filtros por terceros devuelven 404. Usuarios colaboradores no acceden al reporte de equipo.

## API nueva

| Método/ruta | Operación |
| --- | --- |
| GET/POST `/api/job-profiles` | Consultar activos / registrar como administrador |
| GET/PUT `/api/job-profiles/{id}` | Detalle / editar o retirar con revisión esperada |
| GET `/api/profiles/{id}/assessment?job_profile_id=...` | Cuestionario según puesto activo de la categoría |
| GET/POST `/api/admin/resources` | Catálogo / alta de recurso |
| PUT `/api/admin/resources/{id}` | Actualización con revisión esperada y motivo |
| GET `/api/reports/team` | Reporte JSON autorizado |
| GET `/api/reports/team.csv` | Exportación con los mismos filtros |

Las escrituras requieren cookie de sesión y CSRF. Los catálogos no exponen claves de corrección al colaborador.

## Numeración de requisitos

Contraste con fuente: RF-04 = puestos, competencias y niveles; RF-05 = asociar recursos; RF-06 = panel privado; RF-08 = reportes. La documentación anterior usaba RF-06 como abreviatura del incremento de login y RF-05 como pertinencia: se corrigió la trazabilidad vigente sin modificar los originales. Login/RBAC son controles transversales de RNF-01.

## Instalación y portabilidad

`PREPARAR_EQUIPO.ps1` prepara Python 3.12, dependencias, `npm ci`, build y MongoDB portable. `-Comprobar` revisa requisitos sin reinstalar. `-PythonExe` resuelve instalaciones donde el lanzador apunta a un Python eliminado. No modifica políticas permanentes de PowerShell.

MongoDB usa metadata relativa; el iniciador busca su ejecutable dentro del proyecto y ya no depende de una ruta D: de esta PC. Se comprueba Python antes de iniciar. Scripts con BOM para PowerShell 5.1.

`scripts/empaquetar_proyecto.py` genera `entrega/SkillPath-codigo.zip`, SHA256 y manifiesto. Incluye fuentes y manuales; excluye `.env`, entornos, paquetes, logs, herramientas y datos. La guía explica instalación nueva y copia separada de datos con MongoDB detenido/misma versión.

Se reparó el venv local mediante la instalación Python 3.12.7 disponible: apuntaba a una instalación Microsoft Store no disponible. No se modificaron los documentos fuente del cliente.

## Verificación

75 pruebas previas y 28 nuevas aprobadas con bases MongoDB aisladas. Nuevas pruebas cubren matriz, asociación, nombres duplicados, versiones, retiro, concurrencia, recursos inválidos, snapshots, persistencia, reporte/CSV, permisos, fechas y fórmulas.

Build TypeScript/Vite aprobado. Edge sobre una base aislada: reporte Ana 2 usuarios / Luis 1; CSV sin terceros; puesto de dos competencias y seis preguntas; edición de requisito 90 → 95 conservando diagnóstico anterior en 90; recursos creados/retirados; restricciones del usuario; escritorio/móvil sin errores JavaScript ni desbordamiento de página. Capturas inspeccionadas.

Evidencia UI: `.logs/qa/oct19-catalogos-reportes-ui.json` y capturas `oct19-*.png`.

Conservación de datos, reinicio e instalación: Instalación limpia y arranque real desde carpeta reubicada aprobados en esta misma PC; no una segunda PC física. Demo original reiniciada, sesión conservada y huellas intactas de 5 cuentas, 33 diagnósticos, 29 rutas y 10 documentos de avance. Evidencia: .logs/qa/oct19-instalacion-verificada.json y oct19-arranque-reubicado-verificado.json.

## Avance y pendientes

El 80 % corresponde a 32/40 criterios internos del MVP, detallados en `AVANCE_REQUISITOS.md`; no certifica aceptación del cliente ni preparación de producción. Persisten validación empresarial/piloto, nuevas competencias/preguntas administrables, aceptación/rendimiento, evidencias de formación, gestión de identidades y operación segura.
