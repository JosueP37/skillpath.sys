# RF-06: login y equipos

Fecha: 10 de octubre de 2026, America/Bogota.

## Decisiones confirmadas

El usuario confirmó una relación 1:N: un administrador puede tener muchos usuarios y cada usuario debe escoger un administrador existente y activo al registrarse. Sin responsable no se crea la cuenta. El administrador consulta el historial y la mejora de sus usuarios. Se solicitaron dos administradores y tres usuarios ficticios.

El rol `admin` representa al responsable del equipo solicitado. La separación previa entre supervisor y administradores funcional/técnico era una propuesta; esas variantes no se implementaron en este incremento.

## Implementación

- `users`: correo normalizado y único, nombre, rol, estado activo, hash Argon2id y administrador obligatorio para rol usuario. No hay registro público de administradores ni se aceptan roles/identidades extra en el registro.
- `sessions`: token aleatorio de 256 bits; MongoDB almacena su huella SHA256, usuario y caducidad. Cookie HttpOnly, SameSite=Lax, ruta `/api`, ocho horas. Logout revoca la sesión y elimina la cookie. Caducidad comprobada incluso antes del TTL.
- Escrituras autenticadas requieren `X-CSRF-Token` y se comprueba el origen cuando existe. El frontend guarda CSRF en memoria y lo recupera mediante `/auth/me`, sin tokens en localStorage.
- Cinco intentos fallidos por correo/IP bloquean el login durante la ventana de diez minutos. Errores de credenciales genéricos.
- El servidor comprueba propietario/equipo en historial, resultado, ruta, progreso, panel y reevaluación. El usuario consulta y modifica únicamente sus registros.
- El administrador consulta únicamente usuarios actualmente asignados y activos. Puede generar/recuperar la ruta derivada e inmutable de un diagnóstico autorizado, pero no registrar evaluaciones ni cambiar el avance del usuario.
- Nuevas evaluaciones incluyen propietario y administrador derivados de la sesión. Eventos de progreso guardan autor. Se mantienen snapshots, cálculo, reglas, control de versiones y conflictos 409.
- Historial paginado en bloques de veinte; panel y evolución consideran todos los registros autorizados.

Argon2id usa memoria 19 MiB, dos iteraciones y paralelismo uno: [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html) y [argon2-cffi](https://argon2-cffi.readthedocs.io/en/stable/api.html). Son decisiones técnicas de implementación, no requisitos nuevos atribuidos al cliente.

## Seguimiento

«Mi equipo» muestra personas asignadas, número de evaluaciones, última categoría/puntuación y porcentaje de actividades. Al abrir una persona muestra historial, cada puntuación y comparación inicial/actual por competencia.

Las series se separan por categoría, versión del cuestionario, algoritmo y requisitos de competencias. Una sola evaluación tiene delta nulo; las variaciones pueden ser positivas, negativas o cero. No se comparan instrumentos diferentes.

El avance formativo agrega las actividades de todas las rutas de la persona. Sin actividades, el porcentaje no aplica. La formación es declarada y no cambia la puntuación: la mejora se observa con otro diagnóstico, sin demostrar por sí sola rendimiento laboral.

## Ejemplos

| Persona | Correo | Rol | Responsable |
| --- | --- | --- | --- |
| Ana Torres | ana.admin@skillpath.test | Administrador | — |
| Luis Medina | luis.admin@skillpath.test | Administrador | — |
| Carla Ruiz | carla@skillpath.test | Usuario | Ana Torres |
| Diego Pérez | diego@skillpath.test | Usuario | Ana Torres |
| Lucía Gómez | lucia@skillpath.test | Usuario | Luis Medina |

Clave de administradores: `AdminDemo!2026`. Clave de usuarios: `UsuarioDemo!2026`. Cuentas ficticias para esta demo local.

Dos diagnósticos por usuario, calculados con los pesos actuales: Carla, Desarrollo Web, 0 → 100; Diego, Soporte TI, 16,67 → 66,67; Lucía, Infraestructura, 33,33 → 83,33. Rutas y notas de práctica ficticias. La carga `scripts/crear_usuarios_demo.py` es idempotente, conserva los datos y no restablece contraseñas. Correos ajenos al seed o cuentas modificadas en rol/estado/responsable detienen la carga sin sobrescribirse.

## Datos anteriores

Los registros anónimos anteriores se conservan exactamente en MongoDB. Sin evidencia de propietario no se adjudican a las cuentas nuevas ni se exponen en sus historiales. Un diagnóstico antiguo con propietario conocido sí permanece consultable con sus snapshots y permisos.

Conservación SHA256 comprobada de 27 diagnósticos, 23 rutas y 7 documentos de progreso anteriores. Evidencia: `.logs/qa/login-anteriores-verificado.json`.

## API

| Ruta | Acceso |
| --- | --- |
| GET `/api/auth/administrators` | Público; solo nombre e identificador |
| POST `/api/auth/register` | Público; exclusivamente usuario con administrador activo |
| POST `/api/auth/login` | Público; credenciales y sesión |
| GET `/api/auth/me` | Identidad y CSRF de sesión |
| POST `/api/auth/logout` | Sesión y CSRF; revocación |
| GET `/api/team` | Administrador; lista asignada |
| GET `/api/team/{user_id}` | Administrador; resumen y evolución de su usuario |
| GET `/api/evaluations` | Alcance propio/equipo; filtros `user_id`, `offset`, `limit` |
| GET `/api/dashboard` | Alcance propio/equipo; filtros `profile_id`, `user_id` |

Las rutas existentes de categorías, cuestionarios, resultados, aprendizaje y progreso requieren sesión. Fuera de alcance: 404; operación prohibida por rol: 403; sesión ausente/vencida: 401.

## Evidencia

Suite de backend: 75 pruebas aprobadas: suite completa de 74 y una prueba adicional de categoría inválida; además, se repitió satisfactoriamente la prueba de CSRF/caducidad/revocación con cabecera no ASCII. Las 47 pruebas previas se conservan usando login real. Advertencia de deprecación de TestClient/httpx sin fallos.

Build TypeScript/Vite aprobado. Edge/Playwright aprobó login, registro real con responsable, persistencia de sesión al recargar, cierre, equipos 2/1, diagnóstico ajeno rechazado, administrador sin editor de actividades, cuatro cuestionarios/rutas, avance, reevaluación 0 → 100 con progreso anterior conservado y CSV. Escritorio/móvil sin desbordamiento ni errores JavaScript; capturas inspeccionadas.

`scripts/probar_login_equipos.py` crea una base `test_skillpath_ui_<uuid>` y backend temporal en puerto 8001. Registra un cuarto usuario únicamente en esa base y la elimina al finalizar. La demo conserva las cinco cuentas solicitadas. Evidencia: `.logs/qa/login-equipos-ui.json` y capturas `login-`, `registro-`, `equipo-`, `evolucion-`.

Reinicio final: aprobado con MongoDB y los tres procesos reiniciados: 5 cuentas, 33 diagnósticos, 29 rutas y 10 documentos de progreso conservados exactamente. Tres sesiones sobrevivieron al reinicio; equipos 2/1 e historiales 4/2/2 comprobados. Demo ejecutándose. Evidencia en .logs/qa/login-reinicio-verificado.json.

## RF y pendientes

RF-01/RF-02 conservan diagnóstico y rutas con propietario; RF-03 incorpora privacidad; RF-06 incorpora login, sesiones, roles y autorización por objeto; RF-07 registra autor y mantiene conflictos. RF-08 incorpora consulta de evolución de usuarios, pero falta reporte formal y exportación de equipo. RF-04 sigue pendiente de administración de catálogos; RF-05 requiere validación empresarial.

Pendientes para piloto: recuperación/cambio de contraseñas; gestión de altas/bajas/reasignaciones de administradores desde la aplicación; otras variantes de roles si se confirman; contenido validado; HTTPS, MongoDB autenticado, respaldos y alojamiento autorizado. `SESSION_COOKIE_SECURE=false` corresponde a HTTP local; HTTPS debe usar `true` y configurar orígenes. No se publicó el sistema.

Prueba adicional de cierre de sesión ya revocada en la interfaz: volvió al login y limpió la pantalla anterior sin errores JavaScript. Evidencia: .logs/qa/login-sesion-vencida-ui.json.

## Actualización del 19 de octubre

Este documento conserva el nombre del incremento de login. Según la tabla original, RF-06 corresponde al panel privado del colaborador; la autenticación/permisos son controles transversales de RNF-01. Puestos, recursos y reportes CSV ya se incorporaron; detalle en 08_CATALOGOS_REPORTES_INSTALACION.md y matriz vigente ../AVANCE_REQUISITOS.md.
