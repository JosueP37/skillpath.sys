import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  const { SKILLPATH_API_PORT = '8000' } = loadEnv(mode, '.', 'SKILLPATH_API_PORT')
  return {
    plugins: [react()],
    server: {
      host: '127.0.0.1', port: 5173, strictPort: true,
      proxy: { '/api': 'http://127.0.0.1:' + SKILLPATH_API_PORT },
    },
  }
})
