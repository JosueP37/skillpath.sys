import { useEffect, useState, type FormEvent } from 'react'
import { BookOpen, LoaderCircle, Plus, Save } from 'lucide-react'
import { api, type BankCompetency, type ResourceCatalog, type ManagedResource } from './api'

export default function ResourceManager() {
  const [data, setData] = useState<ResourceCatalog | null>(null)
  const [bank, setBank] = useState<BankCompetency[]>([])
  const [form, setForm] = useState<ManagedResource | null>(null)
  const [originalId, setOriginalId] = useState('')
  const [filter, setFilter] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [retry, setRetry] = useState(0)
  const competencies = [...bank, { id: 'python', name: 'Python (histórico)' }, { id: 'sql', name: 'SQL (histórico)' }]
  useEffect(() => {
    let active = true
    setError('')
    Promise.all([api.resources(), api.competencyBank()])
      .then(([catalog, competencyBank]) => { if (active) { setData(catalog); setBank(competencyBank.competencies) } })
      .catch(reason => { if (active) setError(reason.message) })
    return () => { active = false }
  }, [retry])
  function start(resource?: ManagedResource) {
    setOriginalId(resource?.id ?? ''); setNote(''); setError(''); setNotice('')
    setForm(resource ? structuredClone(resource) : { id: 'recurso-' + crypto.randomUUID().slice(0, 8), competency_id: filter || competencies[0]?.id || 'web', title: '', provider: '', level: 'Fundamentos', estimated_minutes: 60, entry_score: 0, target_score: 100, prerequisite_ids: [], approved: true, links: [{ label: 'Abrir recurso', url: '' }], practice: '' })
  }
  async function save(event: FormEvent) {
    event.preventDefault()
    if (!form || !data) return
    setBusy(true); setError('')
    try { setData(await api.saveResource(form, data.revision, note, originalId)); setForm(null); setNotice('Recurso guardado. Las rutas ya asignadas conservan su contenido original.') }
    catch (reason) { setError((reason as Error).message) }
    finally { setBusy(false) }
  }
  const resources = data?.resources.filter(row => !filter || row.competency_id === filter) ?? []
  return <section>
    <div className="page-heading"><div><span className="eyebrow">RECURSOS Y COMPETENCIAS · RF-05</span><h1>Contenido para cada brecha.</h1><p>Registra recursos, sus competencias, niveles y prerrequisitos.</p></div><button className="primary" disabled={!data || busy} onClick={() => start()}><Plus size={17} /> Nuevo recurso</button></div>
    <p className="catalog-info">Catálogo común. La disponibilidad permite utilizar un recurso en futuras rutas; su pertinencia empresarial todavía debe validarse con iCloudFlex.</p>
    {error && <div className="path-error" role="alert"><p>{error}</p><button className="text-button" disabled={busy} onClick={() => { setForm(null); setRetry(value => value + 1) }}>Recargar recursos</button></div>}
    {notice && <p className="save-notice" role="status">{notice}</p>}
    {form && <form className="catalog-form" onSubmit={event => void save(event)}>
      <div className="section-heading"><h2>{originalId ? 'Editar recurso' : 'Registrar recurso'}</h2><button type="button" className="text-button" disabled={busy} onClick={() => setForm(null)}>Cancelar</button></div>
      <div className="catalog-fields">
        <label>Título<input name="resource-title" value={form.title} required minLength={3} maxLength={160} disabled={busy} onChange={event => setForm({ ...form, title: event.target.value })} /></label>
        <label>Competencia<select name="resource-competency" value={form.competency_id} disabled={busy || !!originalId} onChange={event => setForm({ ...form, competency_id: event.target.value, prerequisite_ids: [] })}>{competencies.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label>Proveedor<input value={form.provider} required minLength={2} maxLength={100} disabled={busy} onChange={event => setForm({ ...form, provider: event.target.value })} /></label>
        <label>Nivel del recurso<input value={form.level} required minLength={2} maxLength={60} disabled={busy} onChange={event => setForm({ ...form, level: event.target.value })} /></label>
        <label>Duración estimada (minutos)<input type="number" min="1" max="10080" value={form.estimated_minutes} disabled={busy} required onChange={event => setForm({ ...form, estimated_minutes: Number(event.target.value) })} /></label>
        <label>Nivel de entrada (0–99)<input type="number" min="0" max="99" value={form.entry_score} disabled={busy} required onChange={event => setForm({ ...form, entry_score: Number(event.target.value) })} /></label>
        <label>Nivel objetivo (1–100)<input type="number" min="1" max="100" value={form.target_score} disabled={busy} required onChange={event => setForm({ ...form, target_score: Number(event.target.value) })} /></label>
        <label>Identificador<input value={form.id} disabled={busy || !!originalId} pattern="[a-z0-9][a-z0-9-]{1,49}" required onChange={event => setForm({ ...form, id: event.target.value })} /></label>
        <label className="wide-field">Práctica propuesta<textarea name="resource-practice" value={form.practice} rows={3} minLength={5} maxLength={2000} required disabled={busy} onChange={event => setForm({ ...form, practice: event.target.value })} /></label>
      </div>
      <fieldset className="resource-links"><legend>Enlaces de aprendizaje</legend>{form.links.map((link, index) => <div className="resource-link-row" key={index}><label>Etiqueta<input value={link.label} maxLength={100} required disabled={busy} onChange={event => setForm({ ...form, links: form.links.map((row, i) => i === index ? { ...row, label: event.target.value } : row) })} /></label><label>URL HTTP/HTTPS<input type="url" value={link.url} maxLength={2000} required disabled={busy} onChange={event => setForm({ ...form, links: form.links.map((row, i) => i === index ? { ...row, url: event.target.value } : row) })} /></label>{form.links.length > 1 && <button type="button" className="text-button" disabled={busy} onClick={() => setForm({ ...form, links: form.links.filter((_, i) => i !== index) })}>Quitar enlace</button>}</div>)}<button type="button" className="text-button" disabled={busy || form.links.length >= 6} onClick={() => setForm({ ...form, links: [...form.links, { label: '', url: '' }] })}>Añadir enlace</button></fieldset>
      <fieldset className="resource-prerequisites"><legend>Prerrequisitos de la misma competencia</legend>{data?.resources.filter(row => row.competency_id === form.competency_id && row.id !== form.id).map(row => <label className="catalog-checkbox" key={row.id}><input type="checkbox" disabled={busy} checked={form.prerequisite_ids.includes(row.id)} onChange={event => setForm({ ...form, prerequisite_ids: event.target.checked ? [...form.prerequisite_ids, row.id] : form.prerequisite_ids.filter(id => id !== row.id) })} />{row.title} · objetivo {row.target_score}/100</label>)}</fieldset>
      <label className="catalog-checkbox"><input type="checkbox" checked={form.approved} disabled={busy} onChange={event => setForm({ ...form, approved: event.target.checked })} /> Disponible para generar nuevas rutas</label>
      <label className="catalog-note-label">Motivo del cambio<textarea name="resource-change-note" value={note} required minLength={5} maxLength={500} rows={2} disabled={busy} onChange={event => setNote(event.target.value)} /></label>
      <button className="primary" disabled={busy || !data}><Save size={17} />{busy ? 'Guardando…' : 'Guardar recurso'}</button>
    </form>}
    <div className="dashboard-toolbar"><div><label htmlFor="resource-filter">Filtrar por competencia</label><select id="resource-filter" value={filter} onChange={event => setFilter(event.target.value)}><option value="">Todas las competencias</option>{competencies.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div><span className="quiet-note">{resources.length} recursos · versión {data?.revision ?? '—'}</span></div>
    {!data ? <div className="loading"><LoaderCircle className="spin" /> Cargando catálogo…</div> : <div className="catalog-grid">{resources.map(resource => <article className="catalog-card" key={resource.id}><span className={'route-state ' + (resource.approved ? 'completed' : 'pending')}>{resource.approved ? 'Disponible' : 'Retirado'}</span><h3><BookOpen size={17} /> {resource.title}</h3><p>{competencies.find(item => item.id === resource.competency_id)?.name}</p><p>{resource.provider} · {resource.estimated_minutes} min · entrada {resource.entry_score} / objetivo {resource.target_score}</p><p>{resource.practice}</p><button className="secondary" onClick={() => start(resource)}>Editar recurso</button></article>)}</div>}
    {data && <details className="metric-definitions"><summary>Historial de cambios del catálogo</summary>{data.history.length ? data.history.map(event => <p key={event.revision}>Versión {event.revision} · {event.actor_name} · {event.note}</p>) : <p>Catálogo inicial de demostración. Aún no hay cambios administrativos.</p>}</details>}
  </section>
}
