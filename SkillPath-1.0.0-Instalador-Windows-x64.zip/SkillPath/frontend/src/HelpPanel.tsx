import { ArrowRight, BookOpen, ClipboardCheck, Download, FileBarChart2, Route, Users } from 'lucide-react'

export default function HelpPanel({ isAdmin, onStart }: { isAdmin: boolean; onStart: () => void }) {
  const steps = isAdmin ? [
    { icon: Users, title: 'Revisa el avance del equipo', text: 'En Mi equipo, abre el diagnóstico de una persona para validar la evidencia de una actividad completada o solicitarle cambios.' },
    { icon: ClipboardCheck, title: 'Configura el aprendizaje', text: 'En Puestos → Banco de preguntas, crea o edita competencias y preguntas. Asocia la competencia al puesto y agrega materiales en Recursos.' },
    { icon: FileBarChart2, title: 'Consulta y comparte resultados', text: 'En Reportes filtra por persona, categoría y fechas. Exporta el mismo conjunto de resultados a CSV.' },
  ] : [
    { icon: ClipboardCheck, title: 'Descubre tu punto de partida', text: 'En Evaluación elige una de las cuatro categorías y, si corresponde, un puesto. Responde todos los pasos.' },
    { icon: Route, title: 'Sigue tu ruta', text: 'Abre un diagnóstico y consulta sus actividades. Al completarlas, envía tu nota de práctica y un enlace opcional. Consulta la revisión en esa misma ruta.' },
    { icon: FileBarChart2, title: 'Observa tu evolución', text: 'Consulta Mi panel e Historial. Usa Reevaluar esta categoría desde un diagnóstico para comparar instrumentos compatibles.' },
  ]
  return <section className="help-panel">
    <div className="page-heading"><div><h1>Ayuda y manual</h1><p>{isAdmin ? 'Gestión del equipo, catálogos y reportes.' : 'Evaluaciones, rutas y seguimiento del avance.'}</p></div><a className="secondary manual-link" href="/manual.html" target="_blank" rel="noreferrer"><BookOpen size={18} /> Abrir manual completo</a></div>
    <div className="help-steps">{steps.map((step, index) => <article className="help-step" key={step.title}><div className="help-step-top"><step.icon size={23} /><span>0{index + 1}</span></div><h2>{step.title}</h2><p>{step.text}</p></article>)}</div>
    <div className="help-action"><div><h2>Aprende a tu ritmo.</h2><p>Los resultados y el avance se guardan en tu cuenta.</p></div><button className="primary" onClick={onStart}>{isAdmin ? 'Ir a mi equipo' : 'Comenzar evaluación'} <ArrowRight size={18} /></button></div>
    <section className="help-faq"><span className="eyebrow">PREGUNTAS FRECUENTES</span><h2>Lo que conviene saber</h2>
      <details><summary>¿Qué significa una brecha?</summary><p>Es la diferencia entre el nivel requerido y la puntuación obtenida. Se muestra en puntos y porcentaje relativo. Una brecha de cero indica que alcanzaste el objetivo de ese cuestionario.</p></details>
      <details><summary>¿Completar una actividad cambia mi puntuación?</summary><p>El avance registra tu formación declarada. Para observar un cambio de puntuación debes realizar una nueva evaluación vinculada; los diagnósticos anteriores se conservan.</p></details>
      <details><summary>¿Quién puede consultar mis resultados?</summary><p>Cada usuario puede consultar sus propios registros. Su administrador solo ve a las personas asignadas a su equipo.</p></details>
      <details><summary>¿Cómo abro SkillPath otro día?</summary><p>Abre INICIAR_DEMO.cmd desde la carpeta del proyecto. Para cerrar los servicios usa DETENER_DEMO.cmd; cerrar el navegador no los detiene.</p></details>
      <details><summary>¿Cómo instalo la demo en otra computadora?</summary><p>Descomprime el paquete de código en una carpeta local y abre INSTALAR_Y_ABRIR.cmd. La primera instalación necesita Internet. El manual incluye los pasos, las cuentas ficticias y soluciones a errores.</p></details>
    </section>
    <a className="text-button manual-link" href="/manual.html" download="Manual-de-uso-SkillPath.html"><Download size={17} /> Descargar manual para consultar sin conexión</a>
    <p className="quiet-note">Esta versión contiene datos de demostración y cuestionarios pendientes de validación empresarial.</p>
  </section>
}
