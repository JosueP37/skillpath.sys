import { useEffect, useState } from 'react'
import { BookOpen, Check, CheckCircle2, Clock3, ExternalLink, LoaderCircle, RefreshCw, Route, Save, Target } from 'lucide-react'
import { api, type ActivityState, type LearningPath, type LearningProgress, type ProgressItem, type ReviewStatus } from './api'

const duration = (minutes: number) => {
  const hours = Math.floor(minutes / 60)
  const rest = minutes % 60
  return hours ? `${hours} h${rest ? ` ${rest} min` : ''}` : `${rest} min`
}
const states = { pending: 'Pendiente', in_progress: 'En curso', completed: 'Completada' }
const reviewLabels = { approved: 'Evidencia validada', changes_requested: 'Se solicitaron cambios' }
const localDate = (value: string) => new Date(value).toLocaleString('es-PE', { timeZone: 'America/Lima', dateStyle: 'short', timeStyle: 'short' })

function EvidenceStatus({ item }: { item: ProgressItem }) {
  if (item.status !== 'completed') return null
  const review = item.review
  return <div className="evidence-status">
    <strong>{review ? reviewLabels[review.status] : 'Evidencia pendiente de revisión'}</strong>
    {review && <small>{review.reviewer_name} · {localDate(review.reviewed_at)}</small>}
    {review?.feedback && <p>{review.feedback}</p>}
  </div>
}

function ActivityEditor({ item, disabled, onSave }: { item: ProgressItem; disabled: boolean; onSave: (resourceId: string, status: ActivityState, note: string, evidenceUrl: string | null) => Promise<void> }) {
  const [status, setStatus] = useState<ActivityState>(item.status)
  const [note, setNote] = useState(item.note)
  const [evidenceUrl, setEvidenceUrl] = useState(item.evidence_url ?? '')
  useEffect(() => { setStatus(item.status); setNote(item.note); setEvidenceUrl(item.evidence_url ?? '') }, [item.status, item.note, item.evidence_url, item.updated_at])
  const changed = status !== item.status || note.trim() !== item.note || evidenceUrl.trim() !== (item.evidence_url ?? '')
  return <form className="activity-editor" onSubmit={event => { event.preventDefault(); void onSave(item.resource_id, status, note, evidenceUrl.trim() || null) }}>
    <div className="activity-editor-header"><span className={'activity-state ' + item.status}>{item.status === 'completed' && <Check size={14} />}{states[item.status]}</span>{item.updated_at && <small>Guardado: {new Date(item.updated_at).toLocaleString('es-PE', { timeZone: 'America/Lima', dateStyle: 'short', timeStyle: 'short' })}</small>}</div>
    <div className="activity-fields"><div><label htmlFor={'state-' + item.resource_id}>Estado de la actividad</label><select id={'state-' + item.resource_id} value={status} disabled={disabled} onChange={event => setStatus(event.target.value as ActivityState)}><option value="pending">Pendiente</option><option value="in_progress">En curso</option><option value="completed">Completada</option></select></div><div className="activity-note"><label htmlFor={'note-' + item.resource_id}>Nota de práctica {status === 'completed' ? '(obligatoria)' : '(opcional)'}</label><textarea id={'note-' + item.resource_id} value={note} onChange={event => setNote(event.target.value)} maxLength={1000} rows={2} disabled={disabled} required={status === 'completed'} placeholder="Describe lo que practicaste o aprendiste." /></div></div>
    <label className="evidence-field">Enlace de evidencia (opcional)
      <input type="url" value={evidenceUrl} onChange={event => setEvidenceUrl(event.target.value)} maxLength={2083} disabled={disabled} placeholder="https://" />
    </label>
    <EvidenceStatus item={item} />
    {item.review && changed && <p className="quiet-note">Si guardas los cambios, la evidencia volverá a revisión.</p>}
    <div className="activity-editor-footer"><small>{note.length} / 1000 caracteres</small><button className="secondary" type="submit" disabled={disabled || !changed || (status === 'completed' && !note.trim())}><Save size={15} /> Guardar avance</button></div>
  </form>
}

function ActivityReviewer({ item, disabled, onReview }: { item: ProgressItem; disabled: boolean; onReview: (resourceId: string, status: ReviewStatus, feedback: string) => Promise<void> }) {
  const [decision, setDecision] = useState<ReviewStatus>(item.review?.status ?? 'approved')
  const [feedback, setFeedback] = useState(item.review?.feedback ?? '')
  useEffect(() => {
    setDecision(item.review?.status ?? 'approved')
    setFeedback(item.review?.feedback ?? '')
  }, [item.updated_at, item.review?.status, item.review?.feedback])
  const unchanged = decision === item.review?.status && feedback.trim() === item.review.feedback
  return <div className="activity-readonly">
    <span className={'activity-state ' + item.status}>{states[item.status]}</span>
    <p>{item.note || 'Sin nota de práctica.'}</p>
    {item.evidence_url && <div className="path-links"><a href={item.evidence_url} target="_blank" rel="noopener noreferrer">Abrir evidencia <ExternalLink size={13} /></a></div>}
    <EvidenceStatus item={item} />
    {item.status === 'completed' && item.note && <form className="evidence-review" onSubmit={event => {
      event.preventDefault()
      void onReview(item.resource_id, decision, feedback)
    }}>
      <div className="activity-fields">
        <label className="evidence-field">Decisión sobre la evidencia
          <select value={decision} disabled={disabled} onChange={event => setDecision(event.target.value as ReviewStatus)}>
            <option value="approved">Validar evidencia</option>
            <option value="changes_requested">Solicitar cambios</option>
          </select>
        </label>
        <label className="evidence-field">Comentario {decision === 'changes_requested' ? '(obligatorio)' : '(opcional)'}
          <textarea value={feedback} maxLength={1000} rows={2} required={decision === 'changes_requested'} disabled={disabled} onChange={event => setFeedback(event.target.value)} />
        </label>
      </div>
      <button className="secondary" type="submit" disabled={disabled || unchanged || (decision === 'changes_requested' && !feedback.trim())}>
        <Save size={15} /> Guardar revisión
      </button>
    </form>}
  </div>
}

export default function LearningPathPanel({ evaluationId, canEdit = true }: { evaluationId: string; canEdit?: boolean }) {
  const [path, setPath] = useState<LearningPath | null>(null)
  const [progress, setProgress] = useState<LearningProgress | null>(null)
  const [error, setError] = useState('')
  const [progressError, setProgressError] = useState('')
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let active = true
    setLoading(true); setError(''); setProgressError(''); setPath(null); setProgress(null)
    api.learningPath(evaluationId)
      .then(async value => {
        if (!active) return
        setPath(value)
        try { const saved = await api.progress(evaluationId); if (active) setProgress(saved) }
        catch (reason) { if (active) setProgressError((reason as Error).message) }
      })
      .catch(reason => { if (active) setError((reason as Error).message) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [evaluationId, attempt])

  async function reloadProgress() {
    setSaving(true); setProgressError(''); setNotice('')
    try { setProgress(await api.progress(evaluationId)) }
    catch (reason) { setProgressError((reason as Error).message) }
    finally { setSaving(false) }
  }
  async function save(resourceId: string, status: ActivityState, note: string, evidenceUrl: string | null) {
    if (!progress || saving || !canEdit) return
    setSaving(true); setProgressError(''); setNotice('')
    try { setProgress(await api.updateProgress(evaluationId, resourceId, status, note, progress.version, evidenceUrl)); setNotice('Avance guardado.') }
    catch (reason) { setProgressError((reason as Error).message) }
    finally { setSaving(false) }
  }

  async function review(resourceId: string, status: ReviewStatus, feedback: string) {
    if (!progress || saving || canEdit) return
    setSaving(true); setProgressError(''); setNotice('')
    try {
      setProgress(await api.reviewProgress(evaluationId, resourceId, status, feedback, progress.version))
      setNotice('Revisión guardada. El colaborador puede consultarla en su ruta.')
    } catch (reason) { setProgressError((reason as Error).message) }
    finally { setSaving(false) }
  }

  return <section className="learning-path" aria-labelledby="learning-path-title" aria-busy={loading} data-route-id={path?.id}>
    <div className="section-heading"><div><span className="eyebrow">DEL DIAGNÓSTICO A LA ACCIÓN</span><h2 id="learning-path-title">{canEdit ? 'Tu ruta de aprendizaje' : 'Ruta de aprendizaje del usuario'}</h2><p>Un recorrido ordenado a partir de las competencias que necesitas fortalecer.</p></div><span className="path-heading-icon"><Route size={24} /></span></div>
    {loading ? <div className="path-loading" role="status"><LoaderCircle className="spin" size={20} /> Preparando tu ruta…</div> : error ? <div className="path-error" role="alert"><p>{error}</p><button className="secondary" onClick={() => setAttempt(previous => previous + 1)}>Reintentar ruta</button></div> : path && <>
      {path.status === 'no_gaps' ? <div className="path-empty"><CheckCircle2 size={30} /><div><h3>No tienes brechas en esta evaluación</h3><p>Alcanzaste los objetivos de la categoría en este cuestionario. No se han asignado actividades de refuerzo.</p></div></div> : <>
        <div className="path-summary" aria-label="Resumen de la ruta"><span><BookOpen size={18} /><strong>{path.items.length}</strong> actividades</span><span><Clock3 size={18} /><strong>{duration(path.estimated_minutes)}</strong> estimadas</span><span><Target size={18} /><strong>{path.covered_gap_count} de {path.gap_count}</strong> competencias con recursos</span></div>
        {progress && <div className="route-progress-summary"><div><span className="eyebrow">AVANCE EN ESTA RUTA</span><strong data-progress-percent>{progress.completion_percent === null ? 'Sin actividades' : progress.completion_percent.toLocaleString('es-PE') + ' % completado'}</strong><p>{progress.completed_activities} de {progress.total_activities} actividades completadas · {duration(progress.remaining_minutes)} pendientes, estimadas</p><p>{progress.approved_activities} de {progress.completed_activities} evidencias validadas</p><div className="progress-track" role="progressbar" aria-label="Avance de la ruta" aria-valuenow={progress.completion_percent ?? 0} aria-valuemin={0} aria-valuemax={100}><div style={{ width: (progress.completion_percent ?? 0) + '%' }} /></div></div><button className="text-button" disabled={saving} onClick={() => void reloadProgress()}><RefreshCw size={16} /> Recargar avance</button></div>}
        {path.uncovered_competencies.length > 0 && <div className="path-missing" role="status"><strong>Hay competencias pendientes de contenido</strong>{path.uncovered_competencies.map(item => <p key={item.competency_id}>{item.competency_name}: {item.reason}</p>)}</div>}
        {progressError && <div className="path-error" role="alert"><p>{progressError}</p><button className="secondary" disabled={saving} onClick={() => void reloadProgress()}>Recargar avance</button></div>}
        {notice && <p className="save-notice" role="status"><CheckCircle2 size={17} />{notice}</p>}
        <ol className="path-list">{path.items.map(item => {
          const activity = progress?.items.find(row => row.resource_id === item.resource.id)
          return <li key={item.resource.id} className={'path-card' + (activity?.status === 'completed' ? ' activity-completed' : '')} data-resource-id={item.resource.id}><span className="path-step" aria-label={'Paso ' + item.order}>{activity?.status === 'completed' ? <Check size={19} /> : String(item.order).padStart(2, '0')}</span><div className="path-card-content"><div className="path-card-meta"><span>{item.competency_name}</span><span className={item.role === 'prerequisite' ? 'path-badge prerequisite' : 'path-badge'}>{item.role === 'prerequisite' ? 'Base necesaria' : item.resource.level}</span></div><h3>{item.resource.title}</h3><p className="path-provider">{item.resource.provider} <span className="middle-dot">·</span> {duration(item.resource.estimated_minutes)} estimados</p><div className="path-links">{item.resource.links.map(link => <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer">{link.label} <ExternalLink size={13} /></a>)}</div><p className="path-practice"><strong>Para practicar</strong>{item.resource.practice}</p><details className="path-reason"><summary>¿Por qué se recomienda?</summary><p>{item.reason}</p></details>{activity && (canEdit ? <ActivityEditor item={activity} disabled={saving} onSave={save} /> : <ActivityReviewer item={activity} disabled={saving} onReview={review} />)}</div></li>
        })}</ol>
        {progress && progress.events.length > 0 && <details className="progress-history"><summary>Historial de avance ({progress.event_count} cambios)</summary><p className="quiet-note">Se conservan los últimos {progress.retained_event_limit} cambios por ruta.</p><ol>{progress.events.slice(0, 10).map(event => <li key={event.id}><div><strong>{event.title}</strong><span>{event.review_status ? reviewLabels[event.review_status] : states[event.previous_status] + ' → ' + states[event.status]}</span><small>{event.actor_name && event.actor_name + ' · '}{new Date(event.created_at).toLocaleString('es-PE', { timeZone: 'America/Lima' })}</small></div>{event.note && <p>{event.note}</p>}</li>)}</ol>{progress.events.length > 10 && <p className="quiet-note">Se muestran los últimos 10 cambios.</p>}</details>}
      </>}
      <details className="path-explanation"><summary>¿Cómo se eligió esta ruta?</summary><p>{path.explanation}</p><p>{path.catalog_note}</p></details>
      <p className="path-note">El avance refleja las actividades registradas. La validación confirma la revisión de la evidencia. Vuelve a evaluarte para medir cambios en tu puntuación.</p>
    </>}
  </section>
}
