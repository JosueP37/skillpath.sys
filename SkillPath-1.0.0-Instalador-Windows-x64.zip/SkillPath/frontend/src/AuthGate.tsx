import { useEffect, useState, type FormEvent } from 'react'
import { ArrowRight, Eye, EyeOff, Layers3, LoaderCircle, ShieldCheck, Sprout, Users } from 'lucide-react'
import App from './App'
import { api, setSession, type AuthUser, type Administrator } from './api'

export default function AuthGate() {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [checking, setChecking] = useState(true)
  const [error, setError] = useState('')
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [administrators, setAdministrators] = useState<Administrator[]>([])
  const [adminsLoading, setAdminsLoading] = useState(false)
  const [adminsError, setAdminsError] = useState('')
  const [busy, setBusy] = useState(false)
  const [visible, setVisible] = useState(false)
  const [retry, setRetry] = useState(0)

  useEffect(() => {
    let active = true
    setChecking(true)
    api.me().then(session => { if (active) { setSession(session.csrf_token); setUser(session.user) } })
      .catch(reason => { if (active && reason.status !== 401) setError(reason.message) })
      .finally(() => { if (active) setChecking(false) })
    return () => { active = false }
  }, [retry])
  useEffect(() => {
    const expired = () => { setSession(''); setUser(null); setError('Tu sesión terminó. Vuelve a ingresar.'); setMode('login') }
    window.addEventListener('skillpath-session-expired', expired)
    return () => window.removeEventListener('skillpath-session-expired', expired)
  }, [])
  useEffect(() => {
    if (mode !== 'register') return
    let active = true
    setAdminsLoading(true); setAdminsError('')
    api.administrators().then(value => { if (active) setAdministrators(value) })
      .catch(reason => { if (active) setAdminsError(reason.message) })
      .finally(() => { if (active) setAdminsLoading(false) })
    return () => { active = false }
  }, [mode, retry])

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const password = String(data.get('password'))
    if (mode === 'register' && password !== data.get('confirm')) { setError('Las contraseñas deben coincidir.'); return }
    setBusy(true); setError('')
    try {
      const session = mode === 'login'
        ? await api.login(String(data.get('email')), password)
        : await api.register(String(data.get('name')), String(data.get('email')), password, String(data.get('administrator_id')))
      setSession(session.csrf_token); setUser(session.user)
    } catch (reason) { setError((reason as Error).message) }
    finally { setBusy(false) }
  }
  async function logout() {
    setBusy(true); setError('')
    try { await api.logout(); setSession(''); setUser(null); setMode('login') }
    catch (reason) {
      if ((reason as Error & { status?: number }).status === 401) { setSession(''); setUser(null); setMode('login') }
      else setError((reason as Error).message)
    }
    finally { setBusy(false) }
  }

  if (checking) return <div className="auth-loading" role="status"><LoaderCircle className="spin" /> Comprobando tu sesión…</div>
  if (user) return <><App key={user.id} user={user} onLogout={() => void logout()} logoutBusy={busy} />{error && <div className="logout-error" role="alert">{error}<button className="text-button" onClick={() => setError('')}>Cerrar</button></div>}</>

  return <main className="auth-shell">
    <section className="auth-story"><a className="auth-brand" href="#" onClick={event => event.preventDefault()}><Layers3 size={30} />SkillPath</a><span className="eyebrow">ICLOUDFLEX · DESARROLLO DEL TALENTO TI</span><h1>Tu crecimiento<br />tiene un camino.</h1><p>Evalúa tus competencias, sigue tu ruta de aprendizaje y observa cuánto has avanzado.</p><div className="auth-steps"><span><Sprout size={22} /> Un recorrido propio</span><span><Users size={22} /> Un administrador que te acompaña</span><span><ShieldCheck size={22} /> Historial y seguimiento por equipo</span></div><small>Capstone Project 2026 · Demostración local</small></section>
    <section className="auth-card">
      <div className="auth-tabs" role="tablist" aria-label="Acceso"><button role="tab" aria-selected={mode === 'login'} disabled={busy} onClick={() => { setMode('login'); setError('') }}>Iniciar sesión</button><button role="tab" aria-selected={mode === 'register'} disabled={busy} onClick={() => { setMode('register'); setError('') }}>Crear cuenta</button></div>
      <div className="auth-heading"><span className="eyebrow">{mode === 'login' ? 'BIENVENIDO A SKILLPATH' : 'TU PRIMER PASO'}</span><h2>{mode === 'login' ? 'Continúa tu recorrido.' : 'Crea tu cuenta de usuario.'}</h2><p>{mode === 'login' ? 'Ingresa con tu correo y contraseña.' : 'Elige al administrador responsable de acompañar tu desarrollo.'}</p></div>
      {error && <div className="path-error" role="alert"><p>{error}</p></div>}
      <form key={mode} onSubmit={event => void submit(event)} className="auth-form">
        {mode === 'register' && <div><label htmlFor="auth-name">Nombre completo</label><input id="auth-name" name="name" autoComplete="name" minLength={2} maxLength={80} required disabled={busy} /></div>}
        <div><label htmlFor="auth-email">Correo electrónico</label><input id="auth-email" name="email" type="email" autoComplete="username" maxLength={254} required disabled={busy} placeholder="tu.nombre@empresa.com" /></div>
        <div><label htmlFor="auth-password">Contraseña</label><div className="password-field"><input id="auth-password" name="password" type={visible ? 'text' : 'password'} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} minLength={mode === 'register' ? 12 : 1} maxLength={128} required disabled={busy} /><button type="button" aria-label={visible ? 'Ocultar contraseña' : 'Mostrar contraseña'} onClick={() => setVisible(value => !value)}>{visible ? <EyeOff size={18} /> : <Eye size={18} />}</button></div>{mode === 'register' && <small>Utiliza al menos 12 caracteres.</small>}</div>
        {mode === 'register' && <><div><label htmlFor="auth-confirm">Confirmar contraseña</label><input id="auth-confirm" name="confirm" type={visible ? 'text' : 'password'} autoComplete="new-password" minLength={12} maxLength={128} required disabled={busy} /></div><div><label htmlFor="auth-administrator">Administrador a cargo</label><select id="auth-administrator" name="administrator_id" required defaultValue="" disabled={busy || adminsLoading || !administrators.length}><option value="">{adminsLoading ? 'Cargando administradores…' : 'Selecciona un administrador'}</option>{administrators.map(admin => <option key={admin.id} value={admin.id}>{admin.name}</option>)}</select><small>Tu cuenta quedará vinculada a este administrador.</small></div>{adminsError ? <div className="path-error" role="alert"><p>{adminsError}</p><button className="text-button" type="button" onClick={() => setRetry(value => value + 1)}>Volver a cargar</button></div> : !adminsLoading && !administrators.length && <p className="path-error" role="status">Primero debe existir un administrador activo para que puedas registrarte.</p>}</>}
        <button className="primary auth-submit" disabled={busy || (mode === 'register' && (adminsLoading || !!adminsError || !administrators.length))}>{busy ? <><LoaderCircle className="spin" size={18} /> Procesando…</> : <>{mode === 'login' ? 'Ingresar' : 'Crear mi cuenta'} <ArrowRight size={18} /></>}</button>
      </form>
      <p className="auth-footnote">Cada usuario consulta su propio avance. Cada administrador consulta únicamente a sus usuarios asignados.</p>
      <a className="text-button manual-link auth-manual" href="/manual.html" target="_blank" rel="noreferrer">¿Primera vez aquí? Consulta el manual <ArrowRight size={16} /></a>
    </section>
  </main>
}
