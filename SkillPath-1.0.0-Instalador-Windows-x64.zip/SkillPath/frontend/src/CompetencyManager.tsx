import { useState, type FormEvent } from 'react'
import { ArrowLeft, Plus, Save } from 'lucide-react'
import { api, type BankCompetency, type CompetencyBank, type CompetencyInput, type Profile, type QuestionInput } from './api'

const blankQuestion = (): QuestionInput => ({ text: '', weight: 1, options: ['', ''], correct_index: 0 })

export default function CompetencyManager({ profiles, bank, onSaved, onBack }: {
  profiles: Profile[]
  bank: CompetencyBank
  onSaved: (bank: CompetencyBank) => void
  onBack: () => void
}) {
  const [categoryId, setCategoryId] = useState(profiles[0].id)
  const [editingId, setEditingId] = useState<string>()
  const [form, setForm] = useState<CompetencyInput | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const competencies = bank.competencies.filter(row => row.category_id === categoryId)

  function edit(competency?: BankCompetency) {
    setEditingId(competency?.id)
    setError('')
    setNotice('')
    setForm({
      name: competency?.name ?? '',
      category_id: categoryId,
      questions: competency?.questions.map(question => ({
        id: question.id, text: question.text, weight: question.weight,
        options: question.options.map(option => option.text),
        correct_index: question.options.findIndex(option => option.id === question.correct),
      })) ?? [blankQuestion()],
    })
  }

  function updateQuestion(index: number, change: Partial<QuestionInput>) {
    setForm(current => current && {
      ...current, questions: current.questions.map((row, position) => position === index ? { ...row, ...change } : row),
    })
  }

  async function save(event: FormEvent) {
    event.preventDefault()
    if (!form || busy) return
    setError('')
    if (!form.name.trim() || form.questions.some(question => question.text.trim().length < 3 ||
      question.options.some(option => !option.trim()) ||
      new Set(question.options.map(option => option.trim().toLowerCase())).size !== question.options.length)) {
      setError('Escribe el nombre, los enunciados y opciones distintas para cada pregunta.')
      return
    }
    setBusy(true)
    try {
      onSaved(await api.saveCompetency(form, bank.revision, editingId))
      setForm(null)
      setNotice('Competencia y preguntas guardadas.')
    } catch (reason) { setError((reason as Error).message) }
    finally { setBusy(false) }
  }

  async function reload() {
    setBusy(true)
    try {
      onSaved(await api.competencyBank())
      setError('')
      setForm(null)
      setNotice('')
    } catch (reason) { setError((reason as Error).message) }
    finally { setBusy(false) }
  }

  return <section>
    <button className="text-button" disabled={busy} onClick={onBack}><ArrowLeft size={17} /> Volver a puestos</button>
    <div className="page-heading">
      <div><h1>Competencias y preguntas</h1><p>Configura las preguntas, sus respuestas correctas y el peso de cada una.</p></div>
      <button className="primary" disabled={busy || !!form} onClick={() => edit()}><Plus size={17} /> Nueva competencia</button>
    </div>
    <div className="dashboard-toolbar">
      <div>
        <label htmlFor="bank-category">Categoría</label>
        <select id="bank-category" value={categoryId} disabled={busy || !!form} onChange={event => { setCategoryId(event.target.value); setNotice('') }}>
          {profiles.map(profile => <option key={profile.id} value={profile.id}>{profile.name}</option>)}
        </select>
      </div>
    </div>
    {error && <div className="path-error" role="alert"><p>{error}</p><button className="text-button" disabled={busy} onClick={() => void reload()}>Recargar banco y descartar cambios</button></div>}
    {notice && <p className="save-notice" role="status">{notice}</p>}
    {form && <form className="catalog-form bank-form" onSubmit={event => void save(event)}>
      <div className="section-heading">
        <h2>{editingId ? 'Editar competencia' : 'Registrar competencia'}</h2>
        <button type="button" className="text-button" disabled={busy} onClick={() => { setForm(null); setError('') }}>Cancelar</button>
      </div>
      <label>Nombre de la competencia
        <input value={form.name} required minLength={2} maxLength={120} disabled={busy} onChange={event => setForm({ ...form, name: event.target.value })} />
      </label>
      {form.questions.map((question, index) => <fieldset key={question.id ?? index}>
        <legend>Pregunta {index + 1}</legend>
        <div className="catalog-fields">
          <label className="wide-field">Enunciado
            <textarea value={question.text} rows={2} required minLength={3} maxLength={600} disabled={busy} onChange={event => updateQuestion(index, { text: event.target.value })} />
          </label>
          {question.options.map((option, position) => <label key={position}>Opción {position + 1}
            <input value={option} required maxLength={300} disabled={busy} onChange={event => updateQuestion(index, {
              options: question.options.map((text, i) => i === position ? event.target.value : text),
            })} />
          </label>)}
          <label>Respuesta correcta
            <select value={question.correct_index} disabled={busy} onChange={event => updateQuestion(index, { correct_index: Number(event.target.value) })}>
              {question.options.map((_, position) => <option key={position} value={position}>Opción {position + 1}</option>)}
            </select>
          </label>
          <label>Peso (1–10)
            <input type="number" min={1} max={10} required value={question.weight} disabled={busy} onChange={event => updateQuestion(index, { weight: Number(event.target.value) })} />
          </label>
        </div>
        <div className="bank-actions">
          {question.options.length < 6 && <button type="button" className="text-button" disabled={busy} onClick={() => updateQuestion(index, { options: [...question.options, ''] })}>Añadir opción</button>}
          {question.options.length > 2 && <button type="button" className="text-button" disabled={busy} onClick={() => updateQuestion(index, {
            options: question.options.slice(0, -1), correct_index: Math.min(question.correct_index, question.options.length - 2),
          })}>Quitar última opción</button>}
          {form.questions.length > 1 && <button type="button" className="text-button" disabled={busy} onClick={() => setForm({ ...form, questions: form.questions.filter((_, i) => i !== index) })}>Quitar pregunta</button>}
        </div>
      </fieldset>)}
      <div className="bank-actions">
        <button type="button" className="secondary" disabled={busy || form.questions.length >= 100} onClick={() => setForm({ ...form, questions: [...form.questions, blankQuestion()] })}><Plus size={17} /> Añadir pregunta</button>
        <button className="primary" disabled={busy} type="submit"><Save size={17} /> {busy ? 'Guardando…' : 'Guardar competencia'}</button>
      </div>
    </form>}
    <p className="quiet-note">Asocia las nuevas competencias a un puesto para incluirlas en su evaluación.</p>
    <div className="catalog-grid">{competencies.map(competency => <article className="catalog-card" key={competency.id}>
      <h3>{competency.name}</h3>
      <p>{competency.questions.length} {competency.questions.length === 1 ? 'pregunta' : 'preguntas'}</p>
      <button className="secondary" disabled={busy || !!form} onClick={() => edit(competency)}>Editar competencia</button>
    </article>)}</div>
  </section>
}
