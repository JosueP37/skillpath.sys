import { useEffect, useState, type FormEvent } from 'react'
import { BriefcaseBusiness, LoaderCircle, Plus, Save } from 'lucide-react'
import { api, type CompetencyBank, type JobProfile, type JobInput, type Profile } from './api'
import CompetencyManager from './CompetencyManager'

export default function JobManager({ profiles }: { profiles: Profile[] }) {
  const [jobs, setJobs] = useState<JobProfile[]>([])
  const [bank, setBank] = useState<CompetencyBank | null>(null)
  const [showBank, setShowBank] = useState(false)
  const [editing, setEditing] = useState<JobProfile | null>(null)
  const [form, setForm] = useState<JobInput | null>(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [retry, setRetry] = useState(0)

  useEffect(() => {
    let active = true
    setLoading(true); setError('')
    Promise.all([api.jobs('', true), api.competencyBank()]).then(([jobs, catalog]) => {
      if (active) { setJobs(jobs); setBank(catalog) }
    })
      .catch(reason => { if (active) setError(reason.message) }).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [retry])
  function start(job?: JobProfile) {
    setEditing(job ?? null); setError(''); setNotice('')
    const category = profiles[0]
    if (!category) return
    setForm(job ? { category_id: job.category_id, name: job.name, description: job.description, active: job.active, competencies: job.competencies.map(row => ({ ...row })) } : { category_id: category.id, name: '', description: '', active: true, competencies: category.competencies.map(row => ({ competency_id: row.id, required: row.required, criticality: 2 })) })
  }
  async function save(event: FormEvent) {
    event.preventDefault()
    if (!form) return
    setBusy(true); setError(''); setNotice('')
    try {
      const saved = await api.saveJob(form, editing?.id, editing?.revision)
      setEditing(saved); setForm(null); setNotice('Puesto guardado. Los diagnósticos anteriores conservan su matriz original.')
      setRetry(value => value + 1)
    } catch (reason) { setError((reason as Error).message) }
    finally { setBusy(false) }
  }
  const category = profiles.find(item => item.id === form?.category_id)
  if (showBank && bank && profiles.length) {
    return <CompetencyManager profiles={profiles} bank={bank} onSaved={setBank} onBack={() => setShowBank(false)} />
  }
  return <section>
    <div className="page-heading"><div><span className="eyebrow">CATÁLOGO DE PUESTOS · RF-04</span><h1>Una matriz para cada puesto.</h1><p>Asocia competencias y define los niveles que se utilizarán en nuevos diagnósticos.</p></div><div className="bank-actions"><button className="secondary" disabled={!bank || !profiles.length || busy || !!form} onClick={() => setShowBank(true)}>Banco de preguntas</button><button className="primary" disabled={!profiles.length || !bank || busy} onClick={() => start()}><Plus size={17} /> Nuevo puesto</button></div></div>
    <p className="catalog-info">Catálogo común de la organización, administrado por los administradores. Los puestos se agrupan dentro de las cuatro categorías de servicio.</p>
    {error && <div className="path-error" role="alert"><p>{error}</p><button className="text-button" onClick={() => setRetry(value => value + 1)}>Recargar catálogo</button></div>}
    {notice && <p className="save-notice" role="status">{notice}</p>}
    {form && <form className="catalog-form" onSubmit={event => void save(event)}>
      <div className="section-heading"><h2>{editing ? 'Editar puesto' : 'Registrar puesto'}</h2><button type="button" className="text-button" disabled={busy} onClick={() => setForm(null)}>Cancelar</button></div>
      <div className="catalog-fields"><label>Nombre del puesto<input name="job-name" value={form.name} onChange={event => setForm({ ...form, name: event.target.value })} minLength={2} maxLength={100} required disabled={busy} /></label><label>Categoría<select name="job-category" value={form.category_id} disabled={busy || !!editing} onChange={event => { const item = profiles.find(row => row.id === event.target.value)!; setForm({ ...form, category_id: item.id, competencies: item.competencies.map(row => ({ competency_id: row.id, required: row.required, criticality: 2 })) }) }}>{profiles.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label className="wide-field">Descripción<textarea name="job-description" value={form.description} onChange={event => setForm({ ...form, description: event.target.value })} maxLength={500} rows={2} disabled={busy} /></label></div>
      <fieldset className="matrix-editor"><legend>Competencias asociadas</legend><p>Selecciona al menos una. Nivel requerido: 1–100. Criticidad: 1–5.</p>{bank?.competencies.filter(row => row.category_id === category?.id).map(competency => {
        const binding = form.competencies.find(row => row.competency_id === competency.id)
        const defaultLevel = category?.competencies.find(row => row.id === competency.id)?.required ?? 80
        return <div className="matrix-row" key={competency.id}><label className="matrix-check"><input type="checkbox" checked={!!binding} disabled={busy} onChange={event => setForm({ ...form, competencies: event.target.checked ? [...form.competencies, { competency_id: competency.id, required: defaultLevel, criticality: 2 }] : form.competencies.filter(row => row.competency_id !== competency.id) })} />{competency.name}</label><label>Nivel requerido<input aria-label={'Nivel requerido: ' + competency.name} type="number" min="1" max="100" value={binding?.required ?? ''} disabled={busy || !binding} required={!!binding} onChange={event => setForm({ ...form, competencies: form.competencies.map(row => row.competency_id === competency.id ? { ...row, required: Number(event.target.value) } : row) })} /></label><label>Criticidad<input aria-label={'Criticidad: ' + competency.name} type="number" min="1" max="5" value={binding?.criticality ?? ''} disabled={busy || !binding} required={!!binding} onChange={event => setForm({ ...form, competencies: form.competencies.map(row => row.competency_id === competency.id ? { ...row, criticality: Number(event.target.value) } : row) })} /></label></div>
      })}</fieldset>
      <label className="catalog-checkbox"><input type="checkbox" checked={form.active} disabled={busy} onChange={event => setForm({ ...form, active: event.target.checked })} /> Disponible para nuevas evaluaciones</label>
      <p className="quiet-note">Desmarcar retira el puesto de la selección. Sus resultados anteriores permanecen guardados.</p>
      <button className="primary" disabled={busy || !form.competencies.length}><Save size={17} />{busy ? 'Guardando…' : 'Guardar puesto'}</button>
    </form>}
    {loading ? <div className="loading"><LoaderCircle className="spin" /> Cargando puestos…</div> : !jobs.length ? <div className="empty"><BriefcaseBusiness size={36} /><h2>Registra el primer puesto</h2><p>Los diagnósticos generales de las cuatro categorías siguen disponibles.</p></div> : <div className="catalog-grid">{jobs.map(job => <article className="catalog-card" key={job.id}><span className={'route-state ' + (job.active ? 'completed' : 'pending')}>{job.active ? 'Activo' : 'Retirado'}</span><h3>{job.name}</h3><p>{profiles.find(item => item.id === job.category_id)?.name}</p><p>{job.description}</p><div className="catalog-tags">{job.competencies.map(row => <span key={row.competency_id}>{bank?.competencies.find(item => item.id === row.competency_id)?.name} · {row.required}/100</span>)}</div><small>Versión {job.revision} · actualizado por {job.updated_by}</small><button className="secondary" onClick={() => start(job)}>Editar puesto</button><details onToggle={async event => { if (!event.currentTarget.open || job.history) return; try { const detail = await api.job(job.id); setJobs(value => value.map(row => row.id === job.id ? detail : row)) } catch (reason) { setError((reason as Error).message) } }}><summary>Historial de versiones</summary>{job.history?.map(event => <p key={event.revision}>Versión {event.revision} · {event.actor_name} · {new Date(event.at).toLocaleString('es-PE')}</p>)}</details></article>)}</div>}
  </section>
}
