import { useEffect, useState } from 'react'
import { ArrowLeft, ArrowRight, ClipboardCheck, LoaderCircle, RefreshCw, Search, TrendingUp, Users } from 'lucide-react'
import { api, type Evaluation, type TeamMember, type MemberDetail } from './api'

const n = (value: number | null) => value === null ? '—' : value.toLocaleString('es-PE', { maximumFractionDigits: 2 })
const date = (value: string) => new Date(value).toLocaleString('es-PE', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'America/Lima' })

export default function TeamPanel({ onOpenResult }: { onOpenResult: (id: string) => void }) {
  const [members, setMembers] = useState<TeamMember[]>([])
  const [selected, setSelected] = useState('')
  const [detail, setDetail] = useState<MemberDetail | null>(null)
  const [history, setHistory] = useState<Evaluation[]>([])
  const [more, setMore] = useState(false)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('all')
  const [sort, setSort] = useState('name')
  const normalize = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es-PE')
  const visibleMembers = members.filter(member => {
    const matches = normalize(member.name + ' ' + member.email + ' ' + (member.latest_category ?? '')).includes(normalize(query.trim()))
    const state = (member.completion_percent ?? 0) >= 100 ? 'complete' : (member.completion_percent ?? 0) > 0 ? 'partial' : 'zero'
    return matches && (status === 'all' || state === status)
  }).sort((a, b) => sort === 'progress' ? (a.completion_percent ?? -1) - (b.completion_percent ?? -1) || a.name.localeCompare(b.name, 'es') : a.name.localeCompare(b.name, 'es'))
  const activities = members.reduce((sum, member) => sum + member.total_activities, 0)
  const completed = members.reduce((sum, member) => sum + member.completed_activities, 0)

  useEffect(() => {
    let active = true
    setLoading(true); setError(''); setDetail(null); setHistory([])
    const action = selected ? Promise.all([api.member(selected), api.history(0, selected)]).then(([value, rows]) => { if (active) { setDetail(value); setHistory(rows); setMore(rows.length === 20) } }) : api.team().then(value => { if (active) setMembers(value.members) })
    action.catch(reason => { if (active) setError(reason.message) }).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [selected, retry])
  async function loadMore() {
    setLoadingMore(true); setError('')
    try { const rows = await api.history(history.length, selected); setHistory(value => [...value, ...rows]); setMore(rows.length === 20) }
    catch (reason) { setError((reason as Error).message) }
    finally { setLoadingMore(false) }
  }
  return <section className="team-panel">
    <div className="page-heading"><div><span className="eyebrow">ACOMPAÑAMIENTO DEL EQUIPO</span><h1>{detail ? detail.member.name : 'Tu equipo, paso a paso.'}</h1><p>{detail ? detail.member.email : 'Consulta el historial y la evolución de tus usuarios asignados.'}</p></div><button className="secondary" disabled={loading} onClick={() => setRetry(value => value + 1)}><RefreshCw size={16} /> Actualizar equipo</button></div>
    {selected && <button className="text-button team-back" onClick={() => setSelected('')}><ArrowLeft size={17} /> Volver a mi equipo</button>}
    {error && <div className="path-error" role="alert"><p>{error}</p><button className="secondary" onClick={() => setRetry(value => value + 1)}>Reintentar equipo</button></div>}
    {loading ? <div className="loading" role="status"><LoaderCircle className="spin" /> Cargando equipo…</div> : detail ? <>
      <div className="team-member-summary"><span><ClipboardCheck size={18} /><strong>{detail.member.evaluation_count}</strong> evaluaciones</span><span><TrendingUp size={18} /><strong>{n(detail.member.completion_percent)} %</strong> de actividades completadas</span><span>{detail.member.completed_activities} de {detail.member.total_activities} actividades</span></div>
      <div className="section-heading"><div><h2>Evolución de competencias</h2><p>Primer y último diagnóstico comparable, separados por categoría y versión.</p></div></div>
      {!detail.evolution.length && <div className="empty"><TrendingUp size={28} /><p>Este usuario todavía no tiene evaluaciones.</p></div>}
      <div className="evolution-grid">{detail.evolution.map((series, index) => <article className="evolution-card" key={series.profile_id + '-' + index}><span className="eyebrow">{series.evaluation_count} DIAGNÓSTICOS · {series.assessment_version}</span><h3>{series.profile_name}</h3>{series.job_profile_name && <p>{series.job_profile_name}</p>}<div className="evolution-score"><span>{n(series.first_score)}<small>Inicial</small></span><ArrowRight size={21} /><span>{n(series.latest_score)}<small>Actual</small></span><strong className={(series.score_delta ?? 0) < 0 ? 'delta negative' : 'delta'}>{series.score_delta === null ? 'Sin comparación' : (series.score_delta > 0 ? '+' : '') + n(series.score_delta) + ' puntos'}</strong></div><p>Competencias con brecha: {series.first_gap_count} al inicio · {series.latest_gap_count} actuales.</p><div className="evolution-points" aria-label="Puntuación de cada diagnóstico">{series.points.map((point, i) => <button key={point.id} onClick={() => onOpenResult(point.id)} title={date(point.created_at)}><span className="evolution-bar"><i style={{ height: Math.max(point.score, 2) + '%' }} /></span><strong>{n(point.score)}</strong><small>#{i + 1}</small></button>)}</div><details><summary>Comparación por competencia</summary>{series.competencies.map(row => <p key={row.id}><strong>{row.name}</strong><br />{n(row.first_score)} → {n(row.latest_score)} / 100 · {row.score_delta > 0 ? '+' : ''}{n(row.score_delta)} puntos</p>)}</details></article>)}</div>
      <p className="quiet-note">{detail.definition}</p>
      <div className="section-heading"><div><h2>Historial de {detail.member.name}</h2><p>Abre cada diagnóstico para ver sus brechas, ruta y cambios de avance.</p></div></div>
      <div className="history-list">{history.map(item => <button className="history-row" key={item.id} onClick={() => onOpenResult(item.id)}><span className="history-icon"><ClipboardCheck size={21} /></span><span className="history-title"><strong>{item.profile_name}{item.job_profile_name && ' · ' + item.job_profile_name}</strong><small>{date(item.created_at)}</small></span><span className="history-score">{n(item.overall_score)}<small> / 100</small></span><span className="history-gap">{item.competencies_with_gap} por fortalecer</span><ArrowRight size={18} /></button>)}</div>
      {more && <button className="secondary history-more" disabled={loadingMore} onClick={() => void loadMore()}>{loadingMore ? 'Cargando…' : 'Cargar más evaluaciones'}</button>}
    </> : <>
      <div className="team-overview" aria-label="Resumen del equipo"><article><span>Personas a tu cargo</span><strong>{members.length}</strong><small>Equipo asignado</small></article><article><span>Personas evaluadas</span><strong>{members.filter(member => member.evaluation_count > 0).length}</strong><small>Con al menos un diagnóstico</small></article><article><span>Actividades completadas</span><strong>{completed}<em> / {activities}</em></strong><small>Sobre todas sus rutas</small></article><article><span>Avance del equipo</span><strong>{activities ? n(completed / activities * 100) + ' %' : '—'}</strong><small>Formación declarada</small></article></div>
      {!members.length ? <div className="empty"><Users size={34} /><h2>Aún no tienes usuarios asignados</h2><p>Los nuevos usuarios pueden elegirte al crear su cuenta.</p></div> : <>
        <div className="team-filter-bar"><div className="team-search"><label htmlFor="team-search">Buscar una persona</label><div><Search size={18} /><input id="team-search" type="search" value={query} placeholder="Nombre, correo o categoría" onChange={event => setQuery(event.target.value)} /></div></div><label>Avance de actividades<select value={status} onChange={event => setStatus(event.target.value)}><option value="all">Todos los avances</option><option value="zero">Sin actividades completadas</option><option value="partial">Avance parcial</option><option value="complete">100 % completado</option></select></label><label>Ordenar por<select value={sort} onChange={event => setSort(event.target.value)}><option value="name">Nombre A–Z</option><option value="progress">Menor avance primero</option></select></label></div>
        <div className="team-results-heading"><h2>Personas de tu equipo</h2><span role="status">{visibleMembers.length} de {members.length} personas</span></div>
        {!visibleMembers.length ? <div className="empty team-no-results"><Search size={30} /><h2>No encontramos coincidencias</h2><p>Prueba con otro nombre o cambia los filtros.</p><button className="secondary" onClick={() => { setQuery(''); setStatus('all') }}>Limpiar filtros</button></div> : <div className="team-grid">{visibleMembers.map(member => <button className="team-card" key={member.id} onClick={() => setSelected(member.id)} aria-label={'Ver seguimiento de ' + member.name}><div className="team-card-heading"><span className="member-avatar">{member.name.split(' ').map(part => part[0]).slice(0, 2).join('')}</span><span><strong>{member.name}</strong><small>{member.email}</small></span><ArrowRight size={18} /></div><p className="member-category">{member.latest_category ?? 'Sin diagnóstico todavía'}</p><div className="team-card-metrics"><span><strong>{member.evaluation_count}</strong>Evaluaciones</span><span><strong>{member.latest_score === null ? '—' : n(member.latest_score)}<em> / 100</em></strong>Última puntuación</span></div><div className="member-progress-label"><span>Avance de actividades</span><strong>{member.completion_percent === null ? 'Sin actividades' : n(member.completion_percent) + ' %'}</strong></div><div className="member-progress-track" role="img" aria-label={member.completed_activities + ' de ' + member.total_activities + ' actividades completadas'}><span style={{ width: Math.max(0, Math.min(100, member.completion_percent ?? 0)) + '%' }} /></div><div className="member-card-bottom"><span>{member.completed_activities} de {member.total_activities} completadas</span><strong>Ver seguimiento <ArrowRight size={14} /></strong></div></button>)}</div>}
      </>}
    </>}

  </section>
}
