import { useEffect, useState } from 'react'
import { ArrowDownToLine, ArrowRight, FileBarChart2, LoaderCircle, RefreshCw } from 'lucide-react'
import { api, type Profile, type TeamMember, type TeamReport, type ReportFilters } from './api'

const number = (value: number | null) => value === null ? '—' : value.toLocaleString('es-PE', { maximumFractionDigits: 2 })
const states: Record<string, string> = { not_evaluated: 'Sin evaluación', no_route: 'Sin ruta generada', no_activities: 'Sin actividades', completed: 'Completada', in_progress: 'En curso', pending: 'Pendiente' }

export default function Reports({ profiles, onOpenResult }: { profiles: Profile[]; onOpenResult: (id: string) => void }) {
  const [members, setMembers] = useState<TeamMember[]>([])
  const [filters, setFilters] = useState<ReportFilters>({})
  const [data, setData] = useState<TeamReport | null>(null)
  const [busy, setBusy] = useState(true)
  const [exporting, setExporting] = useState(false)
  const [error, setError] = useState('')
  const [attempt, setAttempt] = useState(0)
  useEffect(() => { let active = true; api.team().then(value => { if (active) setMembers(value.members) }).catch(reason => { if (active) setError(reason.message) }); return () => { active = false } }, [])
  useEffect(() => {
    let active = true
    setBusy(true); setError(''); setData(null)
    api.report(filters).then(value => { if (active) setData(value) }).catch(reason => { if (active) setError(reason.message) }).finally(() => { if (active) setBusy(false) })
    return () => { active = false }
  }, [filters, attempt])
  async function download() {
    setExporting(true); setError('')
    try { await api.exportReport(filters) } catch (reason) { setError((reason as Error).message) } finally { setExporting(false) }
  }
  return <section className="reports">
    <div className="page-heading"><div><span className="eyebrow">INFORMACIÓN PARA ACOMPAÑAR · RF-08</span><h1>El estado de tu equipo.</h1><p>Brechas, rutas, actividades y competencias alcanzadas, con filtros y exportación.</p></div><button className="primary" disabled={busy || exporting || !data} onClick={() => void download()}><ArrowDownToLine size={17} />{exporting ? 'Exportando…' : 'Exportar reporte CSV'}</button></div>
    <div className="report-filters"><label>Categoría<select aria-label="Categoría del reporte" value={filters.profile_id ?? ''} onChange={event => setFilters({ ...filters, profile_id: event.target.value })}><option value="">Todas las categorías</option>{profiles.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Usuario<select aria-label="Usuario del reporte" value={filters.user_id ?? ''} onChange={event => setFilters({ ...filters, user_id: event.target.value })}><option value="">Todo mi equipo</option>{members.map(member => <option key={member.id} value={member.id}>{member.name}</option>)}</select></label><label>Desde<input aria-label="Fecha inicial del reporte" type="date" value={filters.date_from ?? ''} onChange={event => setFilters({ ...filters, date_from: event.target.value })} /></label><label>Hasta<input aria-label="Fecha final del reporte" type="date" value={filters.date_to ?? ''} onChange={event => setFilters({ ...filters, date_to: event.target.value })} /></label><button className="secondary" disabled={busy} onClick={() => setAttempt(value => value + 1)}><RefreshCw size={16} />Actualizar</button></div>
    {error && <div className="path-error" role="alert"><p>{error}</p><button className="secondary" onClick={() => setAttempt(value => value + 1)}>Reintentar reporte</button></div>}
    {busy ? <div className="loading"><LoaderCircle className="spin" /> Preparando reporte…</div> : data && <>
      <div className="kpi-grid"><article className="kpi-card"><div><span>Usuarios del filtro</span><FileBarChart2 size={18} /></div><strong data-report-users>{data.summary.user_count}</strong><p>{data.summary.evaluated_users} con evaluación</p></article><article className="kpi-card"><div><span>Diagnósticos</span></div><strong>{data.summary.evaluation_count}</strong><p>{data.summary.series_count} series comparables</p></article><article className="kpi-card"><div><span>Rutas asignadas</span></div><strong>{data.summary.path_count}</strong><p>Sobre los diagnósticos del filtro</p></article><article className="kpi-card kpi-accent"><div><span>Avance formativo</span></div><strong>{number(data.summary.completion_percent)}<small>{data.summary.completion_percent === null ? '' : ' %'}</small></strong><p>{data.summary.completed_activities} de {data.summary.total_activities} actividades</p></article></div>
      {!data.rows.length ? <div className="empty"><FileBarChart2 size={36} /><h2>Sin usuarios en el filtro</h2><p>Los nuevos usuarios pueden elegirte al crear su cuenta.</p></div> : <div className="report-table-wrap"><table className="report-table"><caption>Estado por persona, categoría e instrumento comparable</caption><thead><tr><th>Usuario / categoría</th><th>Puntuación</th><th>Brechas / alcanzadas</th><th>Rutas y avance</th><th>Diagnóstico</th></tr></thead><tbody>{data.rows.map((row, index) => <tr key={row.user_id + '-' + index}><td><strong>{row.user_name}</strong><span>{row.profile_name ?? 'Sin diagnóstico'}</span>{row.job_profile_name && <small>{row.job_profile_name}</small>}<small>{row.assessment_version ?? 'Sin instrumento'}</small></td><td><strong>{number(row.latest_score)}{row.latest_score === null ? '' : ' / 100'}</strong><span>{row.score_delta === null ? 'Sin comparación' : (row.score_delta > 0 ? '+' : '') + number(row.score_delta) + ' puntos'}</span><small>{row.evaluation_count} evaluaciones</small></td><td><strong>{row.competencies_with_gap ?? '—'} con brecha</strong><span>{row.competencies_achieved ?? '—'} alcanzadas</span>{!!row.gaps.length && <details><summary>Ver brechas</summary>{row.gaps.map(gap => <p key={gap.competency_name}>{gap.competency_name}: {number(gap.gap_points)} puntos</p>)}</details>}{!!row.achieved.length && <details><summary>Ver alcanzadas</summary>{row.achieved.map(name => <p key={name}>{name}</p>)}</details>}</td><td><strong>{number(row.completion_percent)}{row.completion_percent === null ? '' : ' %'}</strong><span>{row.completed_activities}/{row.total_activities} actividades · {row.path_count} rutas</span><small>{states[row.status]}</small></td><td>{row.latest_evaluation_id ? <button className="text-button" onClick={() => onOpenResult(row.latest_evaluation_id!)}>Abrir <ArrowRight size={15} /></button> : 'Pendiente'}</td></tr>)}</tbody></table></div>}
      <details className="metric-definitions"><summary>Alcance y cálculo del reporte</summary>{data.definitions.map(text => <p key={text}>{text}</p>)}<p>Generado: {new Date(data.generated_at).toLocaleString('es-PE', { timeZone: 'America/Bogota' })} · administrador: {data.administrator}.</p></details>
    </>}
  </section>
}
