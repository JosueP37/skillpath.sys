import { useEffect, useRef, useState } from 'react'
import { ArrowDownToLine, ArrowLeft, ArrowRight, BriefcaseBusiness, CircleHelp, FileBarChart2, LibraryBig, BarChart3, BookOpen, Check, CheckCircle2, ClipboardCheck, Code2, Headset, History, Layers3, LoaderCircle, LogOut, Menu, Users, Server, ShieldCheck, Sprout, Target, X } from 'lucide-react'
import { api, type Assessment, type Evaluation, type Profile, type AuthUser, type JobProfile } from './api'

import LearningPathPanel from './LearningPathPanel'
import Dashboard from './Dashboard'
import TeamPanel from './TeamPanel'
import JobManager from './JobManager'
import ResourceManager from './ResourceManager'
import Reports from './Reports'
import HelpPanel from './HelpPanel'

const number = (value: number) => value.toLocaleString('es-PE', { maximumFractionDigits: 2 })
const date = (value: string) => new Date(value).toLocaleString('es-PE', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'America/Lima' })

const categoryIcons: Record<string, typeof Code2> = {
  'soporte-ti': Headset,
  'desarrollo-web': Code2,
  'infraestructura-virtualizacion': Server,
  'redes-ciberseguridad': ShieldCheck,
}

export default function App({ user, onLogout, logoutBusy }: { user: AuthUser; onLogout: () => void; logoutBusy: boolean }) {
  const isAdmin = user.role === 'admin'
  const [page, setPage] = useState<'dashboard' | 'evaluation' | 'history' | 'team' | 'jobs' | 'resources' | 'reports' | 'help'>(isAdmin ? 'team' : 'dashboard')
  const [menuOpen, setMenuOpen] = useState(false)
  const menuButton = useRef<HTMLButtonElement>(null)
  const navigation = useRef<HTMLElement>(null)
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [selected, setSelected] = useState('')
  const [selectedJob, setSelectedJob] = useState('')
  const [jobs, setJobs] = useState<JobProfile[]>([])
  const [jobsLoading, setJobsLoading] = useState(false)
  const [assessment, setAssessment] = useState<Assessment | null>(null)
  const [previousEvaluationId, setPreviousEvaluationId] = useState<string | undefined>()
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [step, setStep] = useState(0)
  const [result, setResult] = useState<Evaluation | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [loadingMore, setLoadingMore] = useState(false)
  const [history, setHistory] = useState<Evaluation[]>([])
  const [busy, setBusy] = useState(true)
  const [error, setError] = useState('')
  const heading = useRef<HTMLHeadingElement>(null)

  async function loadProfiles() {
    setBusy(true); setError('')
    try { const items = await api.profiles(); setProfiles(items); setSelected(previous => items.some(item => item.id === previous) ? previous : '') } catch (e) { setError((e as Error).message) }
    finally { setBusy(false) }
  }
  useEffect(() => { void loadProfiles() }, [])
  useEffect(() => {
    let active = true
    setSelectedJob(''); setJobs([])
    if (!selected) return
    setJobsLoading(true)
    api.jobs(selected).then(value => { if (active) setJobs(value) }).catch(reason => { if (active) setError(reason.message) }).finally(() => { if (active) setJobsLoading(false) })
    return () => { active = false }
  }, [selected])
  useEffect(() => { if (assessment) heading.current?.focus() }, [step, assessment, result])
  useEffect(() => {
    if (!menuOpen) return
    navigation.current?.querySelector<HTMLButtonElement>('.nav-item.active')?.focus()
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') { setMenuOpen(false); menuButton.current?.focus() } }
    window.addEventListener('keydown', close)
    return () => window.removeEventListener('keydown', close)
  }, [menuOpen])

  async function start() {
    if (!selected || !profiles.some(profile => profile.id === selected)) return
    setBusy(true); setError(''); setResult(null)
    try { setAssessment(await api.assessment(selected, selectedJob || undefined)); setAnswers({}); setStep(0) }
    catch (e) { setError((e as Error).message) }
    finally { setBusy(false) }
  }
  async function submit() {
    if (!assessment) return
    setBusy(true); setError('')
    try { setResult(await api.submit(assessment, answers, previousEvaluationId)); setAssessment(null) }
    catch (e) { setError((e as Error).message) }
    finally { setBusy(false) }
  }
  async function openHistory() {
    setPage('history'); setBusy(true); setError('')
    try { const rows = await api.history(); setHistory(rows); setHasMore(rows.length === 20) } catch (e) { setError((e as Error).message) }
    finally { setBusy(false) }
  }
  async function loadMoreHistory() {
    setLoadingMore(true); setError('')
    try { const rows = await api.history(history.length); setHistory(value => [...value, ...rows]); setHasMore(rows.length === 20) }
    catch (e) { setError((e as Error).message) }
    finally { setLoadingMore(false) }
  }
  async function openResult(id: string) {
    setBusy(true); setError('')
    try { setResult(await api.result(id)); setAssessment(null); setPage('evaluation') }
    catch (e) { setError((e as Error).message) }
    finally { setBusy(false) }
  }
  function reset() { setPreviousEvaluationId(undefined); setAssessment(null); setResult(null); setAnswers({}); setSelectedJob(''); setStep(0); setError(''); setPage(isAdmin ? 'team' : 'evaluation') }
  async function reevaluate() {
    if (!result) return
    setBusy(true); setError('')
    try {
      const next = await api.assessment(result.profile_id, result.job_profile_id ?? undefined)
      setPreviousEvaluationId(result.id); setSelected(result.profile_id)
      setAssessment(next); setAnswers({}); setStep(0); setResult(null); setPage('evaluation')
    } catch (e) { setError((e as Error).message) }
    finally { setBusy(false) }
  }
  function exportResult() {
    if (!result) return
    const lines = ['competencia;puntaje_obtenido;nivel_requerido;brecha_puntos;brecha_relativa_porcentaje']
    for (const row of result.results) {
      const name = /^[\t\r\n]|^\s*[=+@-]/.test(row.competency_name) ? "'" + row.competency_name : row.competency_name
      const quoted = /[";\r\n]/.test(name) ? '"' + name.replaceAll('"', '""') + '"' : name
      lines.push([quoted, row.current, row.required, row.gap_points, row.gap_percent].join(';'))
    }
    const url = URL.createObjectURL(new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' }))
    const link = document.createElement('a'); link.href = url; link.download = `skillpath-evaluacion-${result.id}.csv`; link.click(); URL.revokeObjectURL(url)
  }

  const activeCompetency = assessment?.competencies[step]
  const questions = assessment?.questions.filter(q => q.competency_id === activeCompetency?.id) ?? []
  const earlierCompetencies = new Set(assessment?.competencies.slice(0, step).map(row => row.id))
  const earlierQuestions = assessment?.questions.filter(question => earlierCompetencies.has(question.competency_id)).length ?? 0
  const stepComplete = questions.length > 0 && questions.every(q => answers[q.id])
  const completed = Object.keys(answers).length

  return <div className="app-shell">
    <a href="#main-content" className="skip-link">Ir al contenido</a>
    {menuOpen && <button className="navigation-backdrop" aria-label="Cerrar menú de navegación" onClick={() => { setMenuOpen(false); menuButton.current?.focus() }} />}
    <aside id="main-navigation" ref={navigation} className={'sidebar' + (menuOpen ? ' is-open' : '')}>
      <a className="brand" aria-label="SkillPath · Inicio" href="#" onClick={e => { e.preventDefault(); setPage(isAdmin ? 'team' : 'dashboard'); setMenuOpen(false) }}><span className="brand-icon"><Layers3 size={23} /></span><span>SkillPath<span className="brand-sub">DESARROLLO DEL TALENTO</span></span></a>
      <div className="workspace-label">{isAdmin ? 'ADMINISTRACIÓN' : 'MI ESPACIO'}</div>
      <nav aria-label="Navegación principal" onClick={() => setMenuOpen(false)}>
        <button aria-label="Panel de seguimiento" className={page === 'dashboard' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('dashboard'); setError('') }}><BarChart3 size={19} /> {isAdmin ? 'Panel del equipo' : 'Mi panel'}</button>
        {isAdmin ? <button aria-label="Mi equipo" className={page === 'team' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('team'); setError('') }}><Users size={19} /> Mi equipo</button> : <button aria-label="Evaluación" className={page === 'evaluation' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('evaluation'); setError('') }}><ClipboardCheck size={19} /> Evaluación <span className="nav-dot" /></button>}
        <button aria-label="Historial" className={page === 'history' ? 'nav-item active' : 'nav-item'} onClick={() => void openHistory()}><History size={19} /> Historial</button>
        {isAdmin && <>
          <button aria-label="Puestos y competencias" className={page === 'jobs' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('jobs'); setError('') }}><BriefcaseBusiness size={19} /> Puestos</button>
          <button aria-label="Recursos de aprendizaje" className={page === 'resources' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('resources'); setError('') }}><LibraryBig size={19} /> Recursos</button>
          <button aria-label="Reportes del equipo" className={page === 'reports' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('reports'); setError('') }}><FileBarChart2 size={19} /> Reportes</button>
        </>}
        <button aria-label="Ayuda y manual" className={page === 'help' ? 'nav-item active' : 'nav-item'} onClick={() => { setPage('help'); setError('') }}><CircleHelp size={19} /> Ayuda y manual</button>
      </nav>
      <div className="sidebar-note"><Sprout size={29} /><h3>{isAdmin ? 'Acompaña el crecimiento.' : 'Tu siguiente paso empieza aquí.'}</h3><p>{isAdmin ? 'Consulta los diagnósticos y la evolución de tu equipo.' : 'Identifica qué fortalecer para avanzar en tu desarrollo profesional.'}</p>{user.administrator && <p><strong>A cargo de {user.administrator.name}</strong></p>}</div>
      <div className="sidebar-bottom"><span className="company-avatar">iC</span><div>iCloudFlex<small>Área de Tecnología</small></div></div>
    </aside>

    <div className="main-shell">
      <header className="topbar"><button ref={menuButton} className="mobile-menu-button" aria-label={menuOpen ? 'Cerrar menú' : 'Abrir menú'} aria-expanded={menuOpen} aria-controls="main-navigation" onClick={() => setMenuOpen(value => !value)}>{menuOpen ? <X size={22} /> : <Menu size={22} />}</button><div className="page-breadcrumb"><span className="breadcrumb">{isAdmin ? 'Mi equipo' : 'Mi desarrollo'}</span><span className="breadcrumb-separator">/</span><strong>{page === 'help' ? 'Ayuda y manual' : page === 'jobs' ? 'Puestos y competencias' : page === 'resources' ? 'Recursos de aprendizaje' : page === 'reports' ? 'Reportes' : page === 'team' ? 'Usuarios asignados' : page === 'dashboard' ? 'Panel de seguimiento' : page === 'history' ? 'Historial' : 'Evaluación de competencias'}</strong></div><div className="topbar-right"><span className="demo-label">Demostración · datos de ejemplo</span><div className="session-user"><strong>{user.name}</strong><small>{isAdmin ? 'Administrador' : 'Usuario'}</small></div><button className="logout-button" aria-label="Cerrar sesión" disabled={logoutBusy} onClick={onLogout}><LogOut size={18} /><span>Salir</span></button></div></header>
      <main id="main-content" tabIndex={-1}>
        {error && <div className="error-banner" role="alert"><span>{error}</span><button aria-label="Cerrar mensaje" onClick={() => setError('')}><X size={18} /></button></div>}

        {page === 'help' ? <HelpPanel isAdmin={isAdmin} onStart={() => isAdmin ? setPage('team') : reset()} /> : page === 'jobs' && isAdmin ? <JobManager profiles={profiles} /> : page === 'resources' && isAdmin ? <ResourceManager /> : page === 'reports' && isAdmin ? <Reports profiles={profiles} onOpenResult={id => void openResult(id)} /> : page === 'team' ? <TeamPanel onOpenResult={id => void openResult(id)} /> : page === 'dashboard' ? <Dashboard isAdmin={isAdmin} userName={user.name} profiles={profiles} onNewEvaluation={reset} onOpenResult={id => void openResult(id)} /> : page === 'history' ? <>
          <div className="page-heading"><div><span className="eyebrow">TU RECORRIDO</span><h1>Historial de evaluaciones</h1><p>Vuelve a consultar los diagnósticos guardados.</p></div>{!isAdmin && <button className="primary" onClick={reset}>Nueva evaluación <ArrowRight size={18} /></button>}</div>
          <section className="history-list" aria-label="Evaluaciones guardadas">
            {busy ? <div className="loading"><LoaderCircle className="spin" /> Cargando historial…</div> : history.length === 0 ? <div className="empty"><History size={36} /><h2>Aún no hay evaluaciones</h2><p>Completa tu primer diagnóstico para verlo aquí.</p></div> : history.map(item => <button className="history-row" key={item.id} onClick={() => void openResult(item.id)}><span className="history-icon"><ClipboardCheck size={22} /></span><span className="history-title"><strong>{item.profile_name}</strong><small>{isAdmin && item.user_name + ' · '}{date(item.created_at)}{!item.category_active && ' · Perfil anterior'}</small></span><span className="history-score">{number(item.overall_score)}<small> / 100</small></span><span className="history-gap">{item.competencies_with_gap} por fortalecer</span><ArrowRight size={19} /></button>)}
          </section>{hasMore && <button className="secondary history-more" disabled={loadingMore} onClick={() => void loadMoreHistory()}>{loadingMore ? 'Cargando…' : 'Cargar más evaluaciones'}</button>}<p className="quiet-note">{isAdmin ? 'Historial de tus usuarios asignados.' : 'Historial de tu cuenta.'} Se carga en bloques de 20 evaluaciones.</p>
        </> : result ? <>
          <div className="page-heading"><div><span className="eyebrow">DIAGNÓSTICO COMPLETADO</span><h1>{isAdmin ? 'Diagnóstico de ' + result.user_name : 'Este es tu punto de partida.'}</h1><p>{result.profile_name}{result.job_profile_name && ' · ' + result.job_profile_name} <span className="middle-dot">·</span> {date(result.created_at)}</p></div><button className="secondary" onClick={exportResult}><ArrowDownToLine size={17} /> Exportar resultados</button></div>
          {!result.category_active && <section className="archived-diagnosis" aria-label="Diagnóstico anterior"><History size={22} /><div><strong>Diagnóstico de la versión anterior</strong><p>Este perfil se conserva con sus resultados y su avance originales. Para un nuevo diagnóstico, elige una de las cuatro categorías actuales.</p></div></section>}
          {result.comparison && <section className="reevaluation-summary" aria-label="Comparación con la evaluación anterior"><div><span className="eyebrow">REEVALUACIÓN VINCULADA</span><h2>{result.comparison.compatible ? 'Tu resultado, antes y ahora.' : 'Los instrumentos de evaluación cambiaron.'}</h2><p>{result.comparison.compatible ? 'Puntuación anterior: ' + number(result.comparison.previous_score) + '/100 · actual: ' + number(result.overall_score) + '/100 · cambio: ' + ((result.comparison.score_delta ?? 0) > 0 ? '+' : '') + number(result.comparison.score_delta ?? 0) + ' puntos.' : 'Se conservan ambos diagnósticos; las versiones o requisitos distintos impiden compararlos directamente.'}</p>{result.comparison.compatible && <p>Competencias con brecha: {result.comparison.previous_gap_count} antes · {result.comparison.current_gap_count} ahora.</p>}</div><button className="text-button" onClick={() => void openResult(result.previous_evaluation_id!)}>Ver diagnóstico anterior <ArrowRight size={16} /></button></section>}
          <div className="result-summary"><div className="score-circle"><strong>{number(result.overall_score)}</strong><span>de 100</span></div><div className="result-summary-text"><h2>Enfoca tu aprendizaje donde más lo necesitas.</h2><p>Tu puntuación refleja los aciertos ponderados de esta evaluación.</p><div className="result-tags"><span><CheckCircle2 size={16} /> {result.competencies_achieved} con objetivo alcanzado</span><span><Target size={16} /> {result.competencies_with_gap} por fortalecer</span></div></div><Sprout className="summary-sprout" size={92} strokeWidth={1.1} /></div>
          <div className="section-heading"><div><h2>Resultados por competencia</h2><p>Compara tu puntuación con el objetivo de la categoría.</p></div><span className="legend"><i /> Obtenido <i className="legend-target" /> Requerido</span></div>
          <div className="competency-results">{result.results.map(r => <article className="result-card" key={r.competency_id}><div className="result-card-top"><h3>{r.competency_name}</h3><span className={r.achieved ? 'status achieved' : 'status strengthen'}>{r.achieved ? 'Objetivo alcanzado' : 'Por fortalecer'}</span></div><div className="result-numbers"><strong>{number(r.current)}<small> / 100</small></strong><span>Objetivo: {r.required}</span></div><div className="score-track" aria-label={`Obtenido ${r.current} de 100. Requerido ${r.required}.`}><div style={{ width: `${r.current}%` }} /><span style={{ left: `${r.required}%` }} /></div><div className="gap-detail"><span>Brecha frente al objetivo</span><strong>{number(r.gap_points)} puntos <small>({number(r.gap_percent)} % relativo)</small></strong></div></article>)}</div>
          <div className="explanation"><BookOpen size={21} /><div><strong>¿Cómo interpretar la brecha?</strong><p>Es la diferencia entre el nivel requerido y tu puntuación. Una brecha de 0 indica que alcanzaste el objetivo en este cuestionario. Completar formación y volver a evaluarte permitirá observar tu avance.</p></div></div>
          <LearningPathPanel key={result.id} evaluationId={result.id} canEdit={!isAdmin} />
          <div className="bottom-actions"><button className="text-button" onClick={() => void openHistory()}><History size={17} /> Ver historial</button>{!isAdmin && <div className="result-action-group"><button className="secondary" disabled={busy || !result.category_active} onClick={() => void reevaluate()}>Reevaluar esta categoría</button><button className="primary" onClick={reset}>Realizar otra evaluación <ArrowRight size={18} /></button></div>}</div>
        </> : assessment && activeCompetency ? <>
          <div className="assessment-top"><button className="text-button" disabled={busy} onClick={reset}><ArrowLeft size={17} /> Volver al inicio</button><span>{assessment.profile_name}{assessment.job_profile_name && ' · ' + assessment.job_profile_name}</span></div>
          <div className="assessment-heading"><span className="eyebrow">{previousEvaluationId ? 'REEVALUACIÓN · ' : ''}PASO {step + 1} DE {assessment.competencies.length}</span><h1 ref={heading} tabIndex={-1}>{activeCompetency.name}</h1><p>Elige la respuesta que consideres correcta para cada pregunta.</p></div>
          <div className="assessment-progress"><div className="progress-track"><div style={{ width: `${100 * completed / assessment.questions.length}%` }} /></div><span>{completed} de {assessment.questions.length} respuestas</span></div>
          <form onSubmit={e => { e.preventDefault(); if (stepComplete && !busy) { if (step < assessment.competencies.length - 1) setStep(step + 1); else void submit() } }}>
            <div className="question-list">{questions.map((q, i) => <fieldset className="question-card" key={q.id}><legend><span className="question-number">{earlierQuestions + i + 1}</span>{q.text}</legend><div className="options">{q.options.map(option => <label className={answers[q.id] === option.id ? 'option selected' : 'option'} key={option.id}><input type="radio" name={q.id} value={option.id} checked={answers[q.id] === option.id} disabled={busy} onChange={() => setAnswers(previous => ({ ...previous, [q.id]: option.id }))} /><span>{option.text}</span>{answers[q.id] === option.id && <Check size={17} />}</label>)}</div></fieldset>)}</div>
            <div className="assessment-actions"><button className="secondary" type="button" disabled={step === 0 || busy} onClick={() => setStep(step - 1)}><ArrowLeft size={17} /> Anterior</button><span>{!stepComplete ? 'Responde las preguntas de este paso para continuar.' : 'Todo listo para continuar.'}</span><button className="primary" disabled={!stepComplete || busy} type="submit">{busy ? <><LoaderCircle className="spin" size={18} /> Guardando…</> : step < assessment.competencies.length - 1 ? <>Continuar <ArrowRight size={18} /></> : <>Ver mi diagnóstico <BarChart3 size={18} /></>}</button></div>
          </form>
        </> : <>
          <div className="page-heading"><div><span className="eyebrow">EVALUACIÓN DE COMPETENCIAS</span><h1>Conoce tu punto de partida.</h1><p>Descubre qué competencias fortalecer en las áreas de servicio de iCloudFlex.</p></div><span className="step-pill"><span>01</span> Diagnóstico inicial</span></div>
          <section className="intro-banner"><div><span className="banner-label">UN APRENDIZAJE QUE PARTE DE TI</span><h2>Cuatro categorías.<br />Tu propio camino.</h2><p>Elige tu área de servicio, evalúa tus conocimientos y construye una ruta para las competencias que necesitas fortalecer.</p></div><div className="path-art" aria-hidden="true"><div className="art-grid" /><div className="art-node art-node-one"><Code2 size={27} /></div><div className="art-node art-node-two"><Target size={32} /></div><div className="art-node art-node-three"><Check size={28} /></div><div className="art-line" /><span className="art-caption">TU PRÓXIMO PASO</span></div></section>
          <div className="intro-columns"><section className="profile-section"><div className="section-heading"><div><h2>Selecciona tu categoría</h2><p>Cada categoría tiene su propio cuestionario y recursos de aprendizaje.</p></div></div>
            {busy ? <div className="loading"><LoaderCircle className="spin" /> Cargando categorías…</div> : profiles.length === 0 ? <button className="secondary" onClick={() => void loadProfiles()}>Volver a cargar categorías</button> : <div className="profile-options category-options" role="radiogroup" aria-label="Categoría de servicio">{profiles.map(profile => {
              const Icon = categoryIcons[profile.id] ?? Code2
              return <label className={selected === profile.id ? 'profile-option category-option selected' : 'profile-option category-option'} key={profile.id}>
                <span className="profile-icon"><Icon size={25} /></span>
                <span className="profile-copy"><strong>{profile.name}</strong><small>{profile.description}</small>
                  <span className="category-competencies">{profile.competencies.map(competency => <span key={competency.id}>{competency.name}</span>)}</span>
                  <span className="category-count">{profile.competency_count} competencias · {profile.question_count} preguntas</span>
                </span>
                <input type="radio" name="profile" value={profile.id} checked={selected === profile.id} onChange={() => setSelected(profile.id)} />
              </label>
            })}</div>}
            {selected && <div className="job-selector"><label htmlFor="assessment-job">Puesto objetivo (opcional)</label><select id="assessment-job" value={selectedJob} disabled={jobsLoading || busy} onChange={event => setSelectedJob(event.target.value)}><option value="">Diagnóstico general de la categoría</option>{jobs.map(job => <option key={job.id} value={job.id}>{job.name}</option>)}</select><p>{jobsLoading ? 'Cargando puestos…' : selectedJob ? 'El diagnóstico utilizará las competencias y niveles del puesto seleccionado.' : 'Puedes evaluar la categoría general o elegir un puesto registrado por el administrador.'}</p></div>}
            <div className="start-section"><button className="primary" disabled={busy || jobsLoading || !selected || profiles.length === 0} onClick={() => void start()}>Comenzar evaluación <ArrowRight size={18} /></button></div>
          </section><aside className="how-it-works"><h3>¿Cómo funciona?</h3><ol><li><span>1</span><div><strong>Evalúa tus conocimientos</strong><p>Responde las preguntas de la categoría o del puesto que selecciones.</p></div></li><li><span>2</span><div><strong>Descubre tus brechas</strong><p>Compara tu puntuación con el nivel requerido para la categoría.</p></div></li><li><span>3</span><div><strong>Sigue tu ruta de aprendizaje</strong><p>Accede a recursos, registra tus actividades y compara una nueva evaluación.</p></div></li></ol><div className="demo-note"><BookOpen size={17} /><p>Las cuatro categorías corresponden a las áreas indicadas. Las preguntas, niveles y recursos son de demostración, pendientes de validación.</p></div></aside></div>
        </>}
        <footer className="footer"><span>SkillPath <span className="middle-dot">·</span> Desarrollo del talento TI</span><span>Capstone Project 2026</span></footer>
      </main>
    </div>
  </div>
}

