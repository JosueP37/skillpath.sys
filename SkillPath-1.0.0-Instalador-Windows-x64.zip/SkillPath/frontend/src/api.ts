export type Profile = { id: string; name: string; description: string; competency_count: number; question_count: number; competencies: { id: string; name: string; required: number }[] }
export type Competency = { id: string; name: string; required: number }
export type Question = { id: string; competency_id: string; text: string; weight: number; options: { id: string; text: string }[] }
export type Assessment = { job_profile_id?: string | null; job_profile_name?: string | null; profile_id: string; profile_name: string; version: string; competencies: Competency[]; questions: Question[] }
export type CompetencyResult = { competency_id: string; competency_name: string; current: number; required: number; gap_points: number; gap_percent: number; achieved: boolean }
export type LearningResource = { id: string; title: string; provider: string; level: string; estimated_minutes: number; links: { label: string; url: string }[]; practice: string }
export type LearningPath = {
  id: string; evaluation_id: string; created_at: string; profile_name: string;
  rules_version: string; catalog_version: string; status: 'no_gaps' | 'ready' | 'partial' | 'uncovered';
  items: { order: number; competency_id: string; competency_name: string; role: 'prerequisite' | 'main'; reason: string; resource: LearningResource }[];
  uncovered_competencies: { competency_id: string; competency_name: string; reason: string }[];
  gap_count: number; covered_gap_count: number; estimated_minutes: number; explanation: string; catalog_note: string;
}
export type Evaluation = { job_profile_id?: string | null; job_profile_name?: string | null; user_id: string; user_name: string; category_active: boolean; id: string; created_at: string; profile_id: string; profile_name: string; results: CompetencyResult[]; overall_score: number; competencies_achieved: number; competencies_with_gap: number; calculation_ms: number; assessment_version: string; previous_evaluation_id?: string | null; comparison?: EvaluationComparison | null }

let sessionCsrf = ''
export const setSession = (csrf: string) => { sessionCsrf = csrf }

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  let response: Response
  try {
    const headers = new Headers(options?.headers)
    if (options?.method && !['GET', 'HEAD'].includes(options.method) && sessionCsrf) headers.set('X-CSRF-Token', sessionCsrf)
    response = await fetch('/api' + path, { ...options, credentials: 'same-origin', headers })
  }
  catch { throw new Error('No pudimos conectar con el servicio. Revisa que esté iniciado y vuelve a intentar.') }
  const payload = await response.json().catch(() => null)
  if (!response.ok) {
    if (response.status === 401 && !path.startsWith('/auth/')) window.dispatchEvent(new Event('skillpath-session-expired'))
    const message = typeof payload?.detail === 'string' ? payload.detail : response.status === 422 ? 'Revisa los datos ingresados y vuelve a intentar.' : 'No se pudo completar la operación. Vuelve a intentar.'
    throw Object.assign(new Error(message), { status: response.status })
  }
  return payload as T
}

export const api = {
  jobs: (categoryId = '', includeInactive = false) => request<JobProfile[]>('/job-profiles?' + new URLSearchParams({ ...(categoryId ? { category_id: categoryId } : {}), ...(includeInactive ? { include_inactive: 'true' } : {}) })),
  job: (id: string) => request<JobProfile>('/job-profiles/' + encodeURIComponent(id)),
  saveJob: (job: JobInput, id?: string, revision?: number) => request<JobProfile>('/job-profiles' + (id ? '/' + encodeURIComponent(id) : ''), { method: id ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...job, ...(id ? { expected_revision: revision } : {}) }) }),
  competencyBank: () => request<CompetencyBank>('/admin/competencies'),
  saveCompetency: (competency: CompetencyInput, revision: number, id?: string) => request<CompetencyBank>('/admin/competencies' + (id ? '/' + encodeURIComponent(id) : ''), {
    method: id ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...competency, expected_revision: revision }),
  }),
  resources: () => request<ResourceCatalog>('/admin/resources'),
  saveResource: (resource: ManagedResource, revision: number, note: string, id?: string) => request<ResourceCatalog>('/admin/resources' + (id ? '/' + encodeURIComponent(id) : ''), { method: id ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ resource, expected_revision: revision, note }) }),
  report: (filters: ReportFilters) => request<TeamReport>('/reports/team?' + reportQuery(filters)),
  exportReport: downloadReport,
  me: () => request<AuthSession>('/auth/me'),
  administrators: () => request<Administrator[]>('/auth/administrators'),
  login: (email: string, password: string) => request<AuthSession>('/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) }),
  register: (name: string, email: string, password: string, administrator_id: string) => request<AuthSession>('/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email, password, administrator_id }) }),
  logout: () => request<void>('/auth/logout', { method: 'POST' }),
  team: () => request<{ members: TeamMember[] }>('/team'),
  member: (id: string) => request<MemberDetail>('/team/' + encodeURIComponent(id)),
  profiles: () => request<Profile[]>('/profiles'),
  assessment: (profileId: string, jobProfileId?: string) => request<Assessment>('/profiles/' + encodeURIComponent(profileId) + '/assessment' + (jobProfileId ? '?job_profile_id=' + encodeURIComponent(jobProfileId) : '')),
  submit: (assessment: Assessment, answers: Record<string, string>, previousEvaluationId?: string) => request<Evaluation>('/evaluations', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ previous_evaluation_id: previousEvaluationId ?? null, job_profile_id: assessment.job_profile_id ?? null, profile_id: assessment.profile_id, assessment_version: assessment.version, answers: Object.entries(answers).map(([question_id, option_id]) => ({ question_id, option_id })) }),
  }),
  learningPath: (id: string) => request<LearningPath>("/evaluations/" + encodeURIComponent(id) + "/learning-path", { method: 'POST' }),
  progress: (id: string) => request<LearningProgress>('/evaluations/' + encodeURIComponent(id) + '/progress'),
  updateProgress: (id: string, resourceId: string, status: ActivityState, note: string, version: number, evidenceUrl: string | null) => request<LearningProgress>('/evaluations/' + encodeURIComponent(id) + '/progress/' + encodeURIComponent(resourceId), {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, note, evidence_url: evidenceUrl, expected_version: version }),
  }),
  reviewProgress: (id: string, resourceId: string, status: ReviewStatus, feedback: string, version: number) => request<LearningProgress>('/evaluations/' + encodeURIComponent(id) + '/progress/' + encodeURIComponent(resourceId) + '/review', {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, feedback, expected_version: version }),
  }),
  dashboard: (profileId: string) => request<DashboardData>('/dashboard' + (profileId ? '?profile_id=' + encodeURIComponent(profileId) : '')),
  history: (offset = 0, userId = '') => request<Evaluation[]>('/evaluations?offset=' + offset + (userId ? '&user_id=' + encodeURIComponent(userId) : '')),
  result: (id: string) => request<Evaluation>(`/evaluations/${encodeURIComponent(id)}`),
}


export type ActivityState = 'pending' | 'in_progress' | 'completed'
export type ReviewStatus = 'approved' | 'changes_requested'
export type ProgressItem = {
  resource_id: string; title: string; estimated_minutes: number; status: ActivityState; note: string;
  evidence_url: string | null; updated_at: string | null;
  review: { status: ReviewStatus; feedback: string; reviewer_name: string; reviewed_at: string } | null;
}
export type LearningProgress = {
  evaluation_id: string; path_id: string; version: number; updated_at: string | null;
  total_activities: number; completed_activities: number; approved_activities: number; in_progress_activities: number; pending_activities: number;
  completion_percent: number | null; completed_minutes: number; remaining_minutes: number;
  status: 'no_activities' | ActivityState; items: ProgressItem[];
  events: { actor_user_id: string | null; actor_name: string | null; id: string; resource_id: string; title: string; previous_status: ActivityState; status: ActivityState; review_status: ReviewStatus | null; note: string; created_at: string }[];
  event_count: number; retained_event_limit: number;
}
export type DashboardEvaluation = {
  id: string; user_name: string; profile_name: string; created_at: string; overall_score: number; competencies_with_gap: number;
  path_status: LearningPath['status'] | null; progress_status: LearningProgress['status'] | null;
  completion_percent: number | null; completed_activities: number; total_activities: number;
}
export type DashboardData = {
  generated_at: string; mode: string; filter: { profile_id: string | null };
  metrics: {
    evaluation_count: number; archived_evaluation_count: number; average_score: number | null; evaluations_with_gaps: number;
    path_count: number; evaluations_without_path: number; completed_routes: number; in_progress_routes: number;
    pending_routes: number; routes_without_activities: number; total_activities: number;
    completed_activities: number; in_progress_activities: number; pending_activities: number;
    completion_percent: number | null; completed_minutes: number; remaining_minutes: number; linked_reevaluations: number;
  };
  competencies: { competency_id: string; competency_name: string; evaluation_count: number; gap_count: number; average_score: number; average_gap_percent: number }[];
  recent_evaluations: DashboardEvaluation[];
  definitions: { scope: string; completion: string; score: string; learning: string };
}
export type EvaluationComparison = {
  compatible: boolean; previous_score: number; score_delta: number | null;
  previous_gap_count: number; current_gap_count: number;
  competencies: { competency_id: string; competency_name: string; previous_score: number; current_score: number; score_delta: number; previous_gap_points: number; current_gap_points: number }[];
}

export type Administrator = { id: string; name: string }
export type AuthUser = { id: string; name: string; email: string; role: 'admin' | 'user'; administrator: Administrator | null }
export type AuthSession = { user: AuthUser; csrf_token: string }
export type TeamMember = AuthUser & { evaluation_count: number; latest_score: number | null; latest_category: string | null; latest_at: string | null; completed_activities: number; total_activities: number; completion_percent: number | null }
export type MemberDetail = {
  member: TeamMember; definition: string;
  evolution: { profile_id: string; profile_name: string; job_profile_name?: string | null; assessment_version: string; algorithm_version: string; evaluation_count: number; first_score: number; latest_score: number; score_delta: number | null; first_gap_count: number; latest_gap_count: number; points: { id: string; created_at: string; score: number; gap_count: number }[]; competencies: { id: string; name: string; first_score: number; latest_score: number; score_delta: number }[] }[]
}

export type JobInput = { category_id: string; name: string; description: string; active: boolean; competencies: { competency_id: string; required: number; criticality: number }[] }
export type JobProfile = JobInput & { id: string; revision: number; updated_at: string; updated_by: string; history?: { revision: number; at: string; actor_id: string; actor_name: string; configuration: JobInput }[] }
export type BankCompetency = { id: string; category_id: string; name: string; questions: (Question & { correct: string })[] }
export type CompetencyBank = { revision: number; competencies: BankCompetency[] }
export type QuestionInput = { id?: string; text: string; weight: number; options: string[]; correct_index: number }
export type CompetencyInput = { category_id: string; name: string; questions: QuestionInput[] }
export type ManagedResource = LearningResource & { competency_id: string; entry_score: number; target_score: number; prerequisite_ids: string[]; approved: boolean }
export type ResourceCatalog = { revision: number; version: string; resources: ManagedResource[]; updated_at: string; history: { revision: number; actor_name: string; note: string; at: string; resource_id: string }[] }
export type ReportFilters = { profile_id?: string; user_id?: string; date_from?: string; date_to?: string }
export type TeamReport = {
  generated_at: string; administrator: string; mode: string; filters: ReportFilters & { timezone: string };
  summary: { user_count: number; evaluated_users: number; evaluation_count: number; series_count: number; path_count: number; total_activities: number; completed_activities: number; completion_percent: number | null };
  rows: { user_id: string; user_name: string; email: string; profile_id: string | null; profile_name: string | null; job_profile_name: string | null; assessment_version: string | null; evaluation_count: number; latest_evaluation_id: string | null; first_score: number | null; latest_score: number | null; score_delta: number | null; competencies_with_gap: number | null; competencies_achieved: number | null; gaps: { competency_name: string; gap_points: number }[]; achieved: string[]; path_count: number; total_activities: number; completed_activities: number; completion_percent: number | null; status: string; latest_at: string | null }[];
  definitions: string[];
}
function reportQuery(filters: ReportFilters) {
  return new URLSearchParams(Object.entries(filters).filter(([, value]) => !!value)).toString()
}
async function downloadReport(filters: ReportFilters) {
  const response = await fetch('/api/reports/team.csv?' + reportQuery(filters), { credentials: 'same-origin' })
  if (!response.ok) {
    if (response.status === 401) window.dispatchEvent(new Event('skillpath-session-expired'))
    const payload = await response.json().catch(() => null)
    throw new Error(typeof payload?.detail === 'string' ? payload.detail : 'No se pudo exportar el reporte.')
  }
  const url = URL.createObjectURL(await response.blob())
  const link = document.createElement('a')
  link.href = url; link.download = 'skillpath-reporte-equipo.csv'; link.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
