"""Apagado ordenado de la instancia local usada exclusivamente por la demo."""
from pymongo import MongoClient
from pymongo.errors import AutoReconnect

client = MongoClient('mongodb://127.0.0.1:27018', serverSelectionTimeoutMS=3000)
try:
    client.admin.command({'shutdown': 1})
except AutoReconnect:
    # El servidor cierra la conexión como parte del apagado.
    pass
finally:
    client.close()
