"""RF-03: indicadores sobre registros persistidos de la demo local."""
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Query, Request
from pymongo import DESCENDING
from pymongo.errors import PyMongoError

from .catalog import PROFILES
from .auth import current_user, scoped_user_ids
from .progress import iso, summarize

router = APIRouter(prefix='/api/dashboard', tags=['Panel de seguimiento'])


@router.get('')
def dashboard(request: Request, profile_id: str | None = Query(default=None, max_length=50), user_id: str | None = None):
    user = current_user(request)
    owner_ids = scoped_user_ids(request.app.state.db, user, user_id)
    if profile_id is not None and profile_id not in PROFILES:
        raise HTTPException(422, 'La categoría seleccionada no existe.')
    try:
        db = request.app.state.db
        query = {'profile_id': profile_id} if profile_id else {'profile_id': {'$in': list(PROFILES)}}
        query['user_id'] = {'$in': owner_ids}
        archived_count = db.evaluations.count_documents({'user_id': {'$in': owner_ids}, 'profile_id': {'$nin': list(PROFILES)}})
        evaluations = list(db.evaluations.find(query, {
            'answers': 0, 'scoring_key_snapshot': 0, 'assessment_snapshot': 0,
        }).sort([('created_at', DESCENDING), ('_id', DESCENDING)]))
        ids = [doc['_id'] for doc in evaluations]
        paths = list(db.learning_paths.find({'evaluation_id': {'$in': ids}}))
        progress_docs = {
            doc['evaluation_id']: doc
            for doc in db.learning_progress.find({'evaluation_id': {'$in': ids}}, {'events': 0})
        }
    except PyMongoError:
        raise HTTPException(503, 'No se pudo consultar el panel. Intenta nuevamente.')
    paths_by_evaluation = {path['evaluation_id']: path for path in paths}
    summaries = {path['evaluation_id']: summarize(path, progress_docs.get(path['evaluation_id'])) for path in paths}
    competencies = {}
    for evaluation in evaluations:
        for row in evaluation['results']:
            aggregate = competencies.setdefault(row['competency_id'], {
                'competency_id': row['competency_id'], 'competency_name': row['competency_name'],
                'evaluation_count': 0, 'gap_count': 0, 'score_sum': 0, 'gap_sum': 0,
            })
            aggregate['evaluation_count'] += 1
            aggregate['gap_count'] += int(row['gap_points'] > 0)
            aggregate['score_sum'] += row['current']
            aggregate['gap_sum'] += row['gap_percent']
    competency_rows = [{
        'competency_id': row['competency_id'], 'competency_name': row['competency_name'],
        'evaluation_count': row['evaluation_count'], 'gap_count': row['gap_count'],
        'average_score': round(row['score_sum'] / row['evaluation_count'], 2),
        'average_gap_percent': round(row['gap_sum'] / row['evaluation_count'], 2),
    } for row in competencies.values()]
    competency_rows.sort(key=lambda row: (-row['average_gap_percent'], row['competency_id']))
    total = sum(row['total_activities'] for row in summaries.values())
    completed = sum(row['completed_activities'] for row in summaries.values())
    started = sum(row['in_progress_activities'] for row in summaries.values())
    recent = []
    for evaluation in evaluations[:8]:
        progress = summaries.get(evaluation['_id'])
        path = paths_by_evaluation.get(evaluation['_id'])
        recent.append({
            'id': evaluation['_id'], 'profile_name': evaluation['profile_name'], 'user_name': evaluation.get('user_name'),
            'created_at': iso(evaluation['created_at']), 'overall_score': evaluation['overall_score'],
            'competencies_with_gap': evaluation['competencies_with_gap'],
            'path_status': path['status'] if path else None,
            'progress_status': progress['status'] if progress else None,
            'completion_percent': progress['completion_percent'] if progress else None,
            'completed_activities': progress['completed_activities'] if progress else 0,
            'total_activities': progress['total_activities'] if progress else 0,
        })
    return {
        'generated_at': iso(datetime.now(timezone.utc)), 'mode': 'demo',
        'filter': {'profile_id': profile_id, 'user_id': user_id}, 'scope': 'team' if user['role'] == 'admin' else 'self', 'assigned_user_count': len(owner_ids),
        'metrics': {
            'evaluation_count': len(evaluations),
            'archived_evaluation_count': archived_count,
            'average_score': round(sum(doc['overall_score'] for doc in evaluations) / len(evaluations), 2) if evaluations else None,
            'evaluations_with_gaps': sum(doc['competencies_with_gap'] > 0 for doc in evaluations),
            'path_count': len(paths),
            'evaluations_without_path': len(evaluations) - len(paths),
            'completed_routes': sum(row['status'] == 'completed' for row in summaries.values()),
            'in_progress_routes': sum(row['status'] == 'in_progress' for row in summaries.values()),
            'pending_routes': sum(row['status'] == 'pending' for row in summaries.values()),
            'routes_without_activities': sum(row['status'] == 'no_activities' for row in summaries.values()),
            'total_activities': total, 'completed_activities': completed,
            'in_progress_activities': started, 'pending_activities': total - completed - started,
            'completion_percent': round(100 * completed / total, 2) if total else None,
            'completed_minutes': sum(row['completed_minutes'] for row in summaries.values()),
            'remaining_minutes': sum(row['remaining_minutes'] for row in summaries.values()),
            'linked_reevaluations': sum(doc.get('previous_evaluation_id') is not None for doc in evaluations),
        },
        'competencies': competency_rows, 'recent_evaluations': recent,
        'definitions': {
            'scope': 'Indicadores sobre todos los diagnósticos de tus usuarios asignados.' if user['role'] == 'admin' else 'Indicadores sobre todos los diagnósticos de tu cuenta.',
            'completion': 'Actividades completadas / actividades asignadas × 100. Sin actividades asignadas, el porcentaje no aplica.',
            'score': 'Promedio de las puntuaciones de las evaluaciones filtradas, sobre 100. Cada diagnóstico conserva los requisitos de su categoría.',
            'learning': 'El avance es declarado en la demo. La nota de práctica no ha sido validada por jefatura y completar recursos no demuestra cierre de brechas.',
        },
    }
