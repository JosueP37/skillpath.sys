"""RF-05: catálogo persistente de recursos, con asociación y versiones."""
from copy import deepcopy
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator, HttpUrl
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError
from .auth import current_user, require_role
from .competencies import competency_entries
from .learning_catalog import RESOURCES, CATALOG_VERSION

def iso(value):
    return value.replace(tzinfo=timezone.utc).isoformat(timespec='milliseconds') if value else None

router = APIRouter(prefix='/api/admin/resources', tags=['Catálogo de recursos'])


class Link(BaseModel):
    model_config = ConfigDict(extra='forbid')
    label: str = Field(min_length=1, max_length=100)
    url: str = Field(min_length=8, max_length=2000)

    @field_validator('url')
    @classmethod
    def safe_url(cls, value):
        parsed = HttpUrl(value)
        if parsed.username or parsed.password:
            raise ValueError('El enlace debe ser una URL HTTP/HTTPS sin credenciales.')
        return str(parsed)

    @field_validator('label')
    @classmethod
    def meaningful_label(cls, value):
        if not value.strip():
            raise ValueError('Ingresa una etiqueta para el enlace.')
        return value.strip()


class ResourceInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    id: str = Field(pattern=r'^[a-z0-9][a-z0-9-]{1,49}$')
    competency_id: str = Field(min_length=1, max_length=50)
    title: str = Field(min_length=3, max_length=160)
    provider: str = Field(min_length=2, max_length=100)
    level: str = Field(min_length=2, max_length=60)
    estimated_minutes: int = Field(ge=1, le=10080, strict=True)
    entry_score: int = Field(ge=0, le=99, strict=True)
    target_score: int = Field(ge=1, le=100, strict=True)
    prerequisite_ids: list[str] = Field(max_length=10)
    approved: bool = Field(strict=True)
    links: list[Link] = Field(min_length=1, max_length=6)
    practice: str = Field(min_length=5, max_length=2000)

    @field_validator('title', 'provider', 'level', 'practice')
    @classmethod
    def trim(cls, value):
        return value.strip()


class ResourceChange(BaseModel):
    model_config = ConfigDict(extra='forbid')
    expected_revision: int = Field(ge=1, strict=True)
    resource: ResourceInput
    note: str = Field(min_length=5, max_length=500)

    @field_validator('note')
    @classmethod
    def valid_note(cls, value):
        if len(value.strip()) < 5:
            raise ValueError('Describe el motivo del cambio.')
        return value.strip()


def resource_catalog(db):
    doc = db.resource_catalog.find_one({'_id': 'current'})
    if doc:
        return doc
    initial = {'_id': 'current', 'revision': 1, 'version': CATALOG_VERSION, 'resources': deepcopy(RESOURCES), 'updated_at': datetime.now(timezone.utc), 'history': []}
    try:
        db.resource_catalog.insert_one(initial)
        return initial
    except DuplicateKeyError:
        return db.resource_catalog.find_one({'_id': 'current'})


def view(doc):
    return {'revision': doc['revision'], 'version': doc['version'], 'resources': doc['resources'], 'updated_at': iso(doc['updated_at']), 'history': [{**event, 'at': iso(event['at'])} for event in reversed(doc.get('history', []))]}


def validate_catalog(resources, competency_ids):
    catalog = {row['id']: row for row in resources}
    if len(catalog) != len(resources):
        raise HTTPException(422, 'El identificador del recurso está repetido.')
    for row in resources:
        if row['competency_id'] not in competency_ids or row['entry_score'] >= row['target_score'] or not all(row[key].strip() for key in ['title', 'provider', 'level', 'practice']):
            raise HTTPException(422, 'Verifica la competencia, los textos y los niveles de entrada/objetivo.')
        dependencies = row['prerequisite_ids']
        if len(dependencies) != len(set(dependencies)):
            raise HTTPException(422, 'Hay prerrequisitos repetidos.')
        for key in dependencies:
            dependency = catalog.get(key)
            if not dependency or dependency['competency_id'] != row['competency_id'] or dependency['target_score'] < row['entry_score']:
                raise HTTPException(422, 'Cada prerrequisito debe existir, ser de la misma competencia y cubrir el nivel de entrada.')
    def visit(key, visiting):
        if key in visiting:
            raise HTTPException(422, 'Los prerrequisitos no pueden formar ciclos.')
        for dependency in catalog[key]['prerequisite_ids']:
            visit(dependency, visiting | {key})
    for key in catalog:
        visit(key, set())


@router.get('')
def get_resources(request: Request):
    user = current_user(request)
    require_role(user, 'admin')
    return view(resource_catalog(request.app.state.db))


def save(body, request, updating=False, resource_id=None):
    user = current_user(request)
    require_role(user, 'admin')
    db = request.app.state.db
    old = resource_catalog(db)
    if old['revision'] != body.expected_revision:
        raise HTTPException(409, 'El catálogo cambió en otra ventana. Recarga antes de guardar.')
    data = body.resource.model_dump()
    existing = next((row for row in old['resources'] if row['id'] == data['id']), None)
    if updating and (not existing or resource_id != data['id']):
        raise HTTPException(404, 'El recurso no existe o cambió su identificador.')
    if not updating and existing:
        raise HTTPException(409, 'Ya existe un recurso con ese identificador.')
    if existing and existing['competency_id'] != data['competency_id']:
        raise HTTPException(422, 'La competencia de un recurso existente se conserva; crea otro recurso para otra competencia.')
    resources = [data if row['id'] == data['id'] else row for row in old['resources']] if updating else [*old['resources'], data]
    if len(resources) > 200:
        raise HTTPException(422, 'El catálogo admite hasta 200 recursos.')
    validate_catalog(resources, {*competency_entries(db), 'python', 'sql'})
    revision = old['revision'] + 1
    now = datetime.now(timezone.utc)
    event = {'revision': revision, 'resource_id': data['id'], 'actor_id': user['_id'], 'actor_name': user['name'], 'note': body.note, 'at': now, 'action': 'updated' if updating else 'created', 'resource_snapshot': data}
    doc = db.resource_catalog.find_one_and_update(
        {'_id': 'current', 'revision': body.expected_revision},
        {'$set': {'resources': resources, 'version': 'learning-db-' + str(revision), 'updated_at': now}, '$inc': {'revision': 1}, '$push': {'history': {'$each': [event], '$slice': -100}}},
        return_document=ReturnDocument.AFTER)
    if not doc:
        raise HTTPException(409, 'El catálogo cambió en otra ventana. Recarga antes de guardar.')
    return view(doc)


@router.post('', status_code=201)
def add_resource(body: ResourceChange, request: Request):
    return save(body, request)


@router.put('/{resource_id}')
def change_resource(resource_id: str, body: ResourceChange, request: Request):
    return save(body, request, True, resource_id)
