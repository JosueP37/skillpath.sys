"""RF-07: avance por ruta con actualización atómica e historial acotado."""
from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError, PyMongoError

from .learning_paths import _evaluation_id
from .auth import current_user, authorized_evaluation, require_role

router = APIRouter(prefix='/api/evaluations', tags=['Progreso formativo'])
MAX_EVENTS = 500


class ActivityUpdate(BaseModel):
    model_config = ConfigDict(extra='forbid')
    status: Literal['pending', 'in_progress', 'completed']
    note: str = Field(default='', max_length=1000)
    evidence_url: HttpUrl | None = None
    expected_version: int = Field(ge=0, strict=True)

    @field_validator('note')
    @classmethod
    def clean_note(cls, value):
        return value.strip()

    @field_validator('evidence_url')
    @classmethod
    def safe_evidence_url(cls, value):
        if value and (value.username is not None or value.password is not None):
            raise ValueError('El enlace de evidencia no puede contener credenciales.')
        return value


class ActivityReview(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    status: Literal['approved', 'changes_requested']
    feedback: str = Field(default='', max_length=1000)
    expected_version: int = Field(ge=0, strict=True)


def iso(value):
    return value.replace(tzinfo=timezone.utc).isoformat(timespec='milliseconds') if value else None


def activity_view(resource, activity):
    review = activity.get('review')
    return {
        'resource_id': resource['id'], 'title': resource['title'],
        'estimated_minutes': resource['estimated_minutes'],
        'status': activity.get('status', 'pending'), 'note': activity.get('note', ''),
        'evidence_url': activity.get('evidence_url'), 'updated_at': iso(activity.get('updated_at')),
        'review': {**review, 'reviewed_at': iso(review['reviewed_at'])} if review else None,
    }


def summarize(path, document=None):
    activities = document.get('activities', {}) if document else {}
    items = [activity_view(item['resource'], activities.get(item['resource']['id'], {})) for item in path['items']]
    total = len(items)
    completed = sum(item['status'] == 'completed' for item in items)
    started = sum(item['status'] == 'in_progress' for item in items)
    return {
        'evaluation_id': path['evaluation_id'], 'path_id': path['_id'],
        'version': document.get('version', 0) if document else 0,
        'updated_at': iso(document.get('updated_at')) if document else None,
        'total_activities': total, 'completed_activities': completed,
        'approved_activities': sum(bool(item['review'] and item['review']['status'] == 'approved') for item in items),
        'in_progress_activities': started, 'pending_activities': total - completed - started,
        'completion_percent': round(100 * completed / total, 2) if total else None,
        'completed_minutes': sum(item['estimated_minutes'] for item in items if item['status'] == 'completed'),
        'remaining_minutes': sum(item['estimated_minutes'] for item in items if item['status'] != 'completed'),
        'status': 'no_activities' if not total else 'completed' if completed == total else 'in_progress' if completed or started else 'pending',
        'items': items,
        'events': [{
            'id': event['id'], 'resource_id': event['resource_id'], 'title': event['title'],
            'previous_status': event['previous_status'], 'status': event['status'],
            'note': event['note'], 'created_at': iso(event['created_at']),
            'review_status': event.get('review_status'),
            'actor_user_id': event.get('actor_user_id'), 'actor_name': event.get('actor_name'),
        } for event in reversed(document.get('events', []) if document else [])],
        'event_count': document.get('event_count', 0) if document else 0,
        'retained_event_limit': MAX_EVENTS,
    }


def load_path(db, evaluation_id):
    _evaluation_id(evaluation_id)
    path = db.learning_paths.find_one({'evaluation_id': evaluation_id})
    if path is None:
        raise HTTPException(404, 'Primero genera la ruta de esta evaluación.')
    return path


def activity_resource(path, resource_id):
    resource = next((item['resource'] for item in path['items'] if item['resource']['id'] == resource_id), None)
    if resource is None:
        raise HTTPException(404, 'La actividad no pertenece a esta ruta.')
    return resource


def check_version(document, expected_version):
    if document is None or document['version'] != expected_version:
        raise HTTPException(409, 'El progreso cambió en otra ventana. Recarga el avance antes de guardar.')


def save_activity(db, path, document, resource, user, previous, activity, now, review=None):
    activities = {**document['activities'], resource['id']: activity}
    event = {
        'id': str(uuid4()), 'resource_id': resource['id'], 'title': resource['title'],
        'previous_status': previous['status'], 'status': activity['status'],
        'note': review['feedback'] if review else activity['note'],
        'created_at': now, 'actor_user_id': user['_id'], 'actor_name': user['name'],
        'evidence_url': activity.get('evidence_url'),
    }
    if review:
        event.update(review_status=review['status'], evidence_note=activity['note'])
    updated = db.learning_progress.find_one_and_update(
        {'_id': document['_id'], 'version': document['version']},
        {'$set': {'activities': activities, 'updated_at': now},
         '$inc': {'version': 1, 'event_count': 1},
         '$push': {'events': {'$each': [event], '$slice': -MAX_EVENTS}}},
        return_document=ReturnDocument.AFTER,
    )
    if updated is None:
        raise HTTPException(409, 'El progreso cambió en otra ventana. Recarga el avance antes de guardar.')
    return summarize(path, updated)


@router.get('/{evaluation_id}/progress')
def get_progress(evaluation_id: str, request: Request):
    user = current_user(request)
    authorized_evaluation(request.app.state.db, user, evaluation_id)
    try:
        db = request.app.state.db
        path = load_path(db, evaluation_id)
        return summarize(path, db.learning_progress.find_one({'evaluation_id': evaluation_id}))
    except PyMongoError:
        raise HTTPException(503, 'No se pudo consultar el progreso. Intenta nuevamente.')


@router.put('/{evaluation_id}/progress/{resource_id}')
def update_progress(evaluation_id: str, resource_id: str, body: ActivityUpdate, request: Request):
    user = current_user(request)
    require_role(user, 'user')
    authorized_evaluation(request.app.state.db, user, evaluation_id)
    try:
        db = request.app.state.db
        path = load_path(db, evaluation_id)
        resource = activity_resource(path, resource_id)
        if body.status == 'completed' and not body.note:
            raise HTTPException(422, 'Describe brevemente la práctica realizada antes de completar la actividad.')
        document = db.learning_progress.find_one({'evaluation_id': evaluation_id})
        if document is None:
            try:
                db.learning_progress.insert_one({
                    '_id': path['_id'], 'evaluation_id': evaluation_id,
                    'schema_version': 1, 'version': 0, 'activities': {},
                    'events': [], 'event_count': 0, 'updated_at': None,
                })
            except DuplicateKeyError:
                pass
            document = db.learning_progress.find_one({'evaluation_id': evaluation_id})
        check_version(document, body.expected_version)
        previous = document['activities'].get(resource_id, {'status': 'pending', 'note': ''})
        evidence_url = previous.get('evidence_url')
        if 'evidence_url' in body.model_fields_set:
            evidence_url = str(body.evidence_url) if body.evidence_url else None
        if (previous['status'], previous['note'], previous.get('evidence_url')) == (body.status, body.note, evidence_url):
            return summarize(path, document)
        now = datetime.now(timezone.utc)
        activity = {'status': body.status, 'note': body.note, 'evidence_url': evidence_url, 'updated_at': now}
        return save_activity(db, path, document, resource, user, previous, activity, now)
    except PyMongoError:
        raise HTTPException(503, 'No se pudo guardar el avance. Intenta nuevamente.')


@router.put('/{evaluation_id}/progress/{resource_id}/review')
def review_progress(evaluation_id: str, resource_id: str, body: ActivityReview, request: Request):
    user = current_user(request)
    require_role(user, 'admin')
    db = request.app.state.db
    authorized_evaluation(db, user, evaluation_id)
    path = load_path(db, evaluation_id)
    resource = activity_resource(path, resource_id)
    document = db.learning_progress.find_one({'evaluation_id': evaluation_id})
    previous = document['activities'].get(resource_id, {}) if document else {}
    if document or body.expected_version != 0:
        check_version(document, body.expected_version)
    if previous.get('status') != 'completed' or not previous.get('note'):
        raise HTTPException(422, 'La actividad debe estar completada y tener una nota de práctica para revisarla.')
    if body.status == 'changes_requested' and not body.feedback:
        raise HTTPException(422, 'Indica qué debe corregir el colaborador.')
    old_review = previous.get('review', {})
    if (old_review.get('status'), old_review.get('feedback'), old_review.get('reviewer_id')) == (body.status, body.feedback, user['_id']):
        return summarize(path, document)
    now = datetime.now(timezone.utc)
    review = {
        'status': body.status, 'feedback': body.feedback, 'reviewed_at': now,
        'reviewer_id': user['_id'], 'reviewer_name': user['name'],
    }
    activity = {**previous, 'review': review}
    return save_activity(db, path, document, resource, user, previous, activity, now, review)
