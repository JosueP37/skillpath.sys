"""Cuatro categorías confirmadas; matriz y preguntas de demostración."""
import json
from pathlib import Path

_CATALOG = json.loads(Path(__file__).with_name('category_catalog.json').read_text(encoding='utf-8'))
VERSION = _CATALOG['version']
COMPETENCIES = _CATALOG['competencies']
PROFILES = _CATALOG['profiles']
QUESTIONS = _CATALOG['questions']


def questions_for_profile(profile_id: str, catalog=None) -> list[dict]:
    source = _CATALOG if catalog is None else catalog
    requirements = source['profiles'][profile_id]['requirements']
    return [question for question in source['questions'] if question['competency_id'] in requirements]


def public_assessment(profile_id: str, catalog=None) -> dict:
    source = _CATALOG if catalog is None else catalog
    profile = source['profiles'][profile_id]
    return {
        'profile_id': profile_id, 'profile_name': profile['name'], 'version': source['version'],
        'competencies': [
            {'id': key, 'name': source['competencies'][key], 'required': value, 'criticality': profile['criticality'][key]}
            for key, value in profile['requirements'].items()
        ],
        'questions': [
            {key: value for key, value in question.items() if key != 'correct'}
            for question in questions_for_profile(profile_id, source)
        ],
    }
