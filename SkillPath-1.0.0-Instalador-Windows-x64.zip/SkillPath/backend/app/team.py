"""Historial y evolución del equipo asignado al administrador."""
from fastapi import APIRouter, HTTPException, Request
from .auth import current_user, require_role, scoped_user_ids, user_view
from .evaluation_records import instrument_key
from .progress import summarize, iso

router = APIRouter(prefix='/api/team', tags=['Equipo del administrador'])


def member_summary(db, member):
    evaluations = list(db.evaluations.find({'user_id': member['_id']}, {'answers': 0, 'assessment_snapshot': 0, 'scoring_key_snapshot': 0}).sort([('created_at', 1), ('_id', 1)]))
    ids = [doc['_id'] for doc in evaluations]
    paths = list(db.learning_paths.find({'evaluation_id': {'$in': ids}}))
    progress = {doc['evaluation_id']: doc for doc in db.learning_progress.find({'evaluation_id': {'$in': ids}}, {'events': 0})}
    summaries = [summarize(path, progress.get(path['evaluation_id'])) for path in paths]
    total = sum(row['total_activities'] for row in summaries)
    completed = sum(row['completed_activities'] for row in summaries)
    return {
        **user_view(db, member), 'evaluation_count': len(evaluations),
        'latest_score': evaluations[-1]['overall_score'] if evaluations else None,
        'latest_category': evaluations[-1]['profile_name'] if evaluations else None,
        'latest_at': iso(evaluations[-1]['created_at']) if evaluations else None,
        'completed_activities': completed, 'total_activities': total,
        'completion_percent': round(100 * completed / total, 2) if total else None,
    }, evaluations


@router.get('')
def team(request: Request):
    administrator = current_user(request)
    require_role(administrator, 'admin')
    db = request.app.state.db
    members = list(db.users.find({'role': 'user', 'administrator_id': administrator['_id'], 'active': True}).sort('name', 1))
    return {'administrator': user_view(db, administrator), 'members': [member_summary(db, member)[0] for member in members]}


@router.get('/{user_id}')
def member_detail(user_id: str, request: Request):
    administrator = current_user(request)
    require_role(administrator, 'admin')
    db = request.app.state.db
    scoped_user_ids(db, administrator, user_id)
    member = db.users.find_one({'_id': user_id})
    if member is None:
        raise HTTPException(404, 'El usuario no está disponible.')
    summary, evaluations = member_summary(db, member)
    groups = {}
    for doc in evaluations:
        groups.setdefault(instrument_key(doc), []).append(doc)
    evolution = []
    for docs in groups.values():
        first, latest = docs[0], docs[-1]
        first_rows = {r['competency_id']: r for r in first['results']}
        evolution.append({
            'profile_id': latest['profile_id'], 'profile_name': latest['profile_name'], 'job_profile_id': latest.get('job_profile_id'), 'job_profile_name': latest.get('job_profile_name'),
            'assessment_version': latest['assessment_version'], 'algorithm_version': latest['algorithm_version'],
            'evaluation_count': len(docs), 'first_score': first['overall_score'], 'latest_score': latest['overall_score'],
            'score_delta': round(latest['overall_score'] - first['overall_score'], 2) if len(docs) > 1 else None,
            'first_gap_count': first['competencies_with_gap'], 'latest_gap_count': latest['competencies_with_gap'],
            'points': [{'id': doc['_id'], 'created_at': iso(doc['created_at']), 'score': doc['overall_score'], 'gap_count': doc['competencies_with_gap']} for doc in docs],
            'competencies': [{'id': row['competency_id'], 'name': row['competency_name'], 'first_score': first_rows[row['competency_id']]['current'], 'latest_score': row['current'], 'score_delta': round(row['current'] - first_rows[row['competency_id']]['current'], 2)} for row in latest['results']],
        })
    return {'member': summary, 'evolution': evolution, 'definition': 'Se compara el primer y el último diagnóstico de cada categoría, versión y requisitos iguales. El progreso de actividades es declarado; no modifica la puntuación del diagnóstico.'}
