from .catalog import COMPETENCIES, PROFILES, VERSION, questions_for_profile

def evaluate(profile_id: str, version: str, answers: list[dict], catalog=None) -> dict:
    profiles = PROFILES if catalog is None else catalog['profiles']
    competencies = COMPETENCIES if catalog is None else catalog['competencies']
    expected_version = VERSION if catalog is None else catalog['version']
    if profile_id not in profiles:
        raise ValueError('La categoría seleccionada no existe o pertenece a un perfil anterior.')
    if version != expected_version:
        raise ValueError('La evaluación cambió. Vuelve a iniciarla.')
    requirements = profiles[profile_id]['requirements']
    questions = questions_for_profile(profile_id, catalog)
    expected_ids = {q['id'] for q in questions}
    provided_ids = [answer['question_id'] for answer in answers]
    if len(provided_ids) != len(set(provided_ids)):
        raise ValueError('Cada pregunta debe tener una sola respuesta.')
    if set(provided_ids) != expected_ids:
        raise ValueError('Responde todas las preguntas de esta categoría y solo esas preguntas.')
    submitted = {a['question_id']: a['option_id'] for a in answers}
    totals = {key: 0 for key in requirements}
    obtained = {key: 0 for key in requirements}
    for question in questions:
        if submitted[question['id']] not in {option['id'] for option in question['options']}:
            raise ValueError('Una de las opciones seleccionadas no es válida.')
        key = question['competency_id']
        totals[key] += question['weight']
        if submitted[question['id']] == question['correct']:
            obtained[key] += question['weight']
    results = []
    for key, required in requirements.items():
        current = 100 * obtained[key] / totals[key]
        gap = max(required - current, 0)
        results.append({
            'competency_id': key, 'competency_name': competencies[key],
            'required': required, 'current': round(current, 2), 'gap_points': round(gap, 2),
            'gap_percent': round(100 * gap / required, 2), 'achieved': gap == 0,
            'earned_weight': obtained[key], 'total_weight': totals[key],
        })
    return {
        'profile_id': profile_id, 'profile_name': profiles[profile_id]['name'],
        'assessment_version': version, 'results': results,
        'competencies_with_gap': sum(not row['achieved'] for row in results),
        'competencies_achieved': sum(row['achieved'] for row in results),
        'question_count': len(questions),
        'overall_score': round(100 * sum(obtained.values()) / sum(totals.values()), 2),
    }

