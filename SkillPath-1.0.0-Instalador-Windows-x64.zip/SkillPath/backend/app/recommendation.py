"""Recomendación determinista sobre el diagnóstico guardado, sin entrenar modelos."""
from copy import deepcopy

from .learning_catalog import CATALOG_VERSION, RESOURCES

RULES_VERSION = 'gap-path-1'
RULES = {
    'priority': 'brecha_relativa_porcentaje * criticidad',
    'tie_break': 'brecha_en_puntos descendente, competencia_id ascendente',
    'resource_selection': 'menor nivel objetivo suficiente, menor duración, recurso_id',
    'prerequisites': 'solo de la misma competencia con brecha; omitir bases si el nivel de entrada ya se alcanzó',
    'legacy_criticality': 1,
}


def _expand(resource, current, competency_id, catalog, visiting):
    """Devuelve bases antes del recurso; descarta relaciones inválidas y ciclos."""
    key = resource['id']
    if key in visiting:
        raise ValueError('El catálogo contiene un ciclo de prerrequisitos.')
    if not resource['approved'] or resource['competency_id'] != competency_id:
        raise ValueError('El prerrequisito no es elegible para esta competencia.')
    if current >= resource['target_score']:
        return []
    chain = []
    if current < resource['entry_score']:
        for dependency_id in resource['prerequisite_ids']:
            dependency = catalog.get(dependency_id)
            if dependency is None:
                raise ValueError('Falta un prerrequisito en el catálogo.')
            chain.extend(_expand(dependency, current, competency_id, catalog, visiting | {key}))
        if max([current] + [item['target_score'] for item in chain]) < resource['entry_score']:
            raise ValueError('No hay una base adecuada para el nivel de entrada del recurso.')
    return chain + [resource]


def build_learning_path(evaluation: dict, resources: list[dict] | None = None, catalog_version: str | None = None) -> dict:
    source = RESOURCES if resources is None else resources
    catalog = {item['id']: item for item in source}
    if len(catalog) != len(source):
        raise ValueError('El catálogo tiene identificadores de recurso repetidos.')
    criticality = {
        item['id']: item.get('criticality', 1)
        for item in evaluation['assessment_snapshot']['competencies']
    }
    gaps = [deepcopy(row) for row in evaluation['results'] if not row['achieved'] and row['gap_points'] > 0]
    for row in gaps:
        row['criticality'] = criticality.get(row['competency_id'], 1)
        row['priority_score'] = round(row['gap_percent'] * row['criticality'], 2)
    gaps.sort(key=lambda row: (-row['priority_score'], -row['gap_points'], row['competency_id']))
    items, uncovered, covered = [], [], []
    selected_ids = set()
    for row in gaps:
        candidates = sorted(
            [item for item in source if item['approved'] and item['competency_id'] == row['competency_id'] and item['target_score'] >= row['required']],
            key=lambda item: (item['target_score'], item['estimated_minutes'], item['id']),
        )
        chain = None
        for candidate in candidates:
            try:
                chain = _expand(candidate, row['current'], row['competency_id'], catalog, set())
                break
            except ValueError:
                continue
        if not chain:
            uncovered.append({
                'competency_id': row['competency_id'], 'competency_name': row['competency_name'],
                'reason': 'No hay un recurso aprobado con nivel y prerrequisitos adecuados en el catálogo de demostración.',
            })
            continue
        covered.append(row['competency_id'])
        for resource in chain:
            if resource['id'] in selected_ids:
                continue
            selected_ids.add(resource['id'])
            is_prerequisite = resource['id'] != candidate['id']
            explanation = (
                f"Tu puntuación es {row['current']:g}/100 frente a {row['required']:g}/100; "
                f"la brecha es {row['gap_points']:g} puntos ({row['gap_percent']:g} % relativo). "
                f"Criticidad {row['criticality']:g}; prioridad {row['priority_score']:g}. "
            )
            explanation += (
                f"Esta base se incluye antes de {candidate['title']} porque su nivel de entrada es {candidate['entry_score']:g}/100."
                if is_prerequisite else 'El recurso corresponde al nivel objetivo del diagnóstico en el catálogo de demostración.'
            )
            items.append({
                'order': len(items) + 1, 'competency_id': row['competency_id'],
                'competency_name': row['competency_name'],
                'role': 'prerequisite' if is_prerequisite else 'main',
                'priority_score': row['priority_score'], 'reason': explanation,
                'resource': deepcopy(resource),
            })
    return {
        'rules_version': RULES_VERSION, 'catalog_version': catalog_version or CATALOG_VERSION,
        'rules_snapshot': deepcopy(RULES), 'diagnosis_snapshot': deepcopy(evaluation['results']),
        'priorities': gaps, 'items': items, 'uncovered_competencies': uncovered,
        'gap_count': len(gaps), 'covered_gap_count': len(covered),
        'estimated_minutes': sum(item['resource']['estimated_minutes'] for item in items),
        'status': 'no_gaps' if not gaps else 'ready' if not uncovered else 'partial' if covered else 'uncovered',
        'explanation': 'El orden combina brecha relativa y criticidad de cada competencia. Las bases aparecen antes del recurso principal. La cobertura indica competencias con recursos asignados; no implica que la brecha ya se haya cerrado.',
        'catalog_note': 'Catálogo de demostración. Criticidades, niveles y tiempos son estimaciones pendientes de validación por iCloudFlex.',
    }
