"""Creación y comparación de snapshots, compartida con la carga de ejemplos."""
from datetime import datetime, timezone
from uuid import uuid4
from .catalog import public_assessment, questions_for_profile
from .scoring import evaluate


def make_document(user, profile_id, version, answers, created_at=None, evaluation_id=None, catalog=None, job=None):
    diagnosis = evaluate(profile_id, version, answers, catalog)
    return {
        '_id': evaluation_id or str(uuid4()), 'created_at': created_at or datetime.now(timezone.utc),
        'schema_version': 2, 'algorithm_version': 'weighted-gap-1', 'mode': 'demo',
        'user_id': user['_id'], 'user_name': user['name'], 'administrator_id': user['administrator_id'],
        'job_profile_id': job['_id'] if job else None, 'job_profile_name': job['name'] if job else None, 'job_revision': job['revision'] if job else None,
        'answers': answers, 'assessment_snapshot': public_assessment(profile_id, catalog),
        **diagnosis,
        'scoring_key_snapshot': [{'question_id': q['id'], 'correct': q['correct'], 'weight': q['weight']} for q in questions_for_profile(profile_id, catalog)],
        'calculation_ms': 0,
    }


def instrument_key(document):
    return (document['profile_id'], document.get('job_profile_id'), document['assessment_version'], document['algorithm_version'],
            tuple(sorted((r['competency_id'], r['required']) for r in document['results'])))


def attach_comparison(document, previous):
    compatible = instrument_key(previous) == instrument_key(document)
    old_rows = {r['competency_id']: r for r in previous['results']}
    document['previous_evaluation_id'] = previous['_id']
    document['comparison'] = {
        'compatible': compatible, 'previous_score': previous['overall_score'],
        'score_delta': round(document['overall_score'] - previous['overall_score'], 2) if compatible else None,
        'previous_gap_count': previous['competencies_with_gap'], 'current_gap_count': document['competencies_with_gap'],
        'competencies': [{
            'competency_id': current['competency_id'], 'competency_name': current['competency_name'],
            'previous_score': old_rows[current['competency_id']]['current'], 'current_score': current['current'],
            'score_delta': round(current['current'] - old_rows[current['competency_id']]['current'], 2),
            'previous_gap_points': old_rows[current['competency_id']]['gap_points'], 'current_gap_points': current['gap_points'],
        } for current in document['results']] if compatible else [],
    }
