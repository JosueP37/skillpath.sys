"""RF-06: identidad, sesiones revocables y autorización por propietario/equipo."""
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import os
import re
import secrets
from uuid import UUID, uuid4

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError, InvalidHashError
from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo.errors import DuplicateKeyError

router = APIRouter(prefix='/api/auth', tags=['Autenticación'])
PASSWORDS = PasswordHasher(time_cost=2, memory_cost=19456, parallelism=1)
DUMMY_HASH = PASSWORDS.hash(secrets.token_urlsafe(32))
COOKIE = 'skillpath_session'
SESSION_HOURS = 8
ALLOWED_ORIGINS = {'http://127.0.0.1:5173', 'http://localhost:5173', 'http://127.0.0.1:8000', 'http://localhost:8000'}


def indexes(db):
    db.users.create_index('email', unique=True)
    db.users.create_index([('administrator_id', 1), ('role', 1)])
    db.sessions.create_index('expires_at', expireAfterSeconds=0)
    db.login_attempts.create_index('expires_at', expireAfterSeconds=0)
    db.evaluations.create_index([('user_id', 1), ('created_at', -1)])


def origin_guard(request):
    origin = request.headers.get('origin')
    if origin and origin not in ALLOWED_ORIGINS:
        raise HTTPException(403, 'Origen de la solicitud no permitido.')


def token_digest(token):
    return sha256(token.encode()).hexdigest()


def csrf_token(token):
    return token_digest('skillpath-csrf:' + token)


def user_view(db, user):
    administrator = db.users.find_one({'_id': user.get('administrator_id'), 'role': 'admin', 'active': True}) if user['role'] == 'user' else None
    return {
        'id': user['_id'], 'name': user['name'], 'email': user['email'], 'role': user['role'],
        'administrator': {'id': administrator['_id'], 'name': administrator['name']} if administrator else None,
    }


def current_user(request):
    token = request.cookies.get(COOKIE, '')
    if not token:
        raise HTTPException(401, 'Inicia sesión para continuar.')
    db = request.app.state.db
    session = db.sessions.find_one({'_id': token_digest(token), 'expires_at': {'$gt': datetime.now(timezone.utc)}})
    user = db.users.find_one({'_id': session['user_id'], 'active': True}) if session else None
    if not user or user.get('role') not in ('admin', 'user'):
        raise HTTPException(401, 'Tu sesión terminó. Vuelve a ingresar.')
    if user['role'] == 'user' and not db.users.find_one({'_id': user.get('administrator_id'), 'role': 'admin', 'active': True}, {'_id': 1}):
        raise HTTPException(401, 'Tu cuenta requiere un administrador activo.')
    if request.method not in ('GET', 'HEAD', 'OPTIONS'):
        origin_guard(request)
        if not secrets.compare_digest(request.headers.get('x-csrf-token', '').encode('utf-8'), csrf_token(token).encode('utf-8')):
            raise HTTPException(403, 'La sesión no pudo validar la solicitud. Recarga la página.')
    return user


def require_role(user, role):
    if user['role'] != role:
        raise HTTPException(403, 'Tu rol no permite realizar esta operación.')


def scoped_user_ids(db, user, requested=None):
    ids = [user['_id']] if user['role'] == 'user' else [doc['_id'] for doc in db.users.find({'role': 'user', 'administrator_id': user['_id'], 'active': True}, {'_id': 1})]
    if requested is not None:
        if requested not in ids:
            raise HTTPException(404, 'El usuario no está disponible en tu equipo.')
        return [requested]
    return ids


def authorized_evaluation(db, user, evaluation_id):
    document = db.evaluations.find_one({'_id': evaluation_id})
    owner_id = document.get('user_id') if document else None
    if not owner_id:
        raise HTTPException(404, 'La evaluación no está disponible.')
    if user['role'] == 'user':
        allowed = owner_id == user['_id']
    else:
        allowed = db.users.find_one({'_id': owner_id, 'role': 'user', 'administrator_id': user['_id'], 'active': True}) is not None
    if not allowed:
        raise HTTPException(404, 'La evaluación no está disponible.')
    return document


def new_session(request, response, user):
    token = secrets.token_urlsafe(32)
    db = request.app.state.db
    db.sessions.insert_one({'_id': token_digest(token), 'user_id': user['_id'], 'created_at': datetime.now(timezone.utc), 'expires_at': datetime.now(timezone.utc) + timedelta(hours=SESSION_HOURS)})
    old_token = request.cookies.get(COOKIE)
    if old_token:
        db.sessions.delete_one({'_id': token_digest(old_token)})
    response.set_cookie(COOKIE, token, httponly=True, samesite='lax', secure=os.getenv('SESSION_COOKIE_SECURE', 'false').lower() == 'true', max_age=SESSION_HOURS * 3600, path='/api')
    return {'user': user_view(db, user), 'csrf_token': csrf_token(token)}


class Credentials(BaseModel):
    model_config = ConfigDict(extra='forbid')
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=128)

    @field_validator('email')
    @classmethod
    def email_format(cls, value):
        value = value.strip().casefold()
        if not re.fullmatch(r"[a-z0-9.!#$%&'*+/=?^_{|}~-]+@[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}", value):
            raise ValueError('Ingresa un correo válido.')
        return value


class Registration(Credentials):
    name: str = Field(min_length=2, max_length=80)
    password: str = Field(min_length=12, max_length=128)
    administrator_id: str = Field(min_length=36, max_length=36)

    @field_validator('name')
    @classmethod
    def name_format(cls, value):
        value = value.strip()
        if len(value) < 2:
            raise ValueError('Ingresa tu nombre.')
        return value

    @field_validator('administrator_id')
    @classmethod
    def uuid_format(cls, value):
        if str(UUID(value)) != value:
            raise ValueError('Selecciona un administrador válido.')
        return value


@router.get('/administrators')
def administrators(request: Request):
    return [{'id': doc['_id'], 'name': doc['name']} for doc in request.app.state.db.users.find({'role': 'admin', 'active': True}, {'name': 1}).sort('name', 1)]


@router.post('/register', status_code=201)
def register(body: Registration, request: Request, response: Response):
    origin_guard(request)
    db = request.app.state.db
    if not db.users.find_one({'_id': body.administrator_id, 'role': 'admin', 'active': True}):
        raise HTTPException(422, 'Debes seleccionar un administrador activo. Sin administrador no se puede crear la cuenta.')
    user = {'_id': str(uuid4()), 'name': body.name, 'email': body.email, 'password_hash': PASSWORDS.hash(body.password), 'role': 'user', 'administrator_id': body.administrator_id, 'active': True, 'created_at': datetime.now(timezone.utc)}
    try:
        db.users.insert_one(user)
    except DuplicateKeyError:
        raise HTTPException(409, 'Ya existe una cuenta con ese correo.')
    return new_session(request, response, user)


@router.post('/login')
def login(body: Credentials, request: Request, response: Response):
    origin_guard(request)
    db = request.app.state.db
    now = datetime.now(timezone.utc)
    key = token_digest(body.email + ':' + (request.client.host if request.client else 'unknown'))
    attempt = db.login_attempts.find_one({'_id': key, 'expires_at': {'$gt': now}})
    if attempt and attempt['count'] >= 5:
        raise HTTPException(429, 'Demasiados intentos. Espera 10 minutos antes de volver a ingresar.')
    user = db.users.find_one({'email': body.email, 'active': True})
    try:
        valid = PASSWORDS.verify(user['password_hash'] if user else DUMMY_HASH, body.password)
    except (VerificationError, InvalidHashError):
        valid = False
    if not valid or not user:
        db.login_attempts.delete_one({'_id': key, 'expires_at': {'$lte': now}})
        db.login_attempts.update_one({'_id': key}, {'$inc': {'count': 1}, '$setOnInsert': {'expires_at': now + timedelta(minutes=10)}}, upsert=True)
        raise HTTPException(401, 'Correo o contraseña incorrectos.')
    if user['role'] == 'user' and not db.users.find_one({'_id': user.get('administrator_id'), 'role': 'admin', 'active': True}):
        raise HTTPException(403, 'Tu cuenta requiere un administrador activo.')
    db.login_attempts.delete_one({'_id': key})
    return new_session(request, response, user)


@router.get('/me')
def me(request: Request):
    user = current_user(request)
    return {'user': user_view(request.app.state.db, user), 'csrf_token': csrf_token(request.cookies[COOKIE])}


@router.post('/logout', status_code=204)
def logout(request: Request, response: Response):
    current_user(request)
    request.app.state.db.sessions.delete_one({'_id': token_digest(request.cookies[COOKIE])})
    response.delete_cookie(COOKIE, path='/api')
