from contextlib import asynccontextmanager
from datetime import timezone
from time import perf_counter
import os

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from pymongo import MongoClient, DESCENDING
from pymongo.errors import PyMongoError

from .catalog import PROFILES, public_assessment
from .competencies import MAX_QUESTIONS_PER_CATEGORY, competency_entries, router as competencies_router
from .auth import current_user, require_role, authorized_evaluation, scoped_user_ids, indexes, router as auth_router
from .evaluation_records import make_document, attach_comparison
from .learning_paths import router as learning_paths_router
from .progress import router as progress_router
from .dashboard import router as dashboard_router
from .team import router as team_router
from .reports import router as reports_router
from .jobs import router as jobs_router, assessment_catalog
from .resources import router as resources_router


class Answer(BaseModel):
    model_config = ConfigDict(extra='forbid')
    question_id: str = Field(min_length=1, max_length=50)
    option_id: str = Field(min_length=1, max_length=10)


class Submission(BaseModel):
    model_config = ConfigDict(extra='forbid')
    profile_id: str = Field(min_length=1, max_length=50)
    assessment_version: str = Field(min_length=1, max_length=100)
    job_profile_id: str | None = Field(default=None, min_length=36, max_length=36)
    answers: list[Answer] = Field(min_length=1, max_length=MAX_QUESTIONS_PER_CATEGORY)
    previous_evaluation_id: str | None = Field(default=None, min_length=36, max_length=36)


def create_app(mongo_uri: str | None = None, database_name: str | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app):
        client = MongoClient(mongo_uri or os.getenv('MONGODB_URI', 'mongodb://127.0.0.1:27018'), serverSelectionTimeoutMS=3000)
        db = client[database_name or os.getenv('MONGODB_DATABASE', 'skillpath_demo')]
        client.admin.command('ping')
        db.evaluations.create_index([('created_at', DESCENDING)])
        db.learning_paths.create_index('evaluation_id', unique=True)
        db.learning_progress.create_index('evaluation_id', unique=True)
        db.evaluations.create_index([('profile_id', 1), ('created_at', DESCENDING)])
        indexes(db)
        db.job_profiles.create_index([('category_id', 1), ('normalized_name', 1)], unique=True)
        app.state.db = db
        try:
            yield
        finally:
            client.close()

    app = FastAPI(title='SkillPath · Competencias y aprendizaje', version='1.0.0', lifespan=lifespan)
    app.add_middleware(CORSMiddleware, allow_origins=['http://127.0.0.1:5173', 'http://localhost:5173'], allow_credentials=True, allow_methods=['GET', 'POST', 'PUT'], allow_headers=['Content-Type', 'X-CSRF-Token'])

    @app.middleware('http')
    async def private_cache(request: Request, call_next):
        response = await call_next(request)
        if request.url.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.exception_handler(PyMongoError)
    async def database_error(request, error):
        return JSONResponse(status_code=503, content={'detail': 'La base de datos no está disponible. Intenta nuevamente.'})

    @app.get('/api/health')
    def health(request: Request):
        request.app.state.db.command('ping')
        return {'status': 'ok', 'database': 'mongodb', 'mode': 'demo'}

    @app.get('/api/profiles')
    def profiles(request: Request):
        current_user(request)
        db = request.app.state.db
        entries = competency_entries(db)
        result = []
        for key, profile in PROFILES.items():
            catalog, _ = assessment_catalog(db, key, entries=entries)
            result.append({
                'id': key, 'name': profile['name'], 'description': profile['description'],
                'competency_count': len(profile['requirements']), 'question_count': len(catalog['questions']),
                'competencies': [
                    {'id': cid, 'name': entries[cid]['name'], 'required': required}
                    for cid, required in profile['requirements'].items()
                ],
            })
        return result

    @app.get('/api/profiles/{profile_id}/assessment')
    def assessment(profile_id: str, request: Request, job_profile_id: str | None = None):
        current_user(request)
        if profile_id not in PROFILES:
            raise HTTPException(404, 'La categoría no está disponible. Elige una de las cuatro categorías actuales.')
        catalog, job = assessment_catalog(request.app.state.db, profile_id, job_profile_id)
        return {**public_assessment(profile_id, catalog), 'job_profile_id': job['_id'] if job else None, 'job_profile_name': job['name'] if job else None}

    @app.post('/api/evaluations', status_code=201)
    def submit(body: Submission, request: Request):
        user = current_user(request)
        require_role(user, 'user')
        catalog, job = assessment_catalog(request.app.state.db, body.profile_id, body.job_profile_id)
        started = perf_counter()
        try:
            document = make_document(user, body.profile_id, body.assessment_version, [answer.model_dump() for answer in body.answers], catalog=catalog, job=job)
        except ValueError as error:
            raise HTTPException(422, str(error))
        document['calculation_ms'] = round((perf_counter() - started) * 1000, 3)
        if body.previous_evaluation_id is not None:
            previous = authorized_evaluation(request.app.state.db, user, body.previous_evaluation_id)
            if previous['profile_id'] != body.profile_id or previous.get('job_profile_id') != document.get('job_profile_id'):
                raise HTTPException(422, 'La reevaluación debe corresponder a la misma categoría y puesto.')
            attach_comparison(document, previous)
        request.app.state.db.evaluations.insert_one(document)
        return result_view(document)

    @app.get('/api/evaluations')
    def history(request: Request, user_id: str | None = None, offset: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100)):
        user = current_user(request)
        ids = scoped_user_ids(request.app.state.db, user, user_id)
        docs = request.app.state.db.evaluations.find({'user_id': {'$in': ids}}).sort([('created_at', DESCENDING), ('_id', DESCENDING)]).skip(offset).limit(limit)
        return [result_view(doc) for doc in docs]

    @app.get('/api/evaluations/{evaluation_id}')
    def saved_result(evaluation_id: str, request: Request):
        user = current_user(request)
        return result_view(authorized_evaluation(request.app.state.db, user, evaluation_id))

    app.include_router(auth_router)
    app.include_router(learning_paths_router)
    app.include_router(progress_router)
    app.include_router(dashboard_router)
    app.include_router(team_router)
    app.include_router(reports_router)
    app.include_router(jobs_router)
    app.include_router(competencies_router)
    app.include_router(resources_router)
    return app


def result_view(document: dict) -> dict:
    return {
        'id': document['_id'], 'job_profile_id': document.get('job_profile_id'), 'job_profile_name': document.get('job_profile_name'), 'user_id': document.get('user_id'), 'user_name': document.get('user_name'),
        'category_active': document['profile_id'] in PROFILES,
        'previous_evaluation_id': document.get('previous_evaluation_id'), 'comparison': document.get('comparison'),
        'created_at': document['created_at'].replace(tzinfo=timezone.utc).isoformat(timespec='milliseconds'),
        **{key: document[key] for key in ['profile_id', 'profile_name', 'assessment_version', 'algorithm_version', 'results', 'competencies_with_gap', 'competencies_achieved', 'question_count', 'overall_score', 'calculation_ms', 'mode']},
    }


app = create_app()
