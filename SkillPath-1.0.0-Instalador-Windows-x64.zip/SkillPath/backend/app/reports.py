"""RF-08: reporte de equipo y CSV, con denominadores y filtros reproducibles."""
import csv
from datetime import date, datetime, time, timedelta, timezone
from io import StringIO
from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import Response
from .auth import current_user, require_role, scoped_user_ids
from .catalog import PROFILES
from .evaluation_records import instrument_key
from .progress import iso, summarize

router = APIRouter(prefix='/api/reports', tags=['Reportes del equipo'])
LOCAL_TIMEZONE = timezone(timedelta(hours=-5))


def report_data(request, profile_id=None, user_id=None, date_from=None, date_to=None):
    admin = current_user(request)
    require_role(admin, 'admin')
    db = request.app.state.db
    owner_ids = scoped_user_ids(db, admin, user_id)
    if profile_id and profile_id not in PROFILES:
        raise HTTPException(422, 'La categoría no existe.')
    if date_to == date.max:
        raise HTTPException(422, 'La fecha final excede el rango permitido.')
    if date_from and date_to and date_from > date_to:
        raise HTTPException(422, 'La fecha inicial no puede ser posterior a la fecha final.')
    query = {'user_id': {'$in': owner_ids}}
    if profile_id:
        query['profile_id'] = profile_id
    bounds = {}
    if date_from:
        bounds['$gte'] = datetime.combine(date_from, time.min, LOCAL_TIMEZONE).astimezone(timezone.utc)
    if date_to:
        bounds['$lt'] = datetime.combine(date_to + timedelta(days=1), time.min, LOCAL_TIMEZONE).astimezone(timezone.utc)
    if bounds:
        query['created_at'] = bounds
    evaluations = list(db.evaluations.find(query, {'answers': 0, 'scoring_key_snapshot': 0, 'assessment_snapshot': 0}).sort([('created_at', 1), ('_id', 1)]))
    ids = [doc['_id'] for doc in evaluations]
    paths = list(db.learning_paths.find({'evaluation_id': {'$in': ids}}))
    paths_by_id = {path['evaluation_id']: path for path in paths}
    progresses = {doc['evaluation_id']: doc for doc in db.learning_progress.find({'evaluation_id': {'$in': ids}}, {'events': 0})}
    members = list(db.users.find({'_id': {'$in': owner_ids}}, {'name': 1, 'email': 1}).sort('name', 1))
    grouped = {}
    for doc in evaluations:
        grouped.setdefault(doc['user_id'], {}).setdefault(instrument_key(doc), []).append(doc)
    rows = []
    for member in members:
        groups = grouped.get(member['_id'], {})
        if not groups:
            rows.append({'user_id': member['_id'], 'user_name': member['name'], 'email': member['email'], 'profile_id': profile_id, 'profile_name': PROFILES[profile_id]['name'] if profile_id else None, 'job_profile_name': None, 'assessment_version': None, 'evaluation_count': 0, 'latest_evaluation_id': None, 'first_score': None, 'latest_score': None, 'score_delta': None, 'competencies_with_gap': None, 'competencies_achieved': None, 'gaps': [], 'achieved': [], 'path_count': 0, 'total_activities': 0, 'completed_activities': 0, 'completion_percent': None, 'status': 'not_evaluated', 'latest_at': None})
        for docs in groups.values():
            first, latest = docs[0], docs[-1]
            summaries = [summarize(paths_by_id[doc['_id']], progresses.get(doc['_id'])) for doc in docs if doc['_id'] in paths_by_id]
            total = sum(item['total_activities'] for item in summaries)
            completed = sum(item['completed_activities'] for item in summaries)
            rows.append({
                'user_id': member['_id'], 'user_name': member['name'], 'email': member['email'],
                'profile_id': latest['profile_id'], 'profile_name': latest['profile_name'], 'job_profile_name': latest.get('job_profile_name'), 'assessment_version': latest['assessment_version'],
                'evaluation_count': len(docs), 'latest_evaluation_id': latest['_id'], 'first_score': first['overall_score'], 'latest_score': latest['overall_score'],
                'score_delta': round(latest['overall_score'] - first['overall_score'], 2) if len(docs) > 1 else None,
                'competencies_with_gap': latest['competencies_with_gap'], 'competencies_achieved': latest['competencies_achieved'],
                'gaps': [{'competency_name': row['competency_name'], 'gap_points': row['gap_points']} for row in latest['results'] if not row['achieved']],
                'achieved': [row['competency_name'] for row in latest['results'] if row['achieved']],
                'path_count': len(summaries), 'total_activities': total, 'completed_activities': completed, 'completion_percent': round(100 * completed / total, 2) if total else None,
                'status': 'no_route' if not summaries else 'no_activities' if not total else 'completed' if completed == total else 'in_progress' if any(item['status'] == 'in_progress' for item in summaries) or completed else 'pending',
                'latest_at': iso(latest['created_at']),
            })
    total = sum(row['total_activities'] for row in rows)
    completed = sum(row['completed_activities'] for row in rows)
    return {
        'generated_at': iso(datetime.now(timezone.utc)), 'administrator': admin['name'], 'mode': 'demo',
        'filters': {'profile_id': profile_id, 'user_id': user_id, 'date_from': date_from.isoformat() if date_from else None, 'date_to': date_to.isoformat() if date_to else None, 'timezone': 'America/Bogota (UTC-05:00)'},
        'summary': {'user_count': len(members), 'evaluated_users': len(grouped), 'evaluation_count': len(evaluations), 'series_count': sum(row['evaluation_count'] > 0 for row in rows), 'path_count': len(paths), 'total_activities': total, 'completed_activities': completed, 'completion_percent': round(100 * completed / total, 2) if total else None},
        'rows': rows,
        'definitions': [
            'Cada fila representa una persona y un instrumento comparable: misma categoría, puesto, versión, algoritmo y requisitos.',
            'Las brechas y competencias alcanzadas corresponden al último diagnóstico de cada serie dentro del período.',
            'El avance suma actividades de las rutas de las evaluaciones filtradas. Sin actividades, no aplica porcentaje.',
            'Una persona sin diagnósticos figura como Sin evaluación; su puntuación no se considera cero.',
            'El rango de fechas incluye días completos en UTC-05:00 y filtra la fecha del diagnóstico; el avance es el estado actual de sus rutas.',
            'El contenido y los datos son de demostración. La mejora de puntuación no acredita desempeño laboral.',
        ],
    }


@router.get('/team')
def team_report(request: Request, profile_id: str | None = None, user_id: str | None = None, date_from: date | None = None, date_to: date | None = None):
    return report_data(request, profile_id, user_id, date_from, date_to)


def csv_cell(value):
    if value is None:
        return ''
    # Evita ejecutar fórmulas al abrir textos controlados por usuarios en Excel.
    if isinstance(value, str) and value and (value[:1] in '\t\r\n' or value.lstrip().startswith(('=', '+', '-', '@'))):
        return "'" + value
    return value


@router.get('/team.csv')
def export_report(request: Request, profile_id: str | None = None, user_id: str | None = None, date_from: date | None = None, date_to: date | None = None):
    report = report_data(request, profile_id, user_id, date_from, date_to)
    stream = StringIO()
    writer = csv.writer(stream, delimiter=';', lineterminator='\r\n')
    writer.writerow(['generado_utc', 'usuario', 'correo', 'categoria', 'puesto', 'version', 'evaluaciones', 'puntaje_inicial', 'puntaje_actual', 'cambio_puntos', 'competencias_con_brecha', 'competencias_alcanzadas', 'brechas_detalle', 'alcanzadas_detalle', 'rutas', 'actividades_completadas', 'actividades_asignadas', 'avance_porcentaje', 'estado', 'desde', 'hasta', 'zona_horaria'])
    for row in report['rows']:
        values = [report['generated_at'], row['user_name'], row['email'], row['profile_name'], row['job_profile_name'], row['assessment_version'], row['evaluation_count'], row['first_score'], row['latest_score'], row['score_delta'], row['competencies_with_gap'], row['competencies_achieved'], ' | '.join(item['competency_name'] + ': ' + str(item['gap_points']) for item in row['gaps']), ' | '.join(row['achieved']), row['path_count'], row['completed_activities'], row['total_activities'], row['completion_percent'], row['status'], report['filters']['date_from'], report['filters']['date_to'], report['filters']['timezone']]
        writer.writerow([csv_cell(value) for value in values])
    return Response('\ufeff' + stream.getvalue(), media_type='text/csv; charset=utf-8', headers={'Content-Disposition': 'attachment; filename="skillpath-reporte-equipo.csv"'})
