"""Banco de preguntas por competencia, administrado y versionado en MongoDB."""
from datetime import datetime, timezone
from typing import Annotated
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator
from pymongo.errors import DuplicateKeyError

from .auth import current_user, require_role
from .catalog import COMPETENCIES, PROFILES, QUESTIONS

router = APIRouter(prefix='/api/admin/competencies', tags=['Competencias y preguntas'])
MAX_QUESTIONS_PER_CATEGORY = 100
ShortText = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=300)]
BASE_ENTRIES = {
    key: {
        'id': key, 'category_id': category_id, 'name': COMPETENCIES[key],
        'questions': [question for question in QUESTIONS if question['competency_id'] == key],
    }
    for category_id, profile in PROFILES.items()
    for key in profile['requirements']
}


class QuestionInput(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    id: str | None = Field(default=None, min_length=1, max_length=50)
    text: str = Field(min_length=3, max_length=600)
    weight: int = Field(ge=1, le=10, strict=True)
    options: list[ShortText] = Field(min_length=2, max_length=6)
    correct_index: int = Field(ge=0, strict=True)

    @model_validator(mode='after')
    def validate_options(self):
        if self.correct_index >= len(self.options):
            raise ValueError('Selecciona una respuesta correcta.')
        if len({option.casefold() for option in self.options}) != len(self.options):
            raise ValueError('Las opciones de una pregunta deben ser distintas.')
        return self


class CompetencyInput(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    expected_revision: int = Field(ge=0, strict=True)
    category_id: str
    name: str = Field(min_length=2, max_length=120)
    questions: list[QuestionInput] = Field(min_length=1, max_length=MAX_QUESTIONS_PER_CATEGORY)


def catalog_document(db):
    return db.competency_catalog.find_one({'_id': 'current'}) or {'revision': 0, 'entries': {}}


def competency_entries(db):
    return {**BASE_ENTRIES, **catalog_document(db)['entries']}


def view(revision, entries):
    return {'revision': revision, 'competencies': sorted(entries.values(), key=lambda row: row['name'].casefold())}


@router.get('')
def list_competencies(request: Request):
    require_role(current_user(request), 'admin')
    document = catalog_document(request.app.state.db)
    return view(document['revision'], {**BASE_ENTRIES, **document['entries']})


def save_competency(db, user, body, competency_id=None):
    catalog = catalog_document(db)
    if catalog['revision'] != body.expected_revision:
        raise HTTPException(409, 'El banco cambió en otra ventana. Recarga antes de editar nuevamente.')
    entries = {**BASE_ENTRIES, **catalog['entries']}
    previous = entries.get(competency_id)
    if competency_id and previous is None:
        raise HTTPException(404, 'La competencia no existe.')
    if body.category_id not in PROFILES or (previous and previous['category_id'] != body.category_id):
        raise HTTPException(422, 'Selecciona una categoría válida. La categoría de una competencia existente se conserva.')
    category_entries = [row for row in entries.values() if row['category_id'] == body.category_id]
    if any(row['id'] != competency_id and row['name'].casefold() == body.name.casefold() for row in category_entries):
        raise HTTPException(409, 'Ya existe una competencia con ese nombre en esta categoría.')
    question_count = len(body.questions) + sum(len(row['questions']) for row in category_entries if row['id'] != competency_id)
    if question_count > MAX_QUESTIONS_PER_CATEGORY:
        raise HTTPException(422, f'El banco de cada categoría admite hasta {MAX_QUESTIONS_PER_CATEGORY} preguntas.')

    question_ids = [row.id for row in body.questions if row.id]
    previous_ids = {row['id'] for row in previous['questions']} if previous else set()
    if len(question_ids) != len(set(question_ids)) or not set(question_ids) <= previous_ids:
        raise HTTPException(422, 'Las preguntas existentes deben pertenecer a esta competencia y aparecer una sola vez.')

    key = competency_id or str(uuid4())
    questions = []
    for row in body.questions:
        options = [{'id': chr(ord('a') + index), 'text': option} for index, option in enumerate(row.options)]
        questions.append({
            'id': row.id or str(uuid4()), 'competency_id': key, 'text': row.text,
            'weight': row.weight, 'options': options, 'correct': options[row.correct_index]['id'],
        })
    entry = {'id': key, 'category_id': body.category_id, 'name': body.name, 'questions': questions}
    if entry == previous:
        return view(catalog['revision'], entries)

    updated_fields = {
        'entries.' + key: entry,
        'updated_at': datetime.now(timezone.utc),
        'updated_by': user['_id'],
    }
    try:
        result = db.competency_catalog.update_one(
            {'_id': 'current', 'revision': body.expected_revision},
            {'$set': updated_fields, '$inc': {'revision': 1}},
            upsert=body.expected_revision == 0,
        )
    except DuplicateKeyError:
        raise HTTPException(409, 'El banco cambió en otra ventana. Recarga antes de editar nuevamente.')
    if result.matched_count == 0 and result.upserted_id is None:
        raise HTTPException(409, 'El banco cambió en otra ventana. Recarga antes de editar nuevamente.')
    return view(body.expected_revision + 1, {**entries, key: entry})


@router.post('', status_code=201)
def create_competency(body: CompetencyInput, request: Request):
    user = current_user(request)
    require_role(user, 'admin')
    return save_competency(request.app.state.db, user, body)


@router.put('/{competency_id}')
def update_competency(competency_id: str, body: CompetencyInput, request: Request):
    user = current_user(request)
    require_role(user, 'admin')
    return save_competency(request.app.state.db, user, body, competency_id)
