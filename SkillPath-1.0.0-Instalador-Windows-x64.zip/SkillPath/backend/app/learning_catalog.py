"""Recursos de demostración; niveles y tiempos pendientes de validación funcional."""
import json
from pathlib import Path

CATALOG_VERSION = 'learning-categories-2'
RESOURCES = json.loads(Path(__file__).with_name('learning_resources.json').read_text(encoding='utf-8'))
