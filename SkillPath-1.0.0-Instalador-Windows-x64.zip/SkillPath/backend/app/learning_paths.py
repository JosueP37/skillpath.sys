from datetime import datetime, timezone
from uuid import UUID, uuid4

from fastapi import APIRouter, HTTPException, Request, Response
from pymongo.errors import DuplicateKeyError, PyMongoError

from .recommendation import build_learning_path
from .resources import resource_catalog
from .auth import current_user, authorized_evaluation

router = APIRouter(prefix='/api/evaluations', tags=['Rutas de aprendizaje'])


def _evaluation_id(value: str) -> str:
    try:
        if str(UUID(value)) != value:
            raise ValueError
    except ValueError:
        raise HTTPException(404, 'La evaluación no existe.')
    return value


def path_view(document):
    return {
        'id': document['_id'], 'evaluation_id': document['evaluation_id'],
        'created_at': document['created_at'].replace(tzinfo=timezone.utc).isoformat(timespec='milliseconds'),
        **{key: document[key] for key in [
            'profile_name', 'rules_version', 'catalog_version', 'mode', 'items',
            'priorities', 'uncovered_competencies', 'gap_count', 'covered_gap_count',
            'estimated_minutes', 'status', 'explanation', 'catalog_note',
        ]},
    }


@router.get('/{evaluation_id}/learning-path')
def saved_path(evaluation_id: str, request: Request):
    user = current_user(request)
    _evaluation_id(evaluation_id)
    try:
        authorized_evaluation(request.app.state.db, user, evaluation_id)
        document = request.app.state.db.learning_paths.find_one({'evaluation_id': evaluation_id})
    except PyMongoError:
        raise HTTPException(503, 'No se pudo consultar la ruta de aprendizaje.')
    if document is None:
        raise HTTPException(404, 'Aún no hay una ruta guardada para esta evaluación.')
    return path_view(document)


@router.post('/{evaluation_id}/learning-path', status_code=201)
def generate_path(evaluation_id: str, request: Request, response: Response):
    user = current_user(request)
    _evaluation_id(evaluation_id)
    db = request.app.state.db
    try:
        evaluation = authorized_evaluation(db, user, evaluation_id)
        existing = db.learning_paths.find_one({'evaluation_id': evaluation_id})
        if existing is not None:
            response.status_code = 200
            return path_view(existing)
        catalog = resource_catalog(db)
        document = {
            '_id': str(uuid4()), 'evaluation_id': evaluation_id,
            'created_at': datetime.now(timezone.utc), 'schema_version': 1, 'mode': 'demo',
            'profile_name': evaluation['profile_name'],
            'assessment_version': evaluation['assessment_version'],
            **build_learning_path(evaluation, catalog['resources'], catalog['version']),
        }
        try:
            db.learning_paths.insert_one(document)
        except DuplicateKeyError:
            # Una generación simultánea ya guardó la misma ruta.
            document = db.learning_paths.find_one({'evaluation_id': evaluation_id})
            if document is None:
                raise HTTPException(503, 'No se pudo recuperar la ruta. Intenta nuevamente.')
            response.status_code = 200
        return path_view(document)
    except PyMongoError:
        raise HTTPException(503, 'No se pudo guardar la ruta de aprendizaje. Intenta nuevamente.')

