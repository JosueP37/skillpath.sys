"""Ejemplos ficticios solicitados: dos administradores y tres usuarios."""
from datetime import datetime, timedelta, timezone
from uuid import NAMESPACE_URL, uuid5
from .auth import PASSWORDS, indexes
from .catalog import VERSION, questions_for_profile
from .evaluation_records import make_document, attach_comparison
from .recommendation import build_learning_path

ADMIN_PASSWORD = 'AdminDemo!2026'
USER_PASSWORD = 'UsuarioDemo!2026'


def demo_id(label):
    return str(uuid5(NAMESPACE_URL, 'skillpath-local-demo/' + label))


ACCOUNTS = [
    ('ana.admin@skillpath.test', 'Ana Torres', 'admin', None),
    ('luis.admin@skillpath.test', 'Luis Medina', 'admin', None),
    ('carla@skillpath.test', 'Carla Ruiz', 'user', 'ana.admin@skillpath.test'),
    ('diego@skillpath.test', 'Diego Pérez', 'user', 'ana.admin@skillpath.test'),
    ('lucia@skillpath.test', 'Lucía Gómez', 'user', 'luis.admin@skillpath.test'),
]


def seed_demo(db, examples=True):
    indexes(db)
    # Una cuenta existente ajena al seed nunca se sustituye ni se eleva de rol.
    for email, name, role, responsible in ACCOUNTS:
        existing = db.users.find_one({'email': email})
        if existing and (existing['_id'] != demo_id(email) or not existing.get('demo_seed')):
            raise ValueError('El correo de ejemplo ya pertenece a otra cuenta: ' + email)
        if existing and (existing['role'] != role or not existing.get('active') or existing.get('administrator_id') != (demo_id(responsible) if responsible else None)):
            raise ValueError('La cuenta de ejemplo fue modificada; no se sobrescribe: ' + email)
    now = datetime.now(timezone.utc)
    for email, name, role, responsible in ACCOUNTS:
        if db.users.find_one({'_id': demo_id(email)}):
            continue
        administrator_id = demo_id(responsible) if responsible else None
        if role == 'user' and not db.users.find_one({'_id': administrator_id, 'role': 'admin', 'active': True}):
            raise ValueError('Falta el administrador del usuario de ejemplo.')
        db.users.insert_one({
            '_id': demo_id(email), 'name': name, 'email': email, 'role': role,
            'administrator_id': administrator_id, 'password_hash': PASSWORDS.hash(ADMIN_PASSWORD if role == 'admin' else USER_PASSWORD),
            'active': True, 'created_at': now, 'demo_seed': True,
        })
    if examples:
        cases = [
            ('carla@skillpath.test', 'desarrollo-web', set(), {1, 2, 3}, 3),
            ('diego@skillpath.test', 'soporte-ti', {1}, {1, 3}, 2),
            ('lucia@skillpath.test', 'infraestructura-virtualizacion', {2}, {2, 3}, 1),
        ]
        for email, profile, first_weights, latest_weights, completed in cases:
            user = db.users.find_one({'_id': demo_id(email)})
            previous = None
            for stage, weights in [('initial', first_weights), ('latest', latest_weights)]:
                identifier = demo_id(email + '/evaluation/' + stage)
                doc = db.evaluations.find_one({'_id': identifier})
                if not doc:
                    answers = [{'question_id': q['id'], 'option_id': q['correct'] if q['weight'] in weights else next(option['id'] for option in q['options'] if option['id'] != q['correct'])} for q in questions_for_profile(profile)]
                    created = now - timedelta(days=3 if stage == 'initial' else 1)
                    doc = make_document(user, profile, VERSION, answers, created, identifier)
                    doc['demo_seed'] = True
                    if previous:
                        attach_comparison(doc, previous)
                    db.evaluations.insert_one(doc)
                path = db.learning_paths.find_one({'evaluation_id': identifier})
                if not path:
                    path = {'_id': demo_id(email + '/path/' + stage), 'evaluation_id': identifier, 'created_at': doc['created_at'], 'schema_version': 1, 'mode': 'demo', 'demo_seed': True, 'profile_name': doc['profile_name'], 'assessment_version': doc['assessment_version'], **build_learning_path(doc)}
                    db.learning_paths.insert_one(path)
                if stage == 'initial' and not db.learning_progress.find_one({'evaluation_id': identifier}):
                    activities, events = {}, []
                    for index, item in enumerate(path['items'][:completed]):
                        resource = item['resource']
                        updated = doc['created_at'] + timedelta(hours=index + 2)
                        note = 'Práctica ficticia de demostración: ' + resource['title'] + '.'
                        activities[resource['id']] = {'status': 'completed', 'note': note, 'updated_at': updated}
                        events.append({'id': demo_id(email + '/event/' + resource['id']), 'resource_id': resource['id'], 'title': resource['title'], 'previous_status': 'pending', 'status': 'completed', 'note': note, 'created_at': updated, 'actor_user_id': user['_id'], 'actor_name': user['name']})
                    db.learning_progress.insert_one({'_id': path['_id'], 'evaluation_id': identifier, 'schema_version': 1, 'demo_seed': True, 'version': len(events), 'activities': activities, 'events': events, 'event_count': len(events), 'updated_at': events[-1]['created_at'] if events else None})
                previous = doc
    return {'administrators': 2, 'users': 3, 'examples': examples}
