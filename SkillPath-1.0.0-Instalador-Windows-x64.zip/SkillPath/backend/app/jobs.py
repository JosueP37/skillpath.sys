"""RF-04: puestos y matriz dentro de las cuatro categorías confirmadas."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from uuid import uuid4
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError
from .auth import current_user, require_role
from .catalog import PROFILES, VERSION, _CATALOG
from .competencies import BASE_ENTRIES, MAX_QUESTIONS_PER_CATEGORY, competency_entries
from .progress import iso

router = APIRouter(prefix='/api/job-profiles', tags=['Puestos y competencias'])


class Binding(BaseModel):
    model_config = ConfigDict(extra='forbid')
    competency_id: str = Field(min_length=1, max_length=50)
    required: int = Field(ge=1, le=100, strict=True)
    criticality: int = Field(ge=1, le=5, strict=True)


class JobInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    category_id: str = Field(min_length=1, max_length=50)
    name: str = Field(min_length=2, max_length=100)
    description: str = Field(max_length=500)
    active: bool = Field(default=True, strict=True)
    competencies: list[Binding] = Field(min_length=1, max_length=MAX_QUESTIONS_PER_CATEGORY)

    @field_validator('name', 'description')
    @classmethod
    def trim(cls, value):
        return value.strip()

    def checked(self, db):
        if self.category_id not in PROFILES or len(self.name) < 2:
            raise HTTPException(422, 'Selecciona una categoría e ingresa un nombre de puesto válido.')
        ids = [row.competency_id for row in self.competencies]
        entries = competency_entries(db)
        if len(ids) != len(set(ids)) or any(entries.get(key, {}).get('category_id') != self.category_id for key in ids):
            raise HTTPException(422, 'Asocia competencias distintas de la categoría seleccionada.')
        return self.model_dump()


class JobUpdate(JobInput):
    expected_revision: int = Field(ge=1, strict=True)


def job_view(doc, include_history=False):
    result = {'id': doc['_id'], **{key: doc[key] for key in ['category_id', 'name', 'description', 'active', 'competencies', 'revision']}, 'updated_at': iso(doc['updated_at']), 'updated_by': doc['updated_by']}
    if include_history:
        result['history'] = [{**event, 'at': iso(event['at'])} for event in reversed(doc['history'])]
    return result


def event(user, data, revision):
    return {'revision': revision, 'at': datetime.now(timezone.utc), 'actor_id': user['_id'], 'actor_name': user['name'], 'configuration': data}


@router.get('')
def jobs(request: Request, category_id: str | None = None, include_inactive: bool = False):
    user = current_user(request)
    if include_inactive:
        require_role(user, 'admin')
    if category_id is not None and category_id not in PROFILES:
        raise HTTPException(422, 'La categoría no existe.')
    query = {} if include_inactive else {'active': True}
    if category_id:
        query['category_id'] = category_id
    return [job_view(doc) for doc in request.app.state.db.job_profiles.find(query).sort([('category_id', 1), ('name', 1)])]


@router.get('/{job_id}')
def job_detail(job_id: str, request: Request):
    user = current_user(request)
    query = {'_id': job_id}
    if user['role'] != 'admin':
        query['active'] = True
    doc = request.app.state.db.job_profiles.find_one(query)
    if not doc:
        raise HTTPException(404, 'El puesto no está disponible.')
    return job_view(doc, user['role'] == 'admin')


@router.post('', status_code=201)
def create_job(body: JobInput, request: Request):
    user = current_user(request)
    require_role(user, 'admin')
    data = body.checked(request.app.state.db)
    record = event(user, data, 1)
    doc = {'_id': str(uuid4()), **data, 'normalized_name': data['name'].casefold(), 'revision': 1, 'updated_at': record['at'], 'updated_by': user['name'], 'history': [record]}
    try:
        request.app.state.db.job_profiles.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(409, 'Ya existe un puesto con ese nombre en esta categoría.')
    return job_view(doc, True)


@router.put('/{job_id}')
def update_job(job_id: str, body: JobUpdate, request: Request):
    user = current_user(request)
    require_role(user, 'admin')
    data = body.checked(request.app.state.db)
    data.pop('expected_revision')
    old = request.app.state.db.job_profiles.find_one({'_id': job_id})
    if not old:
        raise HTTPException(404, 'El puesto no existe.')
    if old['category_id'] != data['category_id']:
        raise HTTPException(422, 'La categoría de un puesto existente se conserva. Crea otro puesto para otra categoría.')
    record = event(user, data, body.expected_revision + 1)
    try:
        doc = request.app.state.db.job_profiles.find_one_and_update(
            {'_id': job_id, 'revision': body.expected_revision},
            {'$set': {**data, 'normalized_name': data['name'].casefold(), 'updated_at': record['at'], 'updated_by': user['name']}, '$inc': {'revision': 1}, '$push': {'history': {'$each': [record], '$slice': -100}}},
            return_document=ReturnDocument.AFTER)
    except DuplicateKeyError:
        raise HTTPException(409, 'Ya existe un puesto con ese nombre en esta categoría.')
    if not doc:
        raise HTTPException(409, 'El puesto cambió en otra ventana. Recarga antes de guardar.')
    return job_view(doc, True)


def assessment_catalog(db, category_id, job_id=None, entries=None):
    """Compone el instrumento y su versión con los datos que realmente utiliza."""
    if category_id not in PROFILES:
        return _CATALOG, None  # evaluate() valida este caso al enviar respuestas.
    entries = competency_entries(db) if entries is None else entries
    profile = PROFILES[category_id]
    version = VERSION
    job = None
    if job_id:
        job = db.job_profiles.find_one({'_id': job_id, 'category_id': category_id, 'active': True})
        if not job:
            raise HTTPException(404, 'El puesto no está activo en esta categoría.')
        profile = {
            **profile,
            'requirements': {row['competency_id']: row['required'] for row in job['competencies']},
            'criticality': {row['competency_id']: row['criticality'] for row in job['competencies']},
        }
        version += '/job-' + job['_id'] + '/r' + str(job['revision'])
    selected = [entries[key] for key in PROFILES[category_id]['requirements'] if key in profile['requirements']]
    selected += [entries[key] for key in profile['requirements'] if key not in BASE_ENTRIES]
    if any(entry != BASE_ENTRIES.get(entry['id']) for entry in selected):
        contents = json.dumps(selected, ensure_ascii=False, sort_keys=True).encode('utf-8')
        version += '/q-' + sha256(contents).hexdigest()[:20]
    source = {
        'version': version,
        'profiles': {category_id: profile},
        'competencies': {entry['id']: entry['name'] for entry in selected},
        'questions': [question for entry in selected for question in entry['questions']],
    }
    return source, job
