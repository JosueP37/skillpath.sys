from copy import deepcopy

import pytest

from app.catalog import QUESTIONS, VERSION, public_assessment, questions_for_profile
from app.learning_catalog import RESOURCES
from app.recommendation import build_learning_path
from app.scoring import evaluate


def evaluation(profile='desarrollo-web', scores=None):
    scores = scores or {'web': 0, 'javascript': 0, 'http': 0}
    answers = []
    for question in questions_for_profile(profile):
        score = scores[question['competency_id']]
        correct = score == 100 or score == 50 and question['weight'] == 3
        option = question['correct'] if correct else next(option['id'] for option in question['options'] if option['id'] != question['correct'])
        answers.append({'question_id': question['id'], 'option_id': option})
    return {**evaluate(profile, VERSION, answers), 'assessment_snapshot': public_assessment(profile)}


def test_route_excludes_achieved_competencies_and_matches_entry_level():
    diagnosis = evaluation(scores={'web': 100, 'javascript': 50, 'http': 100})
    path = build_learning_path(diagnosis)
    assert path['status'] == 'ready'
    assert path['gap_count'] == path['covered_gap_count'] == 1
    assert [item['resource']['id'] for item in path['items']] == ['javascript-practice']
    assert path['estimated_minutes'] == 90
    assert '30 puntos' in path['items'][0]['reason']
    assert '37.5 % relativo' in path['items'][0]['reason']
    assert diagnosis['results'][1]['current'] == 50


def test_criticality_and_gap_order_with_prerequisites_first():
    path = build_learning_path(evaluation(scores={'web': 0, 'javascript': 50, 'http': 0}))
    assert [row['competency_id'] for row in path['priorities']] == ['http', 'web', 'javascript']
    ids = [item['resource']['id'] for item in path['items']]
    assert ids == ['http-base', 'http-practice', 'web-base', 'web-practice', 'javascript-practice']
    assert len(ids) == len(set(ids))
    assert path['items'][0]['role'] == 'prerequisite'
    assert path['items'][1]['role'] == 'main'
    assert path['estimated_minutes'] == 390
    assert path['covered_gap_count'] == 3


def test_no_gaps_has_no_assigned_resources_or_fake_coverage():
    path = build_learning_path(evaluation(scores={'web': 100, 'javascript': 100, 'http': 100}))
    assert path['status'] == 'no_gaps'
    assert path['items'] == path['uncovered_competencies'] == []
    assert path['gap_count'] == path['covered_gap_count'] == path['estimated_minutes'] == 0


def test_legacy_evaluation_uses_neutral_criticality_and_stable_ties():
    diagnosis = evaluation(profile='desarrollo-web')
    for row in diagnosis['assessment_snapshot']['competencies']:
        del row['criticality']
    path = build_learning_path(diagnosis)
    diagnosis['results'].reverse()
    again = build_learning_path(diagnosis)
    assert path['items'] == again['items']
    assert path['priorities'] == again['priorities']
    assert [row['criticality'] for row in path['priorities']] == [1, 1, 1]
    assert [row['competency_id'] for row in path['priorities']] == ['http', 'web', 'javascript']


def test_missing_content_produces_partial_coverage_without_inventing_a_course():
    catalog = [resource for resource in RESOURCES if resource['competency_id'] != 'javascript']
    path = build_learning_path(evaluation(), catalog)
    assert path['status'] == 'partial'
    assert path['gap_count'] == 3 and path['covered_gap_count'] == 2
    assert path['uncovered_competencies'][0]['competency_id'] == 'javascript'
    assert all(item['competency_id'] != 'javascript' for item in path['items'])


@pytest.mark.parametrize('problem', ['unapproved', 'missing', 'cycle', 'cross_competency', 'insufficient_level'])
def test_invalid_prerequisites_and_ineligible_resources_are_not_assigned(problem):
    catalog = deepcopy(RESOURCES)
    base = next(resource for resource in catalog if resource['id'] == 'web-base')
    main = next(resource for resource in catalog if resource['id'] == 'web-practice')
    if problem == 'unapproved':
        base['approved'] = False
    elif problem == 'missing':
        main['prerequisite_ids'] = ['missing']
    elif problem == 'cycle':
        base['entry_score'] = 10
        base['prerequisite_ids'] = ['web-practice']
    elif problem == 'cross_competency':
        main['prerequisite_ids'] = ['javascript-base']
    else:
        main['target_score'] = 70
    path = build_learning_path(evaluation(scores={'web': 0, 'javascript': 100, 'http': 100}), catalog)
    assert path['status'] == 'uncovered'
    assert path['items'] == []
    assert path['covered_gap_count'] == 0
    assert path['uncovered_competencies'][0]['competency_id'] == 'web'


def test_resource_snapshot_survives_changes_to_the_source_catalog():
    catalog = deepcopy(RESOURCES)
    path = build_learning_path(evaluation(), catalog)
    title = path['items'][0]['resource']['title']
    next(item for item in catalog if item['id'] == 'http-base')['title'] = 'Cambio posterior'
    assert path['items'][0]['resource']['title'] == title

