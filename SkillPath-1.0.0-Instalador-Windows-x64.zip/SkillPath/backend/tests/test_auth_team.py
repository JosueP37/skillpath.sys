"""RF-06 y relación 1:N: MongoDB real, bases aisladas y login público."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from uuid import uuid4
import pytest
from fastapi.testclient import TestClient
from app.auth import COOKIE, PASSWORDS, token_digest
from app.demo_seed import seed_demo, demo_id, ADMIN_PASSWORD, USER_PASSWORD
from app.main import create_app
from test_api_mongodb import URI, body, demo_database


def login(client, email='carla@skillpath.test'):
    response = client.post('/api/auth/login', json={'email': email, 'password': ADMIN_PASSWORD if '.admin@' in email else USER_PASSWORD})
    assert response.status_code == 200, response.text
    client.headers['X-CSRF-Token'] = response.json()['csrf_token']
    return response


@pytest.fixture
def accounts(demo_database):
    with TestClient(create_app(URI, demo_database[0])) as client:
        seed_demo(demo_database[1])
        yield client, demo_database[1]


def registration(administrator_id=None, **extra):
    return {'name': 'Nueva Persona', 'email': 'nueva@skillpath.test', 'password': 'NuevaClave!2026', 'administrator_id': administrator_id or demo_id('ana.admin@skillpath.test'), **extra}


def test_no_admin_no_registration(demo_database):
    with TestClient(create_app(URI, demo_database[0])) as client:
        assert client.get('/api/auth/administrators').json() == []
        assert client.post('/api/auth/register', json=registration()).status_code == 422
        payload = registration(); del payload['administrator_id']
        assert client.post('/api/auth/register', json=payload).status_code == 422
        assert demo_database[1].users.count_documents({}) == 0


@pytest.mark.parametrize('invalid', ['not-uuid', demo_id('missing'), demo_id('carla@skillpath.test')])
def test_invalid_administrator(accounts, invalid):
    client, db = accounts
    assert client.post('/api/auth/register', json=registration(invalid)).status_code == 422
    assert db.users.count_documents({}) == 5


def test_registration_hashed_and_assigned_to_chosen_admin(accounts):
    client, db = accounts
    public = client.get('/api/auth/administrators').json()
    assert len(public) == 2 and all(set(row) == {'id', 'name'} for row in public)
    payload = registration(demo_id('luis.admin@skillpath.test'), email=' NUEVA@skillpath.test ')
    response = client.post('/api/auth/register', json=payload)
    assert response.status_code == 201
    assert response.json()['user']['role'] == 'user'
    assert response.json()['user']['administrator']['name'] == 'Luis Medina'
    doc = db.users.find_one({'email': 'nueva@skillpath.test'})
    assert doc['password_hash'].startswith('$argon2id$') and 'password' not in doc
    assert PASSWORDS.verify(doc['password_hash'], payload['password'])
    assert 'password_hash' not in response.text
    assert client.get('/api/auth/me').json()['user']['id'] == doc['_id']
    assert client.post('/api/auth/register', json=payload).status_code == 409
    login(client, 'ana.admin@skillpath.test')
    assert len(client.get('/api/team').json()['members']) == 2
    assert client.get('/api/team/' + doc['_id']).status_code == 404
    login(client, 'luis.admin@skillpath.test')
    assert len(client.get('/api/team').json()['members']) == 2


@pytest.mark.parametrize('extra', [{'role': 'admin'}, {'user_id': demo_id('ana.admin@skillpath.test')}, {'active': True}])
def test_cannot_forge_registration_role(accounts, extra):
    client, db = accounts
    assert client.post('/api/auth/register', json=registration(**extra)).status_code == 422
    assert db.users.count_documents({}) == 5


def test_inactive_admin_blocks_signup_and_login(accounts):
    client, db = accounts
    db.users.update_one({'_id': demo_id('ana.admin@skillpath.test')}, {'$set': {'active': False}})
    assert client.post('/api/auth/register', json=registration()).status_code == 422
    assert client.post('/api/auth/login', json={'email': 'carla@skillpath.test', 'password': USER_PASSWORD}).status_code == 403


@pytest.mark.parametrize('endpoint', ['/api/profiles', '/api/profiles/desarrollo-web/assessment', '/api/evaluations', '/api/dashboard', '/api/team', '/api/evaluations/' + demo_id('carla@skillpath.test/evaluation/initial') + '/progress'])
def test_requires_login(accounts, endpoint):
    assert accounts[0].get(endpoint).status_code == 401


def test_session_csrf_expiry_revocation(accounts):
    client, db = accounts
    response = login(client)
    assert 'HttpOnly' in response.headers['set-cookie'] and 'SameSite=lax' in response.headers['set-cookie']
    raw = client.cookies.get(COOKIE)
    assert db.sessions.find_one({'_id': token_digest(raw)}) and not db.sessions.find_one({'_id': raw})
    client.headers.pop('X-CSRF-Token')
    assert client.post('/api/evaluations', json=body()).status_code == 403
    client.headers['X-CSRF-Token'] = 'forged'
    assert client.post('/api/auth/logout').status_code == 403
    assert client.post('/api/evaluations', json=body(), headers={b'X-CSRF-Token': b'\xff'}).status_code == 403
    client.headers['X-CSRF-Token'] = response.json()['csrf_token']
    assert client.post('/api/evaluations', json=body(), headers={'Origin': 'https://outside.example'}).status_code == 403
    assert client.post('/api/auth/logout').status_code == 204
    assert not db.sessions.find_one({'_id': token_digest(raw)})
    client.cookies.set(COOKIE, raw, domain='testserver.local', path='/api')
    assert client.get('/api/auth/me').status_code == 401
    login(client); raw = client.cookies.get(COOKIE)
    db.sessions.update_one({'_id': token_digest(raw)}, {'$set': {'expires_at': datetime.now(timezone.utc) - timedelta(seconds=1)}})
    assert client.get('/api/auth/me').status_code == 401


def test_session_survives_new_connection(accounts, demo_database):
    response = login(accounts[0]); raw = accounts[0].cookies.get(COOKIE)
    with TestClient(create_app(URI, demo_database[0])) as other:
        other.cookies.set(COOKIE, raw, domain='testserver.local', path='/api')
        assert other.get('/api/auth/me').json() == response.json()


def test_rate_limit_generic_errors_and_origin(accounts):
    client, _ = accounts
    assert client.post('/api/auth/login', json={'email': 'carla@skillpath.test', 'password': USER_PASSWORD}, headers={'Origin': 'https://outside.example'}).status_code == 403
    messages = []
    for email in ['missing@skillpath.test', 'carla@skillpath.test']:
        response = client.post('/api/auth/login', json={'email': email, 'password': 'wrong'})
        assert response.status_code == 401
        messages.append(response.json()['detail'])
    assert messages[0] == messages[1]
    for _ in range(4):
        assert client.post('/api/auth/login', json={'email': 'carla@skillpath.test', 'password': 'wrong'}).status_code == 401
    assert client.post('/api/auth/login', json={'email': 'carla@skillpath.test', 'password': USER_PASSWORD}).status_code == 429


@pytest.mark.parametrize('email,count,others', [('ana.admin@skillpath.test', 2, 'lucia@skillpath.test'), ('luis.admin@skillpath.test', 1, 'carla@skillpath.test')])
def test_one_to_many_team_scope(accounts, email, count, others):
    client, _ = accounts; login(client, email)
    members = client.get('/api/team').json()['members']
    assert len(members) == count
    history = client.get('/api/evaluations').json()
    assert len(history) == count * 2
    assert {row['user_id'] for row in history} == {row['id'] for row in members}
    dashboard = client.get('/api/dashboard').json()
    assert dashboard['metrics']['evaluation_count'] == count * 2
    assert dashboard['assigned_user_count'] == count
    for endpoint in ['/api/team/' + demo_id(others), '/api/evaluations?user_id=' + demo_id(others), '/api/dashboard?user_id=' + demo_id(others)]:
        assert client.get(endpoint).status_code == 404
    assert 'password_hash' not in str(members)


@pytest.mark.parametrize('email,forbidden', [('carla@skillpath.test', 'diego@skillpath.test'), ('ana.admin@skillpath.test', 'lucia@skillpath.test')])
def test_guessed_ids_rejected_for_all_resources(accounts, email, forbidden):
    client, db = accounts; login(client, email)
    eid = demo_id(forbidden + '/evaluation/initial'); endpoint = '/api/evaluations/' + eid
    for suffix in ['', '/learning-path', '/progress']:
        assert client.get(endpoint + suffix).status_code == 404
    before = db.learning_paths.find_one({'evaluation_id': eid})
    assert client.post(endpoint + '/learning-path').status_code == 404
    assert db.learning_paths.find_one({'evaluation_id': eid}) == before
    if '.admin@' not in email:
        assert client.put(endpoint + '/progress/' + before['items'][0]['resource']['id'], json={'status': 'completed', 'note': 'Ajeno.', 'expected_version': 1}).status_code == 404
        payload = body(); payload['previous_evaluation_id'] = eid
        assert client.post('/api/evaluations', json=payload).status_code == 404


def test_user_self_only_admin_read_only(accounts):
    client, db = accounts; login(client)
    assert len(client.get('/api/evaluations').json()) == 2
    assert client.get('/api/team').status_code == 403
    assert client.get('/api/dashboard').json()['metrics']['evaluation_count'] == 2
    eid = demo_id('carla@skillpath.test/evaluation/initial'); endpoint = '/api/evaluations/' + eid
    route = client.get(endpoint + '/learning-path').json()
    saved = db.learning_progress.find_one({'evaluation_id': eid})
    login(client, 'ana.admin@skillpath.test')
    assert client.get(endpoint).status_code == 200
    assert client.post(endpoint + '/learning-path').status_code == 200
    assert client.get(endpoint + '/progress').status_code == 200
    assert client.put(endpoint + '/progress/' + route['items'][0]['resource']['id'], json={'status': 'pending', 'note': '', 'expected_version': 3}).status_code == 403
    assert client.post('/api/evaluations', json=body()).status_code == 403
    assert db.learning_progress.find_one({'evaluation_id': eid}) == saved


def test_owner_and_actor_come_from_session(accounts):
    client, db = accounts; login(client)
    payload = body(); payload['user_id'] = demo_id('lucia@skillpath.test')
    assert client.post('/api/evaluations', json=payload).status_code == 422
    result = client.post('/api/evaluations', json=body()).json()
    saved = db.evaluations.find_one({'_id': result['id']})
    assert saved['user_id'] == demo_id('carla@skillpath.test')
    assert saved['administrator_id'] == demo_id('ana.admin@skillpath.test')
    endpoint = '/api/evaluations/' + demo_id('carla@skillpath.test/evaluation/initial') + '/progress'
    progress = client.get(endpoint).json()
    row = next(item for item in progress['items'] if item['status'] == 'pending')
    updated = client.put(endpoint + '/' + row['resource_id'], json={'status': 'in_progress', 'note': 'Práctica propia.', 'expected_version': progress['version']}).json()
    assert updated['events'][0]['actor_user_id'] == demo_id('carla@skillpath.test')


def test_evolution_groups_only_comparable_diagnoses(accounts):
    client, db = accounts; login(client, 'ana.admin@skillpath.test')
    uid = demo_id('carla@skillpath.test')
    original = client.get('/api/team/' + uid).json()['evolution'][0]
    assert original['first_score'] == 0 and original['latest_score'] == 100 and original['score_delta'] == 100
    latest = db.evaluations.find_one({'_id': demo_id('carla@skillpath.test/evaluation/latest')})
    for field, value in [('assessment_version', 'future-version'), ('profile_id', 'another-category')]:
        changed = deepcopy(latest); changed['_id'] = str(uuid4()); changed[field] = value
        db.evaluations.insert_one(changed)
    changed = deepcopy(latest); changed['_id'] = str(uuid4()); changed['results'][0]['required'] += 1
    db.evaluations.insert_one(changed)
    detail = client.get('/api/team/' + uid).json()
    assert sorted(row['evaluation_count'] for row in detail['evolution']) == [1, 1, 1, 2]
    assert sum(row['score_delta'] is None for row in detail['evolution']) == 3


def test_ownerless_history_preserved_and_hidden(accounts):
    client, db = accounts
    original = deepcopy(db.evaluations.find_one({'_id': demo_id('carla@skillpath.test/evaluation/initial')}))
    original['_id'] = str(uuid4())
    for key in ['user_id', 'user_name', 'administrator_id']: original.pop(key)
    db.evaluations.insert_one(original)
    for email in ['carla@skillpath.test', 'ana.admin@skillpath.test', 'luis.admin@skillpath.test']:
        login(client, email)
        assert client.get('/api/evaluations/' + original['_id']).status_code == 404
        assert original['_id'] not in {row['id'] for row in client.get('/api/evaluations').json()}
    assert db.evaluations.find_one({'_id': original['_id']}) == original


def test_seed_idempotence_and_complete_paginated_history(accounts):
    client, db = accounts
    before = {name: list(db[name].find().sort('_id', 1)) for name in ['users', 'evaluations', 'learning_paths', 'learning_progress']}
    seed_demo(db)
    assert before == {name: list(db[name].find().sort('_id', 1)) for name in before}
    login(client)
    for _ in range(21): assert client.post('/api/evaluations', json=body()).status_code == 201
    first = client.get('/api/evaluations').json(); rest = client.get('/api/evaluations?offset=20').json()
    assert len(first) == 20 and len(rest) == 3
    assert not ({row['id'] for row in first} & {row['id'] for row in rest})
    assert client.get('/api/evaluations?offset=-1').status_code == 422


def test_invalid_category_rejected_without_internal_error(accounts):
    client, db = accounts
    login(client)
    payload = body(); payload['profile_id'] = 'unknown'
    before = db.evaluations.count_documents({})
    assert client.post('/api/evaluations', json=payload).status_code == 422
    assert db.evaluations.count_documents({}) == before
