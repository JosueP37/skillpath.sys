from auth_helpers import authenticated_client
from uuid import uuid4
from fastapi.testclient import TestClient
from pymongo import MongoClient
import pytest
from app.catalog import QUESTIONS, VERSION, questions_for_profile
from app.main import create_app

URI = 'mongodb://127.0.0.1:27018'

@pytest.fixture
def demo_database():
    name = 'test_skillpath_' + uuid4().hex
    mongo = MongoClient(URI, serverSelectionTimeoutMS=3000)
    mongo.admin.command('ping')
    try:
        yield name, mongo[name]
    finally:
        # Solo elimina la base aislada creada por esta prueba.
        assert name.startswith('test_skillpath_') and len(name) == len('test_skillpath_') + 32
        mongo.drop_database(name)
        mongo.close()

def body(profile='desarrollo-web'):
    return {'profile_id': profile, 'assessment_version': VERSION, 'answers': [{'question_id': q['id'], 'option_id': q['correct']} for q in questions_for_profile(profile)]}

def test_evaluation_persists_and_can_be_read_after_new_connection(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        assert client.get('/api/health').json()['database'] == 'mongodb'
        public = client.get('/api/profiles/desarrollo-web/assessment').json()
        assert all('correct' not in question for question in public['questions'])
        saved = client.post('/api/evaluations', json=body())
        assert saved.status_code == 201
        result = saved.json()
        assert result['overall_score'] == 100
        assert 'answers' not in result and 'scoring_key_snapshot' not in result
        document = db.evaluations.find_one({'_id': result['id']})
        assert len(document['answers']) == 9
        assert document['assessment_snapshot']['version'] == VERSION
        assert len(document['scoring_key_snapshot']) == 9
    with authenticated_client(name) as client:
        reread = client.get('/api/evaluations/' + result['id'])
        assert reread.status_code == 200
        assert reread.json()['results'] == result['results']
        assert client.get('/api/evaluations').json()[0]['id'] == result['id']

def test_invalid_payload_does_not_create_a_document(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        invalid = body()
        invalid['answers'].pop()
        assert client.post('/api/evaluations', json=invalid).status_code == 422
        invalid = body()
        invalid['answers'].append(invalid['answers'][0])
        assert client.post('/api/evaluations', json=invalid).status_code == 422
        assert db.evaluations.count_documents({}) == 0
        assert client.get('/api/evaluations/' + str(uuid4())).status_code == 404
        assert client.get('/api/profiles/unknown/assessment').status_code == 404

def test_learning_path_is_persistent_idempotent_and_uses_saved_snapshot(demo_database):
    from concurrent.futures import ThreadPoolExecutor
    from app.learning_catalog import RESOURCES
    name, db = demo_database
    payload = body()
    payload['profile_id'] = 'desarrollo-web'
    for answer in payload['answers']:
        if not answer['question_id'].startswith('js'):
            question = next(q for q in QUESTIONS if q['id'] == answer['question_id'])
            answer['option_id'] = next(option['id'] for option in question['options'] if option['id'] != question['correct'])
    with authenticated_client(name) as client:
        result = client.post('/api/evaluations', json=payload).json()
        endpoint = '/api/evaluations/' + result['id'] + '/learning-path'
        assert client.get(endpoint).status_code == 404
        with ThreadPoolExecutor(max_workers=4) as executor:
            responses = list(executor.map(lambda _: client.post(endpoint), range(4)))
        assert all(response.status_code in (200, 201) for response in responses)
        assert sum(response.status_code == 201 for response in responses) == 1
        routes = [response.json() for response in responses]
        assert len({route['id'] for route in routes}) == 1
        route = routes[0]
        assert route['gap_count'] == route['covered_gap_count'] == 2
        assert all(item['competency_id'] != 'javascript' for item in route['items'])
        assert db.learning_paths.count_documents({'evaluation_id': result['id']}) == 1
        document = db.learning_paths.find_one({'_id': route['id']})
        assert document['rules_snapshot']['priority'] == 'brecha_relativa_porcentaje * criticidad'
        assert document['diagnosis_snapshot'] == result['results']
        assert 'answers' not in route and 'scoring_key_snapshot' not in route
    with authenticated_client(name) as client:
        assert client.get(endpoint).json() == route
        source_resource = next(item for item in RESOURCES if item['id'] == route['items'][0]['resource']['id'])
        old_title = source_resource['title']
        try:
            source_resource['title'] = 'Título editado después de generar'
            reread = client.post(endpoint)
            assert reread.status_code == 200
            assert reread.json() == route
        finally:
            source_resource['title'] = old_title


def test_no_gap_route_and_unknown_evaluation_do_not_create_false_assignments(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        for value in ['invalid', str(uuid4())]:
            assert client.post('/api/evaluations/' + value + '/learning-path').status_code == 404
        assert db.learning_paths.count_documents({}) == 0
        result = client.post('/api/evaluations', json=body()).json()
        route = client.post('/api/evaluations/' + result['id'] + '/learning-path')
        assert route.status_code == 201
        assert route.json()['status'] == 'no_gaps'
        assert route.json()['items'] == []
        assert route.json()['estimated_minutes'] == 0
