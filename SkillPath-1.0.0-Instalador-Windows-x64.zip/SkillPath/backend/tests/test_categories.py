from app.demo_seed import demo_id
from auth_helpers import authenticated_client
"""Regresión de categorías y compatibilidad con diagnósticos anteriores."""
from datetime import datetime, timezone
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from app.catalog import PROFILES, questions_for_profile
from app.main import create_app
from test_api_mongodb import URI, body, demo_database
from test_progress_dashboard import wrong_body, update

EXPECTED = [
    ('soporte-ti', 'Soporte TI 24/7/365'),
    ('desarrollo-web', 'Desarrollo Web Moderno'),
    ('infraestructura-virtualizacion', 'Infraestructura y Virtualización'),
    ('redes-ciberseguridad', 'Redes y Ciberseguridad'),
]


def test_only_the_four_confirmed_categories_are_selectable(demo_database):
    name, _ = demo_database
    with authenticated_client(name) as client:
        profiles = client.get('/api/profiles').json()
        assert [(item['id'], item['name']) for item in profiles] == EXPECTED
        assert all(item['competency_count'] == 3 and item['question_count'] == 9 for item in profiles)
        assert client.get('/api/profiles/backend-junior/assessment').status_code == 404
        assert client.get('/api/profiles/backend-intermedio/assessment').status_code == 404


@pytest.mark.parametrize('profile', list(PROFILES))
def test_category_flow_persists_its_own_diagnosis_path_and_progress(profile, demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        assessment = client.get('/api/profiles/' + profile + '/assessment').json()
        assert len(assessment['questions']) == 9
        assert set(q['competency_id'] for q in assessment['questions']) == set(PROFILES[profile]['requirements'])
        assert all('correct' not in q for q in assessment['questions'])
        response = client.post('/api/evaluations', json=wrong_body(profile))
        assert response.status_code == 201
        diagnosis = response.json()
        assert diagnosis['category_active'] is True
        assert diagnosis['overall_score'] == 0 and diagnosis['competencies_with_gap'] == 3
        saved = db.evaluations.find_one({'_id': diagnosis['id']})
        assert {q['question_id'] for q in saved['scoring_key_snapshot']} == {q['id'] for q in assessment['questions']}
        assert len(saved['scoring_key_snapshot']) == 9
        endpoint = '/api/evaluations/' + diagnosis['id']
        route = client.post(endpoint + '/learning-path').json()
        assert route['status'] == 'ready' and route['gap_count'] == route['covered_gap_count'] == 3
        assert len(route['items']) == 6
        assert set(item['competency_id'] for item in route['items']) == set(PROFILES[profile]['requirements'])
        for index in range(0, 6, 2):
            assert route['items'][index]['role'] == 'prerequisite'
            assert route['items'][index + 1]['role'] == 'main'
            assert route['items'][index]['competency_id'] == route['items'][index + 1]['competency_id']
        progress = update(client, endpoint + '/progress', route['items'][0]['resource']['id'], 0).json()
        assert progress['completion_percent'] == 16.67
        assert client.get(endpoint).json() == diagnosis
        reevaluation_body = body(profile)
        reevaluation_body['previous_evaluation_id'] = diagnosis['id']
        reevaluation = client.post('/api/evaluations', json=reevaluation_body).json()
        assert reevaluation['overall_score'] == 100
        assert reevaluation['comparison']['compatible'] is True
        assert reevaluation['comparison']['score_delta'] == 100
        no_gaps = client.post('/api/evaluations/' + reevaluation['id'] + '/learning-path').json()
        assert no_gaps['status'] == 'no_gaps' and no_gaps['items'] == []
        filtered = client.get('/api/dashboard?profile_id=' + profile).json()
        assert filtered['metrics']['evaluation_count'] == 2
        assert filtered['metrics']['completion_percent'] == 16.67
    with authenticated_client(name) as client:
        assert client.get(endpoint + '/progress').json() == progress
        assert client.get(endpoint + '/learning-path').json() == route
        assert client.get(endpoint).json() == diagnosis


@pytest.mark.parametrize('target,other', [
    ('soporte-ti', 'desarrollo-web'),
    ('desarrollo-web', 'infraestructura-virtualizacion'),
    ('infraestructura-virtualizacion', 'redes-ciberseguridad'),
    ('redes-ciberseguridad', 'soporte-ti'),
])
def test_answers_from_another_category_do_not_create_a_diagnosis(target, other, demo_database):
    name, db = demo_database
    payload = body(other)
    payload['profile_id'] = target
    with authenticated_client(name) as client:
        assert client.post('/api/evaluations', json=payload).status_code == 422
        assert db.evaluations.count_documents({}) == 0


def test_stale_assessment_does_not_score_new_questions(demo_database):
    name, db = demo_database
    payload = body()
    payload['assessment_version'] = 'demo-1'
    with authenticated_client(name) as client:
        assert client.post('/api/evaluations', json=payload).status_code == 422
        assert db.evaluations.count_documents({}) == 0


def test_legacy_diagnosis_remains_readable_with_its_original_resources(demo_database):
    name, db = demo_database
    rows = [
        {'competency_id': cid, 'competency_name': label, 'required': required,
         'current': 0, 'gap_points': required, 'gap_percent': 100, 'achieved': False,
         'earned_weight': 0, 'total_weight': 6}
        for cid, label, required in [
            ('python', 'Fundamentos de Python', 65),
            ('sql', 'Consultas y datos SQL', 65),
            ('http', 'APIs y protocolo HTTP', 70),
        ]
    ]
    legacy = {
        '_id': str(uuid4()), 'created_at': datetime.now(timezone.utc),
        'user_id': demo_id('carla@skillpath.test'), 'user_name': 'Carla Ruiz',
        'profile_id': 'backend-junior', 'profile_name': 'Desarrollador backend junior',
        'assessment_version': 'demo-1', 'algorithm_version': 'weighted-gap-1',
        'mode': 'demo', 'results': rows, 'competencies_with_gap': 3,
        'competencies_achieved': 0, 'overall_score': 0, 'question_count': 9, 'calculation_ms': 0,
        'assessment_snapshot': {'competencies': [{'id': row['competency_id']} for row in rows]},
    }
    db.evaluations.insert_one(legacy)
    original = db.evaluations.find_one({'_id': legacy['_id']})
    with authenticated_client(name) as client:
        endpoint = '/api/evaluations/' + legacy['_id']
        diagnosis = client.get(endpoint).json()
        assert diagnosis['category_active'] is False
        assert diagnosis['results'] == rows
        route = client.post(endpoint + '/learning-path').json()
        assert route['status'] == 'ready'
        assert {item['resource']['id'] for item in route['items']} == {'python-base', 'sql-base', 'http-base'}
        progress = update(client, endpoint + '/progress', route['items'][0]['resource']['id'], 0).json()
        assert progress['completed_activities'] == 1
        assert db.evaluations.find_one({'_id': legacy['_id']}) == original
        dashboard = client.get('/api/dashboard').json()
        assert dashboard['metrics']['evaluation_count'] == 0
        assert dashboard['metrics']['archived_evaluation_count'] == 1
        assert client.get('/api/evaluations').json()[0] == diagnosis
        payload = body()
        payload['previous_evaluation_id'] = legacy['_id']
        assert client.post('/api/evaluations', json=payload).status_code == 422
        assert db.evaluations.count_documents({}) == 1
