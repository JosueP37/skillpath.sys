"""Cliente autenticado real para la regresión de RF-01/02/03/07."""
from contextlib import contextmanager
from fastapi.testclient import TestClient
from app.main import create_app
from app.demo_seed import seed_demo, USER_PASSWORD
URI = 'mongodb://127.0.0.1:27018'


@contextmanager
def authenticated_client(name):
    with TestClient(create_app(URI, name)) as client:
        seed_demo(client.app.state.db, examples=False)
        response = client.post('/api/auth/login', json={'email': 'carla@skillpath.test', 'password': USER_PASSWORD})
        assert response.status_code == 200
        client.headers['X-CSRF-Token'] = response.json()['csrf_token']
        yield client
