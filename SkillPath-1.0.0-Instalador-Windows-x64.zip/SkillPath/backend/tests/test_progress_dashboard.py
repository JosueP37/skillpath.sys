from auth_helpers import authenticated_client
"""Verificación RF-03/RF-07 con MongoDB real y bases de prueba aisladas."""
from concurrent.futures import ThreadPoolExecutor

from fastapi.testclient import TestClient

from app.catalog import QUESTIONS
from app.main import create_app
from test_api_mongodb import URI, body, demo_database


def wrong_body(profile='desarrollo-web'):
    payload = body(profile)
    for answer in payload['answers']:
        q = next(q for q in QUESTIONS if q['id'] == answer['question_id'])
        answer['option_id'] = next(option['id'] for option in q['options'] if option['id'] != q['correct'])
    return payload


def create_route(client):
    result = client.post('/api/evaluations', json=wrong_body()).json()
    route = client.post('/api/evaluations/' + result['id'] + '/learning-path').json()
    return result, route, '/api/evaluations/' + result['id'] + '/progress'


def update(client, endpoint, resource_id, version, status='completed', note='Realicé la práctica propuesta.'):
    return client.put(endpoint + '/' + resource_id, json={
        'status': status, 'note': note, 'expected_version': version,
    })


def test_existing_route_defaults_to_pending_without_changing_diagnosis(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        result, route, endpoint = create_route(client)
        saved_path = db.learning_paths.find_one({'_id': route['id']})
        progress = client.get(endpoint).json()
        assert progress['completion_percent'] == 0
        assert progress['pending_activities'] == progress['total_activities'] == 6
        assert progress['version'] == 0
        assert progress['events'] == []
        assert db.learning_progress.count_documents({}) == 0
        resource = route['items'][0]['resource']['id']
        response = update(client, endpoint, resource, 0)
        assert response.status_code == 200
        progress = response.json()
        assert progress['completed_activities'] == 1
        assert progress['completion_percent'] == 16.67
        assert progress['completed_minutes'] == route['items'][0]['resource']['estimated_minutes']
        assert progress['remaining_minutes'] + progress['completed_minutes'] == route['estimated_minutes']
        assert progress['status'] == 'in_progress'
        assert progress['events'][0]['previous_status'] == 'pending'
        assert db.learning_paths.find_one({'_id': route['id']}) == saved_path
        assert client.get('/api/evaluations/' + result['id']).json() == result


def test_progress_states_history_noops_and_reopening(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        _, route, endpoint = create_route(client)
        resource = route['items'][0]['resource']['id']
        progress = update(client, endpoint, resource, 0, 'in_progress', '  Ejercicio iniciado.  ').json()
        assert progress['items'][0]['note'] == 'Ejercicio iniciado.'
        assert progress['in_progress_activities'] == 1
        assert progress['completed_activities'] == 0
        same = update(client, endpoint, resource, 1, 'in_progress', 'Ejercicio iniciado.').json()
        assert same == progress
        assert same['event_count'] == 1
        version = same['version']
        for item in route['items']:
            progress = update(client, endpoint, item['resource']['id'], version).json()
            version = progress['version']
        assert progress['status'] == 'completed'
        assert progress['completion_percent'] == 100
        assert progress['remaining_minutes'] == 0
        reopened = update(client, endpoint, resource, version, 'pending', '').json()
        assert reopened['completed_activities'] == 5
        assert reopened['completion_percent'] == 83.33
        assert reopened['status'] == 'in_progress'
        assert reopened['events'][0]['previous_status'] == 'completed'
        assert db.learning_progress.count_documents({}) == 1


def test_progress_rejects_invalid_or_unassigned_changes(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        _, route, endpoint = create_route(client)
        resource = route['items'][0]['resource']['id']
        assert update(client, endpoint, 'not-in-route', 0).status_code == 404
        assert update(client, endpoint, resource, 0, 'completed', '   ').status_code == 422
        assert update(client, endpoint, resource, 0, 'unsupported').status_code == 422
        assert update(client, endpoint, resource, 0, note='x' * 1001).status_code == 422
        assert update(client, endpoint, resource, -1).status_code == 422
        assert client.put(endpoint + '/' + resource, json={'status': 'pending', 'expected_version': 0, 'score': 100}).status_code == 422
        assert db.learning_progress.count_documents({}) == 0
        assert client.get('/api/evaluations/invalid/progress').status_code == 404


def test_progress_conflict_does_not_overwrite_other_window(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        _, route, endpoint = create_route(client)
        resources = [item['resource']['id'] for item in route['items'][:2]]
        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(lambda resource: update(client, endpoint, resource, 0), resources))
        assert sorted(response.status_code for response in responses) == [200, 409]
        progress = client.get(endpoint).json()
        assert progress['version'] == 1
        assert progress['completed_activities'] == 1
        assert progress['event_count'] == 1
        losing = resources[responses.index(next(response for response in responses if response.status_code == 409))]
        assert update(client, endpoint, losing, progress['version']).json()['completed_activities'] == 2


def test_progress_survives_new_application_connection(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        _, route, endpoint = create_route(client)
        saved = update(client, endpoint, route['items'][0]['resource']['id'], 0).json()
    with authenticated_client(name) as client:
        assert client.get(endpoint).json() == saved


def test_no_gap_route_has_no_percentage_or_false_training(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        evaluation = client.post('/api/evaluations', json=body()).json()
        endpoint = '/api/evaluations/' + evaluation['id']
        client.post(endpoint + '/learning-path')
        progress = client.get(endpoint + '/progress').json()
        assert progress['status'] == 'no_activities'
        assert progress['completion_percent'] is None
        assert progress['completed_activities'] == 0
        assert update(client, endpoint + '/progress', 'http-basics', 0).status_code == 404
        metrics = client.get('/api/dashboard').json()['metrics']
        assert metrics['completion_percent'] is None
        assert metrics['routes_without_activities'] == 1
        assert metrics['completed_routes'] == 0


def test_dashboard_counts_filters_and_denominators_match_mongodb(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        _, route, endpoint = create_route(client)
        no_gaps = client.post('/api/evaluations', json=body('soporte-ti')).json()
        client.post('/api/evaluations/' + no_gaps['id'] + '/learning-path')
        update(client, endpoint, route['items'][0]['resource']['id'], 0)
        dashboard = client.get('/api/dashboard').json()
        metrics = dashboard['metrics']
        assert metrics['evaluation_count'] == db.evaluations.count_documents({}) == 2
        assert metrics['average_score'] == 50
        assert metrics['evaluations_with_gaps'] == 1
        assert metrics['path_count'] == db.learning_paths.count_documents({}) == 2
        assert metrics['total_activities'] == 6
        assert metrics['completed_activities'] == 1
        assert metrics['completion_percent'] == 16.67
        assert metrics['routes_without_activities'] == 1
        assert metrics['in_progress_routes'] == 1
        assert len(dashboard['competencies']) == 6
        assert all(row['evaluation_count'] == 1 and row['average_score'] in (0, 100) for row in dashboard['competencies'])
        junior = client.get('/api/dashboard?profile_id=soporte-ti').json()['metrics']
        assert junior['average_score'] == 100
        assert junior['total_activities'] == 0
        assert junior['completion_percent'] is None
        intermediate = client.get('/api/dashboard?profile_id=desarrollo-web').json()['metrics']
        assert intermediate['average_score'] == 0
        assert intermediate['completion_percent'] == 16.67
        assert client.get('/api/dashboard?profile_id=unknown').status_code == 422
        assert 'answers' not in str(dashboard) and 'scoring_key_snapshot' not in str(dashboard)


def test_empty_dashboard_and_records_beyond_history_limit(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        empty = client.get('/api/dashboard').json()
        assert empty['metrics']['evaluation_count'] == 0
        assert empty['metrics']['average_score'] is None
        assert empty['competencies'] == []
        for _ in range(21):
            assert client.post('/api/evaluations', json=body()).status_code == 201
        assert len(client.get('/api/evaluations').json()) == 20
        dashboard = client.get('/api/dashboard').json()
        assert dashboard['metrics']['evaluation_count'] == 21
        assert dashboard['metrics']['evaluations_without_path'] == 21
        assert len(dashboard['recent_evaluations']) == 8
        assert dashboard['metrics']['average_score'] == 100


def test_linked_reevaluation_compares_saved_diagnostics_and_keeps_training(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        previous, route, endpoint = create_route(client)
        progress = update(client, endpoint, route['items'][0]['resource']['id'], 0).json()
        payload = body()
        payload['profile_id'] = previous['profile_id']
        payload['previous_evaluation_id'] = previous['id']
        response = client.post('/api/evaluations', json=payload)
        assert response.status_code == 201
        result = response.json()
        assert result['previous_evaluation_id'] == previous['id']
        assert result['comparison']['compatible'] is True
        assert result['comparison']['score_delta'] == 100
        assert result['comparison']['previous_gap_count'] == 3
        assert result['comparison']['current_gap_count'] == 0
        assert len(result['comparison']['competencies']) == 3
        assert client.get(endpoint).json() == progress
        assert client.get('/api/evaluations/' + previous['id']).json() == previous
        assert client.get('/api/dashboard').json()['metrics']['linked_reevaluations'] == 1
    with authenticated_client(name) as client:
        assert client.get('/api/evaluations/' + result['id']).json()['comparison'] == result['comparison']


def test_reevaluation_rejects_wrong_profile_and_marks_changed_versions(demo_database):
    name, db = demo_database
    with authenticated_client(name) as client:
        previous, _, _ = create_route(client)
        payload = body('soporte-ti')
        payload['previous_evaluation_id'] = previous['id']
        assert client.post('/api/evaluations', json=payload).status_code == 422
        payload = body(previous['profile_id'])
        payload['previous_evaluation_id'] = '00000000-0000-0000-0000-000000000000'
        assert client.post('/api/evaluations', json=payload).status_code == 404
        payload['previous_evaluation_id'] = previous['id']
        db.evaluations.update_one({'_id': previous['id']}, {'$set': {'assessment_version': 'old-version'}})
        result = client.post('/api/evaluations', json=payload).json()
        assert result['comparison']['compatible'] is False
        assert result['comparison']['score_delta'] is None
        assert result['comparison']['competencies'] == []
        assert db.evaluations.count_documents({}) == 2
