import pytest
from app.catalog import QUESTIONS, VERSION, public_assessment, questions_for_profile
from app.scoring import evaluate

def answers(correct=True, profile='desarrollo-web'):
    return [{'question_id': q['id'], 'option_id': q['correct'] if correct else next(o['id'] for o in q['options'] if o['id'] != q['correct'])} for q in questions_for_profile(profile)]

def test_full_marks_have_no_negative_gaps():
    result = evaluate('desarrollo-web', VERSION, answers())
    assert result['overall_score'] == 100
    assert result['competencies_with_gap'] == 0
    assert all(row['gap_points'] == 0 for row in result['results'])

def test_no_correct_answers_have_full_relative_gap():
    result = evaluate('desarrollo-web', VERSION, answers(False))
    assert result['competencies_with_gap'] == 3
    assert all(row['current'] == 0 and row['gap_percent'] == 100 for row in result['results'])

def test_weighted_score_and_units():
    submission = answers(False)
    for i, q in enumerate(questions_for_profile('desarrollo-web')):
        if q['competency_id'] == 'javascript' and q['weight'] == 3:
            submission[i]['option_id'] = q['correct']
    sql = next(row for row in evaluate('desarrollo-web', VERSION, submission)['results'] if row['competency_id'] == 'javascript')
    assert sql['current'] == 50
    assert sql['gap_points'] == 30
    assert sql['gap_percent'] == 37.5

@pytest.mark.parametrize('mutation', ['missing', 'duplicate', 'unknown', 'invalid_option', 'empty'])
def test_invalid_submissions_are_rejected(mutation):
    submission = answers()
    if mutation == 'missing': submission.pop()
    if mutation == 'duplicate': submission.append(submission[0])
    if mutation == 'unknown': submission[0]['question_id'] = 'not-a-question'
    if mutation == 'invalid_option': submission[0]['option_id'] = 'invalid'
    if mutation == 'empty': submission = []
    with pytest.raises(ValueError): evaluate('desarrollo-web', VERSION, submission)

def test_stale_version_is_rejected():
    with pytest.raises(ValueError): evaluate('desarrollo-web', 'old', answers())

def test_unknown_profile_is_rejected():
    with pytest.raises(ValueError): evaluate('unknown', VERSION, answers())

def test_public_questions_do_not_expose_answers():
    assert all('correct' not in q for q in public_assessment('desarrollo-web')['questions'])

