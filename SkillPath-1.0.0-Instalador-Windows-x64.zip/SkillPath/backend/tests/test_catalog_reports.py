"""RF-04, RF-05 y RF-08: integración real, permisos, versiones y reportes."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import datetime, timezone
from io import StringIO
import csv
from fastapi.testclient import TestClient
import pytest
from app.catalog import VERSION, QUESTIONS
from app.demo_seed import seed_demo, demo_id, USER_PASSWORD, ADMIN_PASSWORD
from app.main import create_app
from test_api_mongodb import demo_database, URI, body


def login(client, email='ana.admin@skillpath.test'):
    response = client.post('/api/auth/login', json={'email': email, 'password': ADMIN_PASSWORD if '.admin@' in email else USER_PASSWORD})
    assert response.status_code == 200
    client.headers['X-CSRF-Token'] = response.json()['csrf_token']


@pytest.fixture
def workspace(demo_database):
    name, db = demo_database
    with TestClient(create_app(URI, name)) as client:
        seed_demo(db, examples=False)
        login(client)
        yield client, db


def job_payload(**changes):
    payload = {'category_id': 'desarrollo-web', 'name': 'Analista de aplicaciones', 'description': 'Puesto ficticio para verificación.', 'active': True, 'competencies': [{'competency_id': 'web', 'required': 90, 'criticality': 3}, {'competency_id': 'http', 'required': 80, 'criticality': 2}]}
    payload.update(changes)
    return payload


def new_job(client):
    response = client.post('/api/job-profiles', json=job_payload())
    assert response.status_code == 201, response.text
    return response.json()


def job_assessment(client, job):
    return client.get('/api/profiles/desarrollo-web/assessment?job_profile_id=' + job['id'])


def job_submission(client, job):
    assessment = job_assessment(client, job).json()
    return {'profile_id': 'desarrollo-web', 'job_profile_id': job['id'], 'assessment_version': assessment['version'], 'answers': [{'question_id': q['id'], 'option_id': next(row['correct'] for row in QUESTIONS if row['id'] == q['id'])} for q in assessment['questions']]}


def test_create_consult_and_evaluate_job_with_own_matrix(workspace):
    client, db = workspace
    job = new_job(client)
    assert len(client.get('/api/profiles').json()) == 4
    assert client.get('/api/job-profiles/' + job['id']).json()['history'][0]['actor_name'] == 'Ana Torres'
    login(client, 'carla@skillpath.test')
    assessment = job_assessment(client, job).json()
    assert len(assessment['questions']) == 6
    assert all('correct' not in q for q in assessment['questions'])
    assert [row['required'] for row in assessment['competencies']] == [90, 80]
    response = client.post('/api/evaluations', json=job_submission(client, job))
    assert response.status_code == 201
    result = response.json()
    assert result['job_profile_id'] == job['id'] and result['overall_score'] == 100
    saved = db.evaluations.find_one({'_id': result['id']})
    assert len(saved['scoring_key_snapshot']) == 6 and saved['job_revision'] == 1


@pytest.mark.parametrize('competencies', [
    [], [{'competency_id': 'web', 'required': 0, 'criticality': 1}],
    [{'competency_id': 'identity', 'required': 80, 'criticality': 2}],
    [{'competency_id': 'web', 'required': 80, 'criticality': 2}] * 2,
    [{'competency_id': 'web', 'required': 80, 'criticality': 6}],
])
def test_matrix_validation(workspace, competencies):
    client, db = workspace
    assert client.post('/api/job-profiles', json=job_payload(competencies=competencies)).status_code == 422
    assert db.job_profiles.count_documents({}) == 0


def test_job_versions_archive_duplicates_and_snapshot_conservation(workspace):
    client, db = workspace
    job = new_job(client)
    assert client.post('/api/job-profiles', json=job_payload(name=' ANALISTA DE APLICACIONES ')).status_code == 409
    login(client, 'carla@skillpath.test')
    submission = job_submission(client, job)
    result = client.post('/api/evaluations', json=submission).json()
    original = db.evaluations.find_one({'_id': result['id']})
    login(client)
    changed = job_payload(expected_revision=1)
    changed['competencies'][0]['required'] = 95
    assert client.put('/api/job-profiles/' + job['id'], json=changed).json()['revision'] == 2
    assert client.put('/api/job-profiles/' + job['id'], json=changed).status_code == 409
    login(client, 'carla@skillpath.test')
    assert client.post('/api/evaluations', json=submission).status_code == 422
    fresh = job_submission(client, job); fresh['previous_evaluation_id'] = result['id']
    comparison = client.post('/api/evaluations', json=fresh).json()['comparison']
    assert comparison['compatible'] is False and comparison['score_delta'] is None
    assert db.evaluations.find_one({'_id': result['id']}) == original
    login(client)
    changed['expected_revision'] = 2; changed['active'] = False
    assert client.put('/api/job-profiles/' + job['id'], json=changed).status_code == 200
    login(client, 'carla@skillpath.test')
    assert client.get('/api/job-profiles').json() == []
    assert job_assessment(client, job).status_code == 404
    assert client.get('/api/evaluations/' + result['id']).status_code == 200


def test_job_concurrent_changes_and_wrong_category(workspace):
    client, _ = workspace
    job = new_job(client)
    with ThreadPoolExecutor(max_workers=2) as executor:
        responses = list(executor.map(lambda name: client.put('/api/job-profiles/' + job['id'], json=job_payload(name=name, expected_revision=1)), ['Nombre A', 'Nombre B']))
    assert sorted(response.status_code for response in responses) == [200, 409]
    assert client.get('/api/profiles/soporte-ti/assessment?job_profile_id=' + job['id']).status_code == 404
    assert client.put('/api/job-profiles/' + job['id'], json=job_payload(category_id='soporte-ti', expected_revision=2)).status_code == 422


@pytest.mark.parametrize('endpoint', ['/api/job-profiles', '/api/admin/resources', '/api/reports/team', '/api/reports/team.csv'])
def test_permissions_for_catalogs_and_reports(workspace, endpoint):
    client, _ = workspace
    login(client, 'carla@skillpath.test')
    if endpoint == '/api/job-profiles':
        assert client.post(endpoint, json=job_payload()).status_code == 403
        assert client.get(endpoint + '?include_inactive=true').status_code == 403
    else:
        assert client.get(endpoint).status_code == 403
    assert client.post('/api/auth/logout').status_code == 204
    assert client.get(endpoint).status_code == 401


def resource_payload(client):
    catalog = client.get('/api/admin/resources').json()
    resource = deepcopy(next(row for row in catalog['resources'] if row['id'] == 'web-practice'))
    resource['id'] = 'nuevo-recurso-web'
    resource['title'] = 'Recurso ficticio del catálogo'
    return {'expected_revision': catalog['revision'], 'resource': resource, 'note': 'Alta de recurso de prueba.'}


def test_resources_created_updated_and_recorded_with_actor(workspace):
    client, db = workspace
    payload = resource_payload(client)
    response = client.post('/api/admin/resources', json=payload)
    assert response.status_code == 201, response.text
    catalog = response.json()
    assert catalog['revision'] == 2 and catalog['version'] == 'learning-db-2'
    assert catalog['history'][0]['actor_name'] == 'Ana Torres'
    assert client.post('/api/admin/resources', json=payload).status_code == 409
    payload['expected_revision'] = 2; payload['resource']['approved'] = False
    assert client.put('/api/admin/resources/nuevo-recurso-web', json=payload).json()['revision'] == 3
    assert db.resource_catalog.find_one({'_id': 'current'})['revision'] == 3


@pytest.mark.parametrize('change', [
    {'links': [{'label': 'Malo', 'url': 'javascript:alert(1)'}]},
    {'links': [{'label': 'Malo', 'url': 'https://user:secret@example.org'}]},
    {'prerequisite_ids': ['missing']},
    {'prerequisite_ids': ['javascript-base']},
    {'prerequisite_ids': ['nuevo-recurso-web']},
    {'estimated_minutes': 0},
    {'entry_score': 99, 'target_score': 70},
])
def test_resource_graph_levels_and_url_validation(workspace, change):
    client, db = workspace
    payload = resource_payload(client); payload['resource'].update(change)
    assert client.post('/api/admin/resources', json=payload).status_code == 422
    assert db.resource_catalog.find_one({'_id': 'current'})['revision'] == 1


def test_new_catalog_only_affects_new_routes(workspace):
    client, db = workspace
    login(client, 'carla@skillpath.test')
    payload = body()
    for answer in payload['answers']:
        question = next(row for row in QUESTIONS if row['id'] == answer['question_id'])
        answer['option_id'] = next(option['id'] for option in question['options'] if option['id'] != question['correct'])
    first = client.post('/api/evaluations', json=payload).json()
    endpoint = '/api/evaluations/' + first['id'] + '/learning-path'
    route = client.post(endpoint).json()
    original = db.learning_paths.find_one({'_id': route['id']})
    login(client)
    catalog = client.get('/api/admin/resources').json()
    resource = deepcopy(next(row for row in catalog['resources'] if row['id'] == 'web-base'))
    resource['title'] = 'Nuevo título de lectura'
    assert client.put('/api/admin/resources/web-base', json={'resource': resource, 'note': 'Actualizar el título del recurso.', 'expected_revision': 1}).status_code == 200
    login(client, 'carla@skillpath.test')
    assert client.post(endpoint).json() == route
    assert db.learning_paths.find_one({'_id': route['id']}) == original
    second = client.post('/api/evaluations', json=payload).json()
    new_route = client.post('/api/evaluations/' + second['id'] + '/learning-path').json()
    assert new_route['catalog_version'] == 'learning-db-2'
    assert next(row['resource']['title'] for row in new_route['items'] if row['resource']['id'] == 'web-base') == 'Nuevo título de lectura'


def test_report_matches_database_and_csv_uses_same_rows(workspace):
    client, db = workspace
    seed_demo(db)
    report = client.get('/api/reports/team').json()
    assert report['summary']['user_count'] == 2
    assert report['summary']['evaluation_count'] == 4
    assert report['summary']['path_count'] == 4
    assert report['summary']['total_activities'] == 15
    assert report['summary']['completed_activities'] == 5
    assert report['summary']['completion_percent'] == 33.33
    assert len(report['rows']) == 2
    carla = next(row for row in report['rows'] if row['user_name'] == 'Carla Ruiz')
    assert carla['first_score'] == 0 and carla['latest_score'] == 100 and carla['score_delta'] == 100
    assert carla['competencies_achieved'] == 3 and len(carla['achieved']) == 3
    exported = client.get('/api/reports/team.csv')
    assert exported.status_code == 200 and exported.content.startswith(b'\xef\xbb\xbf')
    rows = list(csv.DictReader(StringIO(exported.content.decode('utf-8-sig')), delimiter=';'))
    assert len(rows) == 2
    assert next(row['puntaje_actual'] for row in rows if row['usuario'] == 'Carla Ruiz') in ['100', '100.0']
    assert 'password_hash' not in exported.text and 'scoring_key_snapshot' not in exported.text
    filtered = client.get('/api/reports/team?profile_id=desarrollo-web&user_id=' + demo_id('carla@skillpath.test')).json()
    assert filtered['summary']['evaluation_count'] == 2 and filtered['summary']['user_count'] == 1


def test_report_foreign_team_and_missing_assessment_are_not_zero(workspace):
    client, db = workspace
    seed_demo(db)
    foreign = demo_id('lucia@skillpath.test')
    for suffix in ['', '.csv']:
        assert client.get('/api/reports/team' + suffix + '?user_id=' + foreign).status_code == 404
    login(client, 'luis.admin@skillpath.test')
    report = client.get('/api/reports/team').json()
    assert report['summary']['user_count'] == 1 and report['summary']['evaluation_count'] == 2
    assert all(row['user_name'] == 'Lucía Gómez' for row in report['rows'])
    empty = client.get('/api/reports/team?profile_id=desarrollo-web').json()['rows'][0]
    assert empty['status'] == 'not_evaluated' and empty['latest_score'] is None and empty['completion_percent'] is None


def test_report_calendar_boundaries_and_csv_formula_protection(workspace):
    client, db = workspace
    seed_demo(db)
    eid = demo_id('carla@skillpath.test/evaluation/initial')
    db.evaluations.update_one({'_id': eid}, {'$set': {'created_at': datetime(2026, 10, 19, 4, 59, tzinfo=timezone.utc)}})
    other = demo_id('carla@skillpath.test/evaluation/latest')
    db.evaluations.update_one({'_id': other}, {'$set': {'created_at': datetime(2026, 10, 19, 5, 0, tzinfo=timezone.utc)}})
    query = '?user_id=' + demo_id('carla@skillpath.test') + '&date_from=2026-10-19&date_to=2026-10-19'
    report = client.get('/api/reports/team' + query).json()
    assert report['summary']['evaluation_count'] == 1 and report['rows'][0]['latest_evaluation_id'] == other
    db.users.update_one({'_id': demo_id('carla@skillpath.test')}, {'$set': {'name': '=HYPERLINK("evil")'}})
    rows = list(csv.DictReader(StringIO(client.get('/api/reports/team.csv' + query).content.decode('utf-8-sig')), delimiter=';'))
    assert rows[0]['usuario'].startswith("'=")
    assert client.get('/api/reports/team?date_from=2026-10-20&date_to=2026-10-19').status_code == 422
    assert client.get('/api/reports/team?date_to=9999-12-31').status_code == 422


def test_catalog_persists_across_application_connections(workspace, demo_database):
    client, db = workspace
    job = new_job(client)
    resource = resource_payload(client)
    assert client.post('/api/admin/resources', json=resource).status_code == 201
    with TestClient(create_app(URI, demo_database[0])) as other:
        login(other)
        assert other.get('/api/job-profiles/' + job['id']).json()['revision'] == 1
        assert other.get('/api/admin/resources').json()['revision'] == 2


@pytest.mark.parametrize('link', [
    {'label': 'Recurso', 'url': 'https://bad host.example/page'},
    {'label': 'Recurso', 'url': 'https://example.org:not-a-port/page'},
    {'label': '   ', 'url': 'https://example.org/page'},
])
def test_resource_links_have_valid_host_port_and_label(workspace, link):
    client, db = workspace
    payload = resource_payload(client)
    payload['resource']['links'] = [link]
    assert client.post('/api/admin/resources', json=payload).status_code == 422
    assert db.resource_catalog.find_one({'_id': 'current'})['revision'] == 1
