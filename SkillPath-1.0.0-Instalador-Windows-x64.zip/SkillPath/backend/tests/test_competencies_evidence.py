"""Integración de competencias administrables y revisión de evidencias."""
from concurrent.futures import ThreadPoolExecutor

from app.catalog import VERSION
from test_catalog_reports import demo_database, job_assessment, job_payload, login, resource_payload, workspace
from test_progress_dashboard import create_route


BANK = '/api/admin/competencies'
CATEGORY = '/api/profiles/desarrollo-web/assessment'


def new_competency(**changes):
    return {
        'expected_revision': 0, 'category_id': 'desarrollo-web', 'name': 'Pruebas de componentes',
        'questions': [{
            'text': '¿Qué conviene verificar al probar un componente?',
            'weight': 2, 'options': ['Su comportamiento observable', 'Solo su nombre'], 'correct_index': 0,
        }],
        **changes,
    }


def test_new_competency_can_be_assessed_and_get_resources(workspace):
    client, db = workspace
    created = client.post(BANK, json=new_competency())
    assert created.status_code == 201, created.text
    entry = next(row for row in created.json()['competencies'] if row['name'] == 'Pruebas de componentes')
    question = entry['questions'][0]
    job = job_payload(competencies=[{'competency_id': entry['id'], 'required': 80, 'criticality': 3}])
    assert client.post('/api/job-profiles', json={**job, 'category_id': 'soporte-ti'}).status_code == 422
    job = client.post('/api/job-profiles', json=job).json()
    resource = resource_payload(client)
    resource['resource'].update(competency_id=entry['id'], prerequisite_ids=[], entry_score=0, target_score=90)
    assert client.post('/api/admin/resources', json=resource).status_code == 201

    login(client, 'carla@skillpath.test')
    assert client.get(BANK).status_code == 403
    assert client.post(BANK, json=new_competency()).status_code == 403
    assert client.get(CATEGORY).json()['version'] == VERSION
    instrument = job_assessment(client, job).json()
    assert [q['id'] for q in instrument['questions']] == [question['id']]
    assert 'correct' not in instrument['questions'][0]
    submission = {
        'profile_id': instrument['profile_id'], 'job_profile_id': job['id'],
        'assessment_version': instrument['version'],
        'answers': [{'question_id': question['id'], 'option_id': 'b'}],
    }
    response = client.post('/api/evaluations', json=submission)
    assert response.status_code == 201, response.text
    result = response.json()
    assert result['results'][0]['gap_points'] == 80
    evaluation = '/api/evaluations/' + result['id']
    route = client.post(evaluation + '/learning-path').json()
    assert route['covered_gap_count'] == 1
    assert route['items'][0]['resource']['id'] == resource['resource']['id']
    snapshot = db.evaluations.find_one({'_id': result['id']})

    login(client)
    edit = new_competency(name='Pruebas de interfaz', expected_revision=1)
    edit['questions'][0].update(id=question['id'], correct_index=1)
    assert client.put(BANK + '/' + entry['id'], json=edit).status_code == 200
    assert client.put(BANK + '/' + entry['id'], json=edit).status_code == 409
    login(client, 'carla@skillpath.test')
    assert client.post('/api/evaluations', json=submission).status_code == 422
    submission['assessment_version'] = job_assessment(client, job).json()['version']
    submission['previous_evaluation_id'] = result['id']
    updated = client.post('/api/evaluations', json=submission).json()
    assert updated['overall_score'] == 100
    assert updated['comparison']['compatible'] is False
    assert db.evaluations.find_one({'_id': result['id']}) == snapshot
    assert client.get(evaluation + '/learning-path').json() == route


def test_bank_rejects_invalid_questions_and_concurrent_initial_writes(workspace):
    client, db = workspace
    invalid = new_competency()
    invalid['questions'][0]['options'] = ['Repetida', '  REPETIDA  ']
    assert client.post(BANK, json=invalid).status_code == 422
    invalid['questions'][0].update(options=['Una', 'Dos'], id='web-1')
    assert client.post(BANK, json=invalid).status_code == 422
    assert db.competency_catalog.count_documents({}) == 0

    with ThreadPoolExecutor(max_workers=2) as executor:
        responses = list(executor.map(lambda name: client.post(BANK, json=new_competency(name=name)), ['Banco A', 'Banco B']))
    assert sorted(response.status_code for response in responses) == [201, 409]
    assert client.get(BANK).json()['revision'] == 1


def test_editing_seed_questions_updates_general_assessment_only_in_its_category(workspace):
    client, _ = workspace
    support = '/api/profiles/soporte-ti/assessment'
    original_support = client.get(support).json()
    web = next(row for row in client.get(BANK).json()['competencies'] if row['id'] == 'web')
    payload = new_competency(name=web['name'])
    payload['questions'][0]['id'] = web['questions'][0]['id']
    assert client.put(BANK + '/web', json=payload).status_code == 200
    updated = client.get(CATEGORY).json()
    assert updated['version'] != VERSION
    assert len(updated['questions']) == 7
    assert next(row for row in client.get('/api/profiles').json() if row['id'] == 'desarrollo-web')['question_count'] == 7
    assert client.get(support).json() == original_support


def test_evidence_review_respects_scope_and_resubmission(workspace):
    client, db = workspace
    login(client, 'carla@skillpath.test')
    evaluation, path, progress_url = create_route(client)
    endpoint = '/api/evaluations/' + evaluation['id']
    resource = path['items'][0]['resource']['id']
    activity_url = progress_url + '/' + resource
    review_url = activity_url + '/review'
    activity = {'status': 'completed', 'note': 'Registré los resultados.', 'expected_version': 0}
    assert client.put(activity_url, json={**activity, 'evidence_url': 'javascript:alert(1)'}).status_code == 422
    assert client.put(activity_url, json={**activity, 'evidence_url': 'https://user:pass@example.test'}).status_code == 422
    decision = {'status': 'approved', 'expected_version': 0}
    assert client.put(review_url, json=decision).status_code == 403
    login(client, 'ana.admin@skillpath.test')
    assert client.put(review_url, json=decision).status_code == 422

    login(client, 'carla@skillpath.test')
    progress = client.put(activity_url, json={**activity, 'evidence_url': 'https://example.test/practica'}).json()
    assert progress['approved_activities'] == 0
    assert progress['items'][0]['review'] is None
    decision['expected_version'] = progress['version']
    login(client, 'luis.admin@skillpath.test')
    assert client.put(review_url, json=decision).status_code == 404
    login(client)
    assert client.put(review_url, json={**decision, 'status': 'changes_requested'}).status_code == 422
    feedback = {'status': 'changes_requested', 'feedback': 'Incluye el resultado esperado.'}
    reviewed = client.put(review_url, json={**decision, **feedback}).json()
    assert reviewed['items'][0]['review']['feedback'] == feedback['feedback']
    assert reviewed['events'][0]['review_status'] == 'changes_requested'
    assert reviewed['completion_percent'] == progress['completion_percent']
    assert client.put(review_url, json=decision).status_code == 409

    login(client, 'carla@skillpath.test')
    assert client.get(progress_url).json()['items'][0]['review']['reviewer_name'] == 'Ana Torres'
    activity.update(note='Documenté el resultado esperado y el observado.', expected_version=reviewed['version'])
    resubmitted = client.put(activity_url, json=activity).json()
    assert resubmitted['items'][0]['review'] is None
    assert resubmitted['items'][0]['evidence_url'] == 'https://example.test/practica'
    login(client)
    decision['expected_version'] = resubmitted['version']
    approved = client.put(review_url, json=decision).json()
    assert approved['approved_activities'] == 1
    assert approved['events'][0]['actor_name'] == 'Ana Torres'
    assert db.learning_progress.find_one({'evaluation_id': evaluation['id']})['events'][-1]['evidence_note'] == activity['note']
    assert client.get(endpoint).json()['overall_score'] == evaluation['overall_score']
