"""Inicia Uvicorn y permite que el acceso de Windows solicite un cierre ordenado."""

import argparse
import asyncio
from pathlib import Path
from uuid import UUID

import uvicorn


async def serve(port: int, stop_file: Path) -> None:
    server = uvicorn.Server(uvicorn.Config(
        'app.main:app', host='127.0.0.1', port=port, timeout_graceful_shutdown=8,
    ))

    async def watch_stop_file() -> None:
        while not stop_file.is_file():
            await asyncio.sleep(0.25)
        server.should_exit = True

    watcher = asyncio.create_task(watch_stop_file())
    try:
        await server.serve()
    finally:
        watcher.cancel()
        await asyncio.gather(watcher, return_exceptions=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('port', type=int, choices=(8000, 8001))
    parser.add_argument('stop_token', type=UUID)
    args = parser.parse_args()
    marker = Path(__file__).resolve().parents[1] / '.logs' / f'api-stop-{args.stop_token.hex}'
    asyncio.run(serve(args.port, marker))
