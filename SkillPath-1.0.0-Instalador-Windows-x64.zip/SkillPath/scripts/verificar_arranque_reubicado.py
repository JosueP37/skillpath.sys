"""Arranque real desde carpeta reubicada y retorno a la demo original."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
from bson.json_util import dumps
import httpx
from pymongo import MongoClient

root = Path(__file__).resolve().parents[1]
output = root/'.logs/qa'
installation = json.loads((output/'oct19-instalacion-verificada.json').read_text(encoding='utf-8'))
relocated = Path(installation['fresh_directory'])
assert relocated.resolve().is_relative_to((output).resolve()) and relocated.name == 'SkillPath'
names = ['users', 'evaluations', 'learning_paths', 'learning_progress', 'job_profiles', 'resource_catalog']


def fingerprints():
    with MongoClient('mongodb://127.0.0.1:27018',serverSelectionTimeoutMS=3000) as mongo:
        db=mongo['skillpath_demo']
        return {name: {doc['_id']: hashlib.sha256(dumps(doc,sort_keys=True).encode()).hexdigest() for doc in db[name].find()} for name in names}


def script(project, filename, log):
    subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(project/filename)],cwd=project,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,check=True)


before=fingerprints()
(output/'oct19-reinicio-huellas.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
client=httpx.Client(base_url='http://127.0.0.1:8000',timeout=20)
response=client.post('/api/auth/login',json={'email':'ana.admin@skillpath.test','password':'AdminDemo!2026'})
response.raise_for_status()
client.headers['X-CSRF-Token']=response.json()['csrf_token']
switched=False
try:
    with (output/'oct19-arranque-reubicado.log').open('w',encoding='utf-8') as log:
        script(root,'DETENER_DEMO.ps1',log)
        switched=True
        try:
            script(relocated,'INICIAR_DEMO.ps1',log)
            subprocess.run([str(relocated/'backend/.venv/Scripts/python.exe'),str(relocated/'scripts/crear_usuarios_demo.py')],cwd=relocated,stdout=log,stderr=subprocess.STDOUT,check=True)
            with httpx.Client(base_url='http://127.0.0.1:5173',timeout=20) as fresh:
                login=fresh.post('/api/auth/login',json={'email':'ana.admin@skillpath.test','password':'AdminDemo!2026'})
                login.raise_for_status()
                fresh.headers['X-CSRF-Token']=login.json()['csrf_token']
                assert len(fresh.get('/api/team').json()['members'])==2
                assert fresh.get('/api/reports/team').json()['summary']['evaluation_count']==4
                assert fresh.get('/api/health').json()['status']=='ok'
                assert fresh.post('/api/auth/logout').status_code==204
        finally:
            try:
                script(relocated,'DETENER_DEMO.ps1',log)
            finally:
                script(root,'INICIAR_DEMO.ps1',log)
                switched=False
    assert fingerprints()==before,'Cambió un documento de la demo original.'
    assert client.get('/api/auth/me').status_code==200
    assert len(client.get('/api/team').json()['members'])==2
    assert client.get('/api/reports/team').json()['summary']['evaluation_count']==4
    result={'relocated_real_services_started':True,'relocated_accounts_and_report_passed':True,'relocated_services_stopped':True,'original_demo_restarted':True,'original_session_survived':True,'original_data_preserved':{name:len(rows) for name,rows in before.items()},'physical_second_pc_tested':False}
    (output/'oct19-arranque-reubicado-verificado.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
finally:
    if switched:
        with (output/'oct19-restaurar-inicio.log').open('w',encoding='utf-8') as log:
            try:
                script(relocated,'DETENER_DEMO.ps1',log)
            finally:
                script(root,'INICIAR_DEMO.ps1',log)
    try:
        client.post('/api/auth/logout')
    except httpx.HTTPError:
        pass
    client.close()
