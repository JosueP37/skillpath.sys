"""Huella de documentos de demo antes y después de un reinicio; no modifica datos."""
import hashlib
import json
import sys
from pathlib import Path
from bson.json_util import dumps
from pymongo import MongoClient

root = Path(__file__).resolve().parents[1]
output = root / '.logs/qa'
output.mkdir(parents=True, exist_ok=True)
target = output / sys.argv[2]
assert target.parent.resolve() == output.resolve() and target.suffix == '.json'
client = MongoClient('mongodb://127.0.0.1:27018', serverSelectionTimeoutMS=3000)
db = client['skillpath_demo']
def fingerprint(document):
    return hashlib.sha256(dumps(document, sort_keys=True).encode('utf-8')).hexdigest()
def capture():
    return {name: {document['_id']: fingerprint(document) for document in db[name].find()} for name in ['evaluations', 'learning_paths', 'learning_progress']}
try:
    if sys.argv[1] == 'capture':
        snapshot = capture()
        target.write_text(json.dumps(snapshot, indent=2), encoding='utf-8')
        print(json.dumps({name: len(rows) for name, rows in snapshot.items()}))
    elif sys.argv[1] == 'verify':
        snapshot = json.loads(target.read_text(encoding='utf-8'))
        current = capture()
        for name, rows in snapshot.items():
            for identifier, digest in rows.items():
                assert current[name].get(identifier) == digest, f'Documento modificado o perdido: {name}/{identifier}'
        result = {name: len(rows) for name, rows in snapshot.items()}
        evidence = {'unchanged_documents': result, 'all_preserved': True}
        target.with_name(target.stem + '-verificado.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
        print(json.dumps(evidence))
    else:
        raise ValueError('Usa capture o verify.')
finally:
    client.close()
