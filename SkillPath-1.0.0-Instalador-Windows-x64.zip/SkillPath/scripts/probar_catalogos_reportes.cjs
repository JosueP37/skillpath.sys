const { chromium } = require(process.env.SKILLPATH_PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

(async () => {
  assert(process.env.SKILLPATH_QA_API);
  const browser = await chromium.launch({ headless: true, executablePath: process.env.SKILLPATH_BROWSER_PATH });
  const output = path.resolve(__dirname, '../.logs/qa');
  const errors = [], correct = JSON.parse(process.env.SKILLPATH_QA_ANSWERS);
  const evidence = {};
  async function open(email, password, width = 1440) {
    const context = await browser.newContext({ viewport: { width, height: 1000 }, baseURL: 'http://127.0.0.1:5173' });
    await context.route('**/api/**', async route => {
      const url = new URL(route.request().url());
      const response = await route.fetch({ url: process.env.SKILLPATH_QA_API + url.pathname + url.search });
      await route.fulfill({ response });
    });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('/');
    await page.getByLabel('Correo electrónico').fill(email);
    await page.getByLabel('Contraseña', { exact: true }).fill(password);
    await page.getByRole('button', { name: 'Ingresar', exact: true }).click();
    await page.getByRole('button', { name: 'Cerrar sesión' }).waitFor();
    return page;
  }
  async function api(page, endpoint) {
    return page.evaluate(async endpoint => {
      const response = await fetch('/api' + endpoint);
      return { status: response.status, data: await response.json().catch(() => null) };
    }, endpoint);
  }
  async function noOverflow(page) {
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1));
  }
  try {
    const admin = await open('ana.admin@skillpath.test', 'AdminDemo!2026');
    await admin.getByRole('button', { name: 'Reportes del equipo' }).click();
    await admin.locator('[data-report-users]').waitFor();
    assert.equal(await admin.locator('[data-report-users]').innerText(), '2');
    assert.equal(await admin.locator('.report-table tbody tr').count(), 2);
    await admin.screenshot({ path: path.join(output, 'oct19-reporte-escritorio.png'), fullPage: true });
    const download = admin.waitForEvent('download');
    await admin.getByRole('button', { name: 'Exportar reporte CSV' }).click();
    const exported = await download;
    const exportPath = path.join(output, 'oct19-equipo-prueba.csv');
    await exported.saveAs(exportPath);
    const csv = await fs.readFile(exportPath, 'utf8');
    assert(csv.includes('Carla Ruiz') && csv.includes('Diego Pérez') && !csv.includes('Lucía Gómez'));
    await admin.getByRole('combobox', { name: 'Categoría del reporte' }).selectOption('desarrollo-web');
    await admin.locator('[data-report-users]').waitFor();
    assert.match(await admin.locator('.report-table').innerText(), /Sin evaluación/);
    await admin.getByRole('combobox', { name: 'Categoría del reporte' }).selectOption('');
    evidence.report = { users: 2, csvMatchesTeam: true, missingAssessmentIsNotZero: true };

    await admin.getByRole('button', { name: 'Puestos y competencias' }).click();
    await admin.getByRole('button', { name: 'Nuevo puesto' }).click();
    await admin.locator('[name="job-name"]').fill('Analista web QA');
    await admin.locator('[name="job-description"]').fill('Puesto ficticio creado mediante la interfaz de prueba.');
    await admin.locator('[name="job-category"]').selectOption('desarrollo-web');
    await admin.getByLabel('JavaScript y aplicaciones web', { exact: true }).uncheck();
    await admin.getByRole('spinbutton', { name: 'Nivel requerido: HTML, CSS y accesibilidad' }).fill('90');
    await admin.getByRole('button', { name: 'Guardar puesto' }).click();
    await admin.getByRole('status').filter({ hasText: 'Puesto guardado' }).waitFor();
    const job = (await api(admin, '/job-profiles')).data[0];
    assert.equal(job.competencies.length, 2);
    await admin.screenshot({ path: path.join(output, 'oct19-puestos-escritorio.png'), fullPage: true });

    const user = await open('carla@skillpath.test', 'UsuarioDemo!2026');
    await user.getByRole('button', { name: 'Evaluación', exact: true }).click();
    await user.locator('input[name="profile"][value="desarrollo-web"]').check();
    await user.locator('#assessment-job option').nth(1).waitFor({ state: 'attached' });
    await user.locator('#assessment-job').selectOption(job.id);
    await user.getByRole('button', { name: 'Comenzar evaluación' }).click();
    const assessment = (await api(user, '/profiles/desarrollo-web/assessment?job_profile_id=' + job.id)).data;
    assert.equal(assessment.questions.length, 6);
    for (let step = 0; step < assessment.competencies.length; step++) {
      for (const q of assessment.questions.filter(q => q.competency_id === assessment.competencies[step].id)) {
        const wrong = q.options.find(option => option.id !== correct[q.id]).id;
        await user.locator('input[name="' + q.id + '"][value="' + wrong + '"]').check();
      }
      await user.getByRole('button', { name: step < assessment.competencies.length - 1 ? 'Continuar' : 'Ver mi diagnóstico', exact: true }).click();
    }
    await user.locator('.path-card').last().waitFor();
    assert.equal(await user.locator('.path-card').count(), 4);
    const diagnosis = (await api(user, '/evaluations')).data[0];
    assert.equal(diagnosis.job_profile_id, job.id);
    assert.equal(diagnosis.results[0].required, 90);

    await admin.locator('.catalog-card').filter({ hasText: 'Analista web QA' }).getByRole('button', { name: 'Editar puesto' }).click();
    await admin.getByRole('spinbutton', { name: 'Nivel requerido: HTML, CSS y accesibilidad' }).fill('95');
    await admin.getByRole('button', { name: 'Guardar puesto' }).click();
    await admin.getByRole('status').filter({ hasText: 'Puesto guardado' }).waitFor();
    assert.equal((await api(admin, '/job-profiles/' + job.id)).data.revision, 2);
    assert.equal((await api(user, '/evaluations/' + diagnosis.id)).data.results[0].required, 90);
    evidence.job = { created: true, associatedCompetencies: 2, questions: 6, originalRequired: 90, newRequired: 95, historicalDiagnosisPreserved: true };

    await admin.getByRole('button', { name: 'Recursos de aprendizaje' }).click();
    await admin.locator('.catalog-card').first().waitFor();
    await admin.getByRole('button', { name: 'Nuevo recurso' }).click();
    await admin.locator('[name="resource-title"]').fill('Taller web QA');
    await admin.locator('[name="resource-competency"]').selectOption('web');
    await admin.getByLabel('Proveedor', { exact: true }).fill('Capacitación de ejemplo');
    await admin.locator('[name="resource-practice"]').fill('Desarrolla una página accesible de demostración.');
    await admin.getByLabel('URL HTTP/HTTPS', { exact: true }).fill('https://developer.mozilla.org/en-US/docs/Web/HTML');
    await admin.locator('[name="resource-change-note"]').fill('Recurso ficticio para comprobar la asociación y el guardado.');
    await admin.getByRole('button', { name: 'Guardar recurso' }).click();
    await admin.getByRole('status').filter({ hasText: 'Recurso guardado' }).waitFor();
    await admin.locator('#resource-filter').selectOption('web');
    const resource = admin.locator('.catalog-card').filter({ hasText: 'Taller web QA' });
    await resource.waitFor();
    await resource.getByRole('button', { name: 'Editar recurso' }).click();
    await admin.getByLabel('Disponible para generar nuevas rutas').uncheck();
    await admin.locator('[name="resource-change-note"]').fill('Retirar el recurso ficticio de futuras recomendaciones.');
    await admin.getByRole('button', { name: 'Guardar recurso' }).click();
    await admin.getByRole('status').filter({ hasText: 'Recurso guardado' }).waitFor();
    await resource.getByText('Retirado', { exact: true }).waitFor();
    await admin.screenshot({ path: path.join(output, 'oct19-recursos-escritorio.png'), fullPage: true });
    evidence.resources = { created: true, associated: true, retired: true, audit: true };
    assert.equal((await api(user, '/admin/resources')).status, 403);
    assert.equal((await api(user, '/reports/team')).status, 403);

    const luis = await open('luis.admin@skillpath.test', 'AdminDemo!2026');
    await luis.getByRole('button', { name: 'Reportes del equipo' }).click();
    await luis.locator('[data-report-users]').waitFor();
    assert.equal(await luis.locator('[data-report-users]').innerText(), '1');
    assert(!((await luis.locator('.report-table').innerText()).includes('Carla Ruiz')));
    const mobile = await open('ana.admin@skillpath.test', 'AdminDemo!2026', 390);
    await mobile.getByRole('button', { name: 'Puestos y competencias' }).click();
    await mobile.locator('.catalog-card').waitFor();
    await noOverflow(mobile);
    await mobile.screenshot({ path: path.join(output, 'oct19-puestos-movil.png'), fullPage: true });
    await mobile.getByRole('button', { name: 'Reportes del equipo' }).click();
    await mobile.locator('[data-report-users]').waitFor();
    await noOverflow(mobile);
    await mobile.screenshot({ path: path.join(output, 'oct19-reporte-movil.png'), fullPage: true });
    evidence.mobile = true;
    assert.deepEqual(errors, []);
    evidence.javascriptErrors = errors;
    await fs.writeFile(path.join(output, 'oct19-catalogos-reportes-ui.json'), JSON.stringify(evidence, null, 2));
    console.log(JSON.stringify(evidence, null, 2));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
