const loginDemo = require('./login_demo.cjs');
const { chromium } = require(process.env.SKILLPATH_PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

(async () => {
  const output = path.resolve(__dirname, '../.logs/qa');
  await fs.mkdir(output, { recursive: true });
  const browser = await chromium.launch({ headless: true, ...(process.env.SKILLPATH_BROWSER_PATH ? { executablePath: process.env.SKILLPATH_BROWSER_PATH } : {}) });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:5173');
    await loginDemo(page);
    await page.getByRole('button', { name: 'Evaluación', exact: true }).click();
    await page.getByRole('button', { name: 'Comenzar evaluación' }).waitFor();
    await page.locator('input[value="desarrollo-web"]').check();
    await page.screenshot({ path: path.join(output, 'inicio-desktop.png'), fullPage: true });
    await page.getByRole('button', { name: 'Comenzar evaluación' }).click();
    await page.getByRole('heading', { name: 'HTML, CSS y accesibilidad', exact: true }).waitFor();
    assert(await page.getByRole('button', { name: 'Continuar', exact: true }).isDisabled());
    await page.locator('input[name="web-1"][value="a"]').check();
    await page.locator('input[name="web-2"][value="b"]').check();
    await page.locator('input[name="web-3"][value="a"]').check();
    await page.getByRole('button', { name: 'Continuar', exact: true }).click();
    await page.getByRole('heading', { name: 'JavaScript y aplicaciones web', exact: true }).waitFor();
    await page.locator('input[name="js-1"][value="a"]').check();
    await page.locator('input[name="js-2"][value="b"]').check();
    await page.locator('input[name="js-3"][value="c"]').check();
    await page.getByRole('button', { name: 'Anterior', exact: true }).click();
    assert(await page.locator('input[name="web-1"][value="a"]').isChecked());
    await page.getByRole('button', { name: 'Continuar', exact: true }).click();
    assert(await page.locator('input[name="js-3"][value="c"]').isChecked());
    await page.getByRole('button', { name: 'Continuar', exact: true }).click();
    await page.locator('input[name="http-1"][value="b"]').check();
    await page.locator('input[name="http-2"][value="a"]').check();
    await page.locator('input[name="http-3"][value="a"]').check();
    const pathResponsePromise = page.waitForResponse(response => response.url().endsWith('/learning-path') && response.request().method() === 'POST');
    await page.getByRole('button', { name: 'Ver mi diagnóstico' }).click();
    await page.getByRole('heading', { name: 'Este es tu punto de partida.' }).waitFor();
    assert((await page.locator('.result-card').filter({ hasText: 'JavaScript y aplicaciones web' }).innerText()).includes('30 puntos'));
    assert(/37[.,]5 %/.test(await page.locator('.result-card').filter({ hasText: 'JavaScript y aplicaciones web' }).innerText()));
    const route = await (await pathResponsePromise).json();
    await page.locator('.path-card').last().waitFor();
    assert.equal(await page.locator('.path-card').count(), 5);
    assert.deepEqual(await page.locator('.path-card h3').allTextContents(), [
      'HTTP: solicitudes y respuestas', 'HTTP: métodos, permisos e idempotencia',
      'Web: HTML semántico y formularios', 'Web: diseño adaptable y accesibilidad',
      'JavaScript: promesas y aplicaciones conectadas',
    ]);
    assert.equal(await page.locator('.learning-path').getAttribute('data-route-id'), route.id);
    assert((await page.locator('.path-summary').innerText()).includes('6 h 30 min'));
    const sqlCard = page.locator('.path-card').filter({ hasText: 'JavaScript: promesas y aplicaciones conectadas' });
    await sqlCard.locator('summary').click();
    assert((await sqlCard.innerText()).includes('37.5 % relativo'));
    for (const link of await page.locator('.path-links a').all()) {
      assert((await link.getAttribute('href')).startsWith('https://'));
      assert.equal(await link.getAttribute('rel'), 'noopener noreferrer');
    }
    await page.screenshot({ path: path.join(output, 'resultado-desktop.png'), fullPage: true });
    await page.locator('.learning-path').screenshot({ path: path.join(output, 'ruta-desktop.png') });
    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Exportar resultados' }).click();
    const download = await downloadPromise;
    await download.saveAs(path.join(output, 'resultado.csv'));
    assert((await fs.readFile(path.join(output, 'resultado.csv'), 'utf8')).includes('JavaScript y aplicaciones web;50;80;30;37.5'));

    await page.reload();
    await page.getByRole('button', { name: 'Historial', exact: true }).click();
    await page.locator('.history-row').first().waitFor();
    // Una caída de la ruta conserva el diagnóstico y permite reintentar.
    const pathPattern = '**/api/evaluations/*/learning-path';
    await page.route(pathPattern, request => request.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ detail: 'Ruta temporalmente no disponible.' }) }));
    await page.locator('.history-row').first().click();
    await page.getByRole('button', { name: 'Reintentar ruta' }).waitFor();
    assert(await page.getByRole('heading', { name: 'Este es tu punto de partida.' }).isVisible());
    await page.unroute(pathPattern);
    await page.getByRole('button', { name: 'Reintentar ruta' }).click();
    await page.locator('.path-card').last().waitFor();
    assert.equal(await page.locator('.learning-path').getAttribute('data-route-id'), route.id);
    const persisted = await (await page.request.get('http://127.0.0.1:5173/api/evaluations/' + route.evaluation_id + '/learning-path')).json();
    assert.deepEqual(persisted, route);
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    await page.screenshot({ path: path.join(output, 'resultado-movil.png'), fullPage: true });
    await page.locator('.learning-path').screenshot({ path: path.join(output, 'ruta-movil.png') });

    await page.getByRole('button', { name: 'Realizar otra evaluación' }).click();
    await page.screenshot({ path: path.join(output, 'inicio-movil.png'), fullPage: true });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    await page.locator('input[value="desarrollo-web"]').check();
    await page.getByRole('button', { name: 'Comenzar evaluación' }).click();
    const correct = [['web-1', 'b'], ['web-2', 'a'], ['web-3', 'c'], ['js-1', 'b'], ['js-2', 'a'], ['js-3', 'c'], ['http-1', 'a'], ['http-2', 'b'], ['http-3', 'c']];
    for (let group = 0; group < 3; group++) {
      for (const [id, answer] of correct.slice(group * 3, group * 3 + 3)) await page.locator(`input[name="${id}"][value="${answer}"]`).check();
      await page.getByRole('button', { name: group < 2 ? 'Continuar' : 'Ver mi diagnóstico', exact: true }).click();
    }
    await page.getByRole('heading', { name: 'No tienes brechas en esta evaluación' }).waitFor();
    assert.equal(await page.locator('.path-card').count(), 0);
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    await page.screenshot({ path: path.join(output, 'ruta-sin-brechas.png'), fullPage: true });
    assert.equal(errors.length, 0, errors.join('\n'));
    await fs.writeFile(path.join(output, 'rf02-ui.json'), JSON.stringify({ route_id: route.id, evaluation_id: route.evaluation_id, activities: 5, estimated_minutes: 390, history_preserved: true, retry_passed: true, no_gap_passed: true, mobile_overflow: false, javascript_errors: errors }, null, 2));
    console.log('RF-01 y RF-02 verificadas: evaluación, rutas, prioridades, prerrequisitos, persistencia, reintento, ausencia de brechas, exportación y móvil. Sin errores de JavaScript.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
