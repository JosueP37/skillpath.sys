# Herramientas oficiales portables, cargadas desde PREPARAR_EQUIPO.ps1.
function Assert-SkillPathToolPath {
    param([string]$ProjectRoot, [string[]]$Paths)
    $prefix = [IO.Path]::GetFullPath((Join-Path $ProjectRoot '.tools')).TrimEnd('\') + '\'
    foreach ($path in $Paths) {
        if (-not [IO.Path]::GetFullPath($path).StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'La ruta de herramientas esta fuera de .tools del proyecto.' }
    }
}
function Get-SkillPathArchive {
    param([string]$Url, [string]$Name, [string]$Sha256, [string]$ProjectRoot, [string]$CacheDir)
    $folder = Join-Path $ProjectRoot '.tools\downloads'
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    $archive = Join-Path $folder $Name
    if ((Test-Path -LiteralPath $archive) -and (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -eq $Sha256) { return $archive }
    if (Test-Path -LiteralPath $archive) { Move-Item -LiteralPath $archive -Destination ($archive + '.invalido-' + [guid]::NewGuid().ToString('N')) }
    if ($CacheDir) {
        foreach ($relative in @($Name, ('downloads\' + $Name), ('mongodb\' + $Name))) {
            $cached = Join-Path $CacheDir $relative
            if ((Test-Path -LiteralPath $cached) -and (Get-FileHash -LiteralPath $cached -Algorithm SHA256).Hash -eq $Sha256) {
                Copy-Item -LiteralPath $cached -Destination $archive
                Write-Host "Cache verificada: $Name"
                return $archive
            }
        }
    }
    $partial = $archive + '.partial'
    Write-Host "Descargando $Name desde su proveedor oficial..."
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $partial -TimeoutSec 180
            if ((Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ne $Sha256) { throw "La huella SHA256 no coincide para $Name. No se ejecutara." }
            Move-Item -LiteralPath $partial -Destination $archive
            return $archive
        } catch {
            if ($attempt -eq 3) { throw }
            Write-Host "Descarga incompleta. Reintentando ($attempt de 3)..."
        }
    }
}

function Expand-SkillPathArchive {
    param([string]$Archive, [string]$Destination)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $prefix = [IO.Path]::GetFullPath($Destination).TrimEnd('\') + '\'
    $zip = [IO.Compression.ZipFile]::OpenRead($Archive)
    try {
        foreach ($entry in $zip.Entries) {
            $target = [IO.Path]::GetFullPath((Join-Path $Destination $entry.FullName))
            if (-not $target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'El archivo contiene una ruta fuera de su carpeta.' }
        }
    } finally { $zip.Dispose() }
    [IO.Compression.ZipFile]::ExtractToDirectory($Archive, $Destination)
}

function Install-SkillPathPython {
    param([string]$ProjectRoot, [string]$CacheDir)
    $archive = Get-SkillPathArchive -ProjectRoot $ProjectRoot -CacheDir $CacheDir -Name 'python.3.12.10.nupkg' -Url 'https://api.nuget.org/v3-flatcontainer/python/3.12.10/python.3.12.10.nupkg' -Sha256 '0eb85c2dfccccf1b17352de4c397f69194035b7d37149eacc16f1147d93de3b8'
    $destination = Join-Path $ProjectRoot '.tools\python312'
    $staging = $destination + '.extraer-' + [guid]::NewGuid().ToString('N')
    Assert-SkillPathToolPath -ProjectRoot $ProjectRoot -Paths @($destination, $staging)
    Expand-SkillPathArchive -Archive $archive -Destination $staging
    $signature = Get-AuthenticodeSignature -FilePath (Join-Path $staging 'tools\python.exe')
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Python Software Foundation') { throw 'No se pudo verificar la firma de Python Software Foundation.' }
    if (Test-Path -LiteralPath $destination) { Move-Item -LiteralPath $destination -Destination ($destination + '.respaldo-' + [guid]::NewGuid().ToString('N')) }
    Move-Item -LiteralPath $staging -Destination $destination
    @{ version='3.12.10'; source='https://api.nuget.org/v3-flatcontainer/python/3.12.10/python.3.12.10.nupkg'; sha256='0eb85c2dfccccf1b17352de4c397f69194035b7d37149eacc16f1147d93de3b8'; executable='.tools/python312/tools/python.exe' } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $destination 'origen.json') -Encoding UTF8
    return (Join-Path $destination 'tools\python.exe')
}

function Install-SkillPathNode {
    param([string]$ProjectRoot, [string]$CacheDir)
    $version = '22.23.4'
    $name = "node-v$version-win-x64.zip"
    $checksum = 'cbc74b5e0982c9dbb41525fd8fb5dcd32fbee237863f7829072f4639a1ce5f20'
    $archive = Get-SkillPathArchive -ProjectRoot $ProjectRoot -CacheDir $CacheDir -Name $name -Url "https://nodejs.org/dist/v$version/$name" -Sha256 $checksum
    $parent = Join-Path $ProjectRoot '.tools\node'
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    $staging = Join-Path $parent ('extraer-' + [guid]::NewGuid().ToString('N'))
    Expand-SkillPathArchive -Archive $archive -Destination $staging
    $source = Join-Path $staging "node-v$version-win-x64"
    $signature = Get-AuthenticodeSignature -FilePath (Join-Path $source 'node.exe')
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'OpenJS Foundation') { throw 'No se pudo verificar la firma de OpenJS Foundation.' }
    $destination = Join-Path $parent "node-v$version-win-x64"
    Assert-SkillPathToolPath -ProjectRoot $ProjectRoot -Paths @($source, $staging, $destination)
    if (Test-Path -LiteralPath $destination) { Move-Item -LiteralPath $destination -Destination ($destination + '.respaldo-' + [guid]::NewGuid().ToString('N')) }
    Move-Item -LiteralPath $source -Destination $destination
    @{ version=$version; source="https://nodejs.org/dist/v$version/$name"; sha256=$checksum; executable=".tools/node/node-v$version-win-x64/node.exe" } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $parent 'origen.json') -Encoding UTF8
    return (Join-Path $destination 'node.exe')
}
