const loginDemo = require('./login_demo.cjs');
const { chromium } = require(process.env.SKILLPATH_PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

(async () => {
  const output = path.resolve(__dirname, '../.logs/qa');
  await fs.mkdir(output, { recursive: true });
  const catalog = JSON.parse(await fs.readFile(path.resolve(__dirname, '../backend/app/category_catalog.json'), 'utf8'));
  const expectedNames = ['Soporte TI 24/7/365', 'Desarrollo Web Moderno', 'Infraestructura y Virtualización', 'Redes y Ciberseguridad'];
  const browser = await chromium.launch({ headless: true, ...(process.env.SKILLPATH_BROWSER_PATH ? { executablePath: process.env.SKILLPATH_BROWSER_PATH } : {}) });
  try {
    const page = await browser.newPage({ baseURL: 'http://127.0.0.1:5173', viewport: { width: 1440, height: 1040 } });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('/');
    await loginDemo(page);
    await page.getByRole('button', { name: 'Evaluación', exact: true }).click();
    await page.locator('.category-option').last().waitFor();
    assert.deepEqual(await page.locator('.category-option strong').allTextContents(), expectedNames);
    assert.equal(await page.locator('input[name="profile"]:checked').count(), 0);
    assert(await page.getByRole('button', { name: 'Comenzar evaluación' }).isDisabled());
    await page.screenshot({ path: path.join(output, 'categorias-desktop.png'), fullPage: true });
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await page.screenshot({ path: path.join(output, 'categorias-movil.png'), fullPage: true });
    await page.setViewportSize({ width: 1440, height: 1040 });

    const evidence = [];
    for (const [profileId, profile] of Object.entries(catalog.profiles)) {
      const publicAssessment = await (await page.request.get('/api/profiles/' + profileId + '/assessment')).json();
      const questionSet = catalog.questions.filter(question => Object.hasOwn(profile.requirements, question.competency_id));
      assert.equal(questionSet.length, 9);
      await page.locator('input[name="profile"][value="' + profileId + '"]').check();
      assert(await page.getByRole('button', { name: 'Comenzar evaluación' }).isEnabled());
      await page.getByRole('button', { name: 'Comenzar evaluación' }).click();
      const submissionPromise = page.waitForResponse(response => response.url().endsWith('/api/evaluations') && response.request().method() === 'POST');
      for (let step = 0; step < publicAssessment.competencies.length; step++) {
        const competency = publicAssessment.competencies[step];
        await page.getByRole('heading', { name: competency.name, exact: true }).waitFor();
        const questions = questionSet.filter(question => question.competency_id === competency.id);
        assert.equal(await page.locator('.question-card').count(), 3);
        for (const question of questions) {
          const wrong = question.options.find(option => option.id !== question.correct).id;
          await page.locator('input[name="' + question.id + '"][value="' + wrong + '"]').check();
        }
        await page.getByRole('button', { name: step < publicAssessment.competencies.length - 1 ? 'Continuar' : 'Ver mi diagnóstico', exact: true }).click();
      }
      const diagnosis = await (await submissionPromise).json();
      await page.locator('.activity-editor').last().waitFor();
      assert.equal(diagnosis.profile_name, profile.name);
      assert.equal(diagnosis.overall_score, 0);
      assert.equal(diagnosis.competencies_with_gap, 3);
      assert.equal(await page.locator('.path-card').count(), 6);
      const endpoint = '/api/evaluations/' + diagnosis.id;
      const route = await (await page.request.get(endpoint + '/learning-path')).json();
      assert.deepEqual(new Set(route.items.map(item => item.competency_id)), new Set(Object.keys(profile.requirements)));
      const firstCard = page.locator('.path-card').first();
      await firstCard.locator('select').selectOption('completed');
      await firstCard.locator('textarea').fill('Práctica de ejemplo para verificar la categoría ' + profile.name + '.');
      await firstCard.getByRole('button', { name: 'Guardar avance' }).click();
      await page.getByRole('status').filter({ hasText: 'Avance guardado' }).waitFor();
      assert.match(await page.locator('[data-progress-percent]').innerText(), /16[.,]67/);
      assert.equal((await (await page.request.get(endpoint)).json()).overall_score, 0);
      await page.screenshot({ path: path.join(output, profileId + '-diagnostico.png'), fullPage: true });
      await page.getByRole('button', { name: 'Panel de seguimiento' }).click();
      const filterPromise = page.waitForResponse(response => response.url().endsWith('/dashboard?profile_id=' + profileId));
      await page.locator('#dashboard-profile').selectOption(profileId);
      await filterPromise;
      await page.locator('[data-metric="evaluations"]').waitFor();
      const dashboard = await (await page.request.get('/api/dashboard?profile_id=' + profileId)).json();
      assert.equal(Number(await page.locator('[data-metric="evaluations"]').innerText()), dashboard.metrics.evaluation_count);
      assert(dashboard.recent_evaluations.every(row => row.profile_name === profile.name));
      await page.getByRole('button', { name: 'Historial', exact: true }).click();
      await page.locator('.history-row').first().waitFor();
      await page.locator('.history-row').filter({ hasText: profile.name }).first().click();
      await page.locator('.activity-editor').last().waitFor();
      assert.equal(await page.locator('.path-card').first().locator('select').inputValue(), 'completed');
      evidence.push({ category: profile.name, evaluation_id: diagnosis.id, path_id: route.id, score: 0, competencies_with_gap: 3, activities: 6, completion_percent: 16.67, dashboard_filter: true, history_preserved: true });
      await page.getByRole('button', { name: 'Realizar otra evaluación' }).click();
    }
    // Los perfiles anteriores son legibles, pero no se pueden reevaluar como una categoría diferente.
    const history = await (await page.request.get('/api/evaluations')).json();
    const archived = history.find(row => !row.category_active);
    if (archived) {
      await page.getByRole('button', { name: 'Historial', exact: true }).click();
      await page.locator('.history-row').filter({ hasText: archived.profile_name }).first().click();
      await page.getByRole('region', { name: 'Diagnóstico anterior' }).waitFor();
      assert(await page.getByRole('button', { name: 'Reevaluar esta categoría' }).isDisabled());
      await page.getByRole('button', { name: 'Realizar otra evaluación' }).click();
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert.equal(errors.length, 0, errors.join('\n'));
    await fs.writeFile(path.join(output, 'categorias-ui.json'), JSON.stringify({ categories: evidence, archived_diagnosis_checked: Boolean(archived), initial_selection_empty: true, mobile_overflow: false, javascript_errors: errors }, null, 2));
    console.log('Cuatro categorías verificadas en navegador: selección, cuestionarios propios, diagnósticos, rutas, avance, filtros, historial y móvil.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
