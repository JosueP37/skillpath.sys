"""Ensayo de instalación en carpeta limpia de esta PC; no altera la demo."""
from pathlib import Path
from zipfile import ZipFile
import json
import os
import shutil
import subprocess
import sys
from uuid import uuid4

root = Path(__file__).resolve().parents[1]
output = root / '.logs/qa'
stage = output / ('instalacion-limpia-' + uuid4().hex[:8])
stage.mkdir(parents=True)
archive = root / 'entrega/SkillPath-codigo.zip'
with ZipFile(archive) as zipped:
    for item in zipped.infolist():
        assert (stage / item.filename).resolve().is_relative_to(stage.resolve())
        assert not set(Path(item.filename).parts) & {'node_modules', '.venv', 'data', '.logs'}
    zipped.extractall(stage)
project = stage / 'SkillPath'
# Reutiliza solo el binario oficial ya disponible; el resto se instala de cero.
source = list((root/'.tools/mongodb').glob('*8.0.32/bin/mongod.exe'))
assert len(source) == 1
target = project / source[0].relative_to(root)
target.parent.mkdir(parents=True)
shutil.copy2(source[0], target)
base_python = getattr(sys, '_base_executable', sys.executable)
with (output/'oct19-instalacion.log').open('w',encoding='utf-8') as log:
    process = subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(project/'PREPARAR_EQUIPO.ps1'),'-PythonExe',base_python,'-ConPruebas'], cwd=project, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    if process.returncode:
        raise RuntimeError('Falló preparación limpia: consulta .logs/qa/oct19-instalacion.log')
    subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(project/'PREPARAR_EQUIPO.ps1'),'-PythonExe',base_python,'-Comprobar'], cwd=project, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW, check=True)
smoke = """
from uuid import uuid4
from fastapi.testclient import TestClient
from pymongo import MongoClient
from app.main import create_app
from app.demo_seed import seed_demo, ADMIN_PASSWORD
name = 'test_skillpath_install_' + uuid4().hex
with MongoClient('mongodb://127.0.0.1:27018', serverSelectionTimeoutMS=3000) as mongo:
    try:
        with TestClient(create_app(database_name=name)) as client:
            seed_demo(mongo[name])
            response = client.post('/api/auth/login',json={'email':'ana.admin@skillpath.test','password':ADMIN_PASSWORD})
            assert response.status_code == 200
            assert len(client.get('/api/team').json()['members']) == 2
            assert client.get('/api/reports/team').json()['summary']['evaluation_count'] == 4
    finally:
        assert name.startswith('test_skillpath_install_') and len(name) == len('test_skillpath_install_') + 32
        mongo.drop_database(name)
print('Smoke de instalación aprobado')
"""
smoke_path = project/'backend/smoke_instalacion.py'
smoke_path.write_text(smoke,encoding='utf-8')
with (output/'oct19-instalacion-smoke.log').open('w',encoding='utf-8') as log:
    subprocess.run([str(project/'backend/.venv/Scripts/python.exe'),str(smoke_path)],cwd=project/'backend',stdout=log,stderr=subprocess.STDOUT,check=True)
result = {'fresh_directory': str(project), 'python_environment_created': True, 'pip_install_passed': True, 'npm_ci_passed': True, 'frontend_build_passed': True, 'preparation_check_passed': True, 'login_team_report_smoke_passed': True, 'mongodb_binary_reused': True, 'physical_second_pc_tested': False}
(output/'oct19-instalacion-verificada.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
