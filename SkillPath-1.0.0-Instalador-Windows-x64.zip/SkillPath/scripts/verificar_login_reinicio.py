"""Comprueba conservación y sesiones durante un reinicio real de la demo."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from bson.json_util import dumps
import httpx
from pymongo import MongoClient

root = Path(__file__).resolve().parents[1]
output = root / '.logs/qa'
names = ['users', 'evaluations', 'learning_paths', 'learning_progress']


def snapshot():
    with MongoClient('mongodb://127.0.0.1:27018', serverSelectionTimeoutMS=3000) as mongo:
        db = mongo['skillpath_demo']
        return {name: {doc['_id']: hashlib.sha256(dumps(doc, sort_keys=True).encode()).hexdigest() for doc in db[name].find()} for name in names}


def lifecycle(filename):
    subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(root / filename)], cwd=root, check=True, creationflags=subprocess.CREATE_NO_WINDOW)


if __name__ == '__main__':
    before = snapshot()
    clients = []
    try:
        for email, password in [('ana.admin@skillpath.test', 'AdminDemo!2026'), ('luis.admin@skillpath.test', 'AdminDemo!2026'), ('carla@skillpath.test', 'UsuarioDemo!2026')]:
            client = httpx.Client(base_url='http://127.0.0.1:8000', timeout=15)
            clients.append(client)
            response = client.post('/api/auth/login', json={'email': email, 'password': password})
            response.raise_for_status()
            client.headers['X-CSRF-Token'] = response.json()['csrf_token']
        output.mkdir(parents=True, exist_ok=True)
        (output/'login-reinicio.json').write_text(json.dumps(before, indent=2),encoding='utf-8')
        lifecycle('DETENER_DEMO.ps1')
        lifecycle('INICIAR_DEMO.ps1')
        assert snapshot() == before, 'Los documentos cambiaron durante el reinicio.'
        sessions = [client.get('/api/auth/me') for client in clients]
        assert all(response.status_code == 200 for response in sessions)
        teams = [clients[index].get('/api/team').json()['members'] for index in [0, 1]]
        assert [len(team) for team in teams] == [2, 1]
        assert [len(client.get('/api/evaluations').json()) for client in clients] == [4, 2, 2]
        assert clients[0].get('/api/dashboard').json()['assigned_user_count'] == 2
        assert clients[1].get('/api/dashboard').json()['assigned_user_count'] == 1
        result = {'unchanged_documents': {name: len(rows) for name, rows in before.items()}, 'all_preserved': True, 'sessions_survived': 3, 'administrator_teams': [2, 1], 'history_counts': [4, 2, 2], 'demo_running': True}
        (output/'login-reinicio-verificado.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(json.dumps(result,indent=2))
    finally:
        for client in clients:
            try:
                client.post('/api/auth/logout')
            except httpx.HTTPError:
                pass
            client.close()
