"""Genera el manual HTML imprimible y sin dependencias desde el Markdown local."""
from pathlib import Path
import base64
import html
import re
import unicodedata

ROOT = Path(__file__).resolve().parents[1]


def inline(value):
    value = html.escape(value)
    value = re.sub(r'`([^`]+)`', r'<code>\1</code>', value)
    value = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', value)
    return re.sub(r'\[([^\]]+)\]\((https?://[^ )]+)\)', r'<a href="\2" target="_blank" rel="noreferrer">\1</a>', value)


def anchor(value):
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode()
    return re.sub(r'[^a-z0-9]+', '-', value.lower()).strip('-')


def build():
    source = (ROOT / 'MANUAL_DE_USO.md').read_text(encoding='utf-8-sig').splitlines()
    body, toc = [], []
    current_list = None
    table = False
    images = {'5. El espacio del administrador': ('oct22-equipo-renovado.png', 'Vista del equipo: resumen, búsqueda y seguimiento.'), '4. Tu recorrido como usuario': ('oct22-panel-renovado.png', 'Panel personal: acceso a rutas, indicadores y diagnósticos.')}

    def close_blocks():
        nonlocal current_list, table
        if current_list:
            body.append('</' + current_list + '>')
            current_list = None
        if table:
            body.append('</tbody></table></div>')
            table = False

    for line in source:
        if not line.strip():
            close_blocks()
            continue
        if line.startswith('|'):
            if re.match(r'^\|[ :|-]+\|$', line):
                continue
            cells = [inline(cell.strip()) for cell in line.strip('|').split('|')]
            if not table:
                body.append('<div class="table-wrap"><table><thead><tr>' + ''.join('<th>' + cell + '</th>' for cell in cells) + '</tr></thead><tbody>')
                table = True
            else:
                body.append('<tr>' + ''.join('<td>' + cell + '</td>' for cell in cells) + '</tr>')
            continue
        heading = re.match(r'^(#{1,3}) (.+)$', line)
        if heading:
            close_blocks()
            level, title = len(heading[1]), heading[2]
            if level == 1:
                continue
            identifier = anchor(title)
            body.append(f'<h{level} id="{identifier}">{inline(title)}</h{level}>')
            if level == 2:
                toc.append(f'<a href="#{identifier}">{html.escape(title)}</a>')
            if title in images:
                filename, caption = images[title]
                path = ROOT / '.logs/qa' / filename
                if path.is_file():
                    encoded = base64.b64encode(path.read_bytes()).decode('ascii')
                    body.append(f'<figure><img src="data:image/png;base64,{encoded}" alt="{caption}"><figcaption>{caption}</figcaption></figure>')
            continue
        item = re.match(r'^(?:([-]) |(\d+)\. )(.+)$', line)
        if item:
            kind = 'ul' if item[1] else 'ol'
            if kind != current_list:
                close_blocks()
                body.append('<' + kind + '>')
                current_list = kind
            body.append('<li>' + inline(item[3]) + '</li>')
            continue
        close_blocks()
        body.append('<p>' + inline(line) + '</p>')
    close_blocks()
    style = '''*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:24px}body{margin:0;background:#f3f6f2;color:#263e30;font:15px/1.85 "Segoe UI",Arial,sans-serif}header{background:#143f34;color:#f1f6e6;padding:44px max(24px,calc((100vw - 1200px)/2))}header small{color:#cfddad;font-weight:600;letter-spacing:2px}header h1{font-size:38px;line-height:1.2;letter-spacing:-1px;margin:16px 0 12px}header p{max-width:740px;color:#c8ddce}header button{border:0;border-radius:8px;padding:12px 18px;background:#dfecb9;color:#1f4f37;font:600 13px "Segoe UI",sans-serif;cursor:pointer}.layout{max-width:1240px;margin:auto;padding:32px 24px 60px;display:grid;grid-template-columns:235px minmax(0,1fr);gap:38px}nav{position:sticky;top:24px;align-self:start;background:white;border:1px solid #dce6d8;border-radius:12px;padding:19px}nav strong{display:block;font-size:12px;color:#597454;margin-bottom:10px}nav a{display:block;text-decoration:none;font-size:12px;line-height:1.6;color:#3c6443;padding:8px 0}article{background:white;border:1px solid #dce6d8;border-radius:16px;padding:34px;min-width:0}h2{font-size:24px;line-height:1.35;letter-spacing:-.4px;margin:40px 0 18px;padding-top:20px;border-top:1px solid #dfe8dc}h3{font-size:17px;color:#2a6442;margin:25px 0 10px}p{margin:12px 0}li{margin:8px 0}a{color:#19613f}code{font:12px/1.5 Consolas,monospace;background:#eef4e9;padding:3px 6px;border-radius:4px;overflow-wrap:anywhere}strong{color:#244b34}.table-wrap{overflow-x:auto;margin:22px 0}table{border-collapse:collapse;width:100%;font-size:12px;line-height:1.7}th,td{padding:11px 13px;text-align:left;border:1px solid #dce6d8;vertical-align:top}th{background:#eaf1e1;color:#345538}figure{margin:25px 0}figure img{max-width:100%;height:auto;border:1px solid #d7e1d4;border-radius:10px}figcaption{font-size:11px;color:#637b5d;margin-top:8px}footer{max-width:1200px;margin:0 auto;padding:0 24px 35px;font-size:12px;color:#657d5d}@media(max-width:800px){.layout{grid-template-columns:1fr;padding:20px 15px;gap:20px}nav{position:static}article{padding:24px 19px}header h1{font-size:31px}header{padding:30px 22px}nav a{padding:5px 0}}@media print{body{background:white;font-size:10pt;line-height:1.6}header{padding:20px;color:#263e30;background:white;border-bottom:2px solid #27583b}header p,header small{color:#3b6244}header h1{font-size:28pt}header button,nav{display:none}.layout{display:block;padding:0;max-width:none}article{border:0;padding:20px}h2{break-after:avoid;font-size:17pt;margin-top:24px}h3{break-after:avoid}tr,figure{break-inside:avoid}figure img{max-height:190mm;object-fit:contain}code{font-size:8pt}a{color:inherit;text-decoration:none}footer{padding:20px}}'''
    document = '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SkillPath · Manual de uso</title><style>' + style + '</style></head><body><header><small>SKILLPATH / ICLOUDFLEX</small><h1>Tu guía para empezar y avanzar.</h1><p>Instalación en otra PC, recorrido del usuario y seguimiento del equipo. Manual de la demostración local.</p><button onclick="window.print()">Imprimir / Guardar como PDF</button></header><div class="layout"><nav aria-label="Contenido del manual"><strong>EN ESTA GUÍA</strong>' + ''.join(toc) + '</nav><article>' + '\n'.join(body) + '</article></div><footer>SkillPath · Capstone Project 2026. Manual disponible sin conexión; los recursos externos requieren Internet.</footer></body></html>'
    for path in [ROOT / 'MANUAL_DE_USO.html', ROOT / 'frontend/public/manual.html']:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(document, encoding='utf-8')
    print('Manual HTML generado en la raiz y frontend/public/manual.html.')


if __name__ == '__main__':
    build()
