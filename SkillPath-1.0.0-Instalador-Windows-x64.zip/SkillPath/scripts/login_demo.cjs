const assert = require('node:assert/strict');
module.exports = async function loginDemo(page) {
  await page.getByRole('button', { name: 'Ingresar', exact: true }).waitFor();
  await page.getByLabel('Correo electrónico').fill(process.env.SKILLPATH_QA_EMAIL || 'carla@skillpath.test');
  await page.getByLabel('Contraseña', { exact: true }).fill(process.env.SKILLPATH_QA_PASSWORD || 'UsuarioDemo!2026');
  await page.getByRole('button', { name: 'Ingresar', exact: true }).click();
  await page.getByRole('button', { name: 'Cerrar sesión' }).waitFor();
  const session = await page.evaluate(async () => (await fetch('/api/auth/me')).json());
  assert(session.csrf_token);
  await page.context().setExtraHTTPHeaders({ 'X-CSRF-Token': session.csrf_token });
};
