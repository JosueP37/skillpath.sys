"""Genera el miniinforme con fotografías reales de la demo del 23/10/2026."""

from base64 import b64encode
from html import escape
from pathlib import Path

from PIL import Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph


ROOT = Path(__file__).resolve().parents[1]
QA = ROOT / ".logs" / "qa" / "informe-oct23"
OUT = ROOT / "output" / "pdf"
ASSETS = OUT / "mini-informe-fotos"
OUT.mkdir(parents=True, exist_ok=True)
ASSETS.mkdir(parents=True, exist_ok=True)

# Recortes de encuadre: conservan el contenido real, sin retocar la interfaz.
PHOTOS = [
    ("01-panel.jpg", (0, 0, 1265, 712)),
    ("02-evaluacion.jpg", (270, 90, 1240, 580)),
    ("03-diagnostico-completo.jpg", (270, 425, 1240, 795)),
    ("04-ruta.jpg", (270, 0, 1220, 690)),
    ("05-equipo-completo.jpg", (270, 405, 1240, 925)),
    ("06-reportes-completo.jpg", (270, 90, 1240, 870)),
    ("07-puestos.jpg", (270, 130, 1240, 660)),
    ("08-recursos.jpg", (270, 95, 1240, 704)),
]

PAGES = [
    {
        "title": "SkillPath | Miniinforme funcional",
        "intro": "Aplicación web para identificar brechas de competencias TI, proponer formación y acompañar el avance del equipo. Capturas reales del 23 de octubre de 2026 en una demo local con datos ficticios.",
        "items": [
            ("1. Panel personal", "El usuario consulta sus evaluaciones, puntuación promedio, rutas y actividades. El botón «Continuar mi aprendizaje» permite retomar una ruta pendiente. La muestra registra 3 de 6 actividades completadas (50 %)."),
            ("2. Evaluación por competencias", "Se elige una de cuatro categorías de servicio. Cada cuestionario general tiene 9 preguntas en 3 competencias, organizadas por pasos. La interfaz muestra las respuestas registradas y solicita completar el paso antes de continuar."),
        ],
    },
    {
        "title": "Del diagnóstico al aprendizaje",
        "intro": "El resultado orienta qué reforzar y vincula el diagnóstico con actividades de formación. Las cifras ilustran el funcionamiento del prototipo.",
        "items": [
            ("3. Diagnóstico de brechas", "Compara la puntuación obtenida con el nivel requerido y calcula la brecha por competencia. En este ejemplo inicial, HTML y HTTP requieren 85 puntos y JavaScript 80; las tres competencias aparecen «Por fortalecer»."),
            ("4. Ruta y registro de avance", "La ruta ordena recursos y ejercicios según las brechas y sus prerrequisitos. Cada actividad admite un estado y una nota de práctica. El ejemplo muestra 50 % completado. El avance es declarado: una nueva evaluación permite comparar puntuaciones."),
        ],
    },
    {
        "title": "Seguimiento del equipo y reportes",
        "intro": "El administrador consulta a las personas que tiene asignadas. Los indicadores distinguen resultados de evaluación y avance de actividades.",
        "items": [
            ("5. Equipo a cargo", "Incluye búsqueda por nombre, correo o categoría, filtro por avance y ordenación. Las tarjetas permiten abrir el seguimiento individual. La muestra de Ana reúne 2 personas y 5 de 15 actividades completadas: 33,33 % agregado."),
            ("6. Reportes con exportación", "Filtra por categoría, usuario y fechas. Resume diagnósticos, rutas, competencias y avance, y permite exportar un archivo CSV. La comparación entre evaluaciones corresponde a datos ficticios; no demuestra una mejora real en una empresa."),
        ],
    },
    {
        "title": "Administración y uso del prototipo",
        "intro": "Los catálogos permiten ajustar los requisitos y el contenido que se utilizarán en nuevas evaluaciones y rutas.",
        "items": [
            ("7. Puestos y requisitos", "El formulario permite definir nombre, categoría, competencias, nivel requerido y criticidad. La foto muestra un borrador de ejemplo, cancelado sin guardar. Los resultados anteriores conservan los requisitos con los que fueron generados."),
            ("8. Recursos de aprendizaje", "El catálogo filtra por competencia y permite registrar o editar recursos con duración, niveles y prerrequisitos. La foto presenta dos recursos de HTML y accesibilidad. También se dispone de ayuda y manual de uso, además del instalador para Windows."),
        ],
    },
]


def create_assets():
    paths = []
    for i, (source, box) in enumerate(PHOTOS, start=1):
        dest = ASSETS / f"funcion-{i:02}.jpg"
        with Image.open(QA / source) as im:
            assert box[2] <= im.width and box[3] <= im.height, source
            im.crop(box).convert("RGB").save(dest, quality=94, subsampling=0)
        paths.append(dest)
    return paths


pdfmetrics.registerFont(TTFont("Segoe", r"C:\Windows\Fonts\segoeui.ttf"))
pdfmetrics.registerFont(TTFont("SegoeBold", r"C:\Windows\Fonts\segoeuib.ttf"))
BODY = ParagraphStyle("body", fontName="Segoe", fontSize=10.5, leading=14, textColor=colors.HexColor("#202b28"), alignment=TA_LEFT)
INTRO = ParagraphStyle("intro", parent=BODY, fontSize=10.5, leading=14)
TITLE = ParagraphStyle("title", fontName="SegoeBold", fontSize=21, leading=25, textColor=colors.black)
HEADING = ParagraphStyle("heading", fontName="SegoeBold", fontSize=12, leading=16, textColor=colors.black)
SMALL = ParagraphStyle("small", parent=BODY, fontSize=8.5, leading=11)


def paragraph(pdf, text, style, x, top, width):
    p = Paragraph(escape(text), style)
    _, height = p.wrap(width, 1000)
    p.drawOn(pdf, x, top - height)
    return top - height


def create_pdf(paths):
    dest = OUT / "Miniinforme_SkillPath.pdf"
    pdf = canvas.Canvas(str(dest), pagesize=letter)
    pdf.setTitle("SkillPath — Miniinforme de funcionalidades")
    pdf.setSubject("Ocho funcionalidades ilustradas con capturas reales de demostración")
    width, height = letter
    margin = 36
    content = width - 2 * margin
    for page_index, page in enumerate(PAGES):
        pdf.setFillColor(colors.HexColor("#285f4e"))
        pdf.setFont("SegoeBold", 8)
        pdf.drawString(margin, height - 27, "ICLOUDFLEX · CAPSTONE PROJECT 2026 · DEMOSTRACIÓN LOCAL")
        top = paragraph(pdf, page["title"], TITLE, margin, height - 38, content)
        top = paragraph(pdf, page["intro"], INTRO, margin, top - 6, content)
        bottom = 80 if page_index == 3 else 40
        area_top = top - 12
        block_height = (area_top - bottom) / 2
        for item_index, (heading, caption) in enumerate(page["items"]):
            block_top = area_top - item_index * block_height
            image_top = paragraph(pdf, heading, HEADING, margin, block_top, content) - 5
            cap_p = Paragraph(escape(caption), BODY)
            _, cap_height = cap_p.wrap(content, 300)
            available_image = block_height - 16 - 5 - cap_height - 16
            with Image.open(paths[page_index * 2 + item_index]) as photo:
                pw, ph = photo.size
            scale = min(content / pw, available_image / ph)
            iw, ih = pw * scale, ph * scale
            ix = margin + (content - iw) / 2
            iy = image_top - ih
            pdf.drawImage(str(paths[page_index * 2 + item_index]), ix, iy, width=iw, height=ih)
            pdf.setStrokeColor(colors.HexColor("#d9e1dd"))
            pdf.setLineWidth(0.5)
            pdf.rect(ix, iy, iw, ih, stroke=1, fill=0)
            cap_p.drawOn(pdf, margin, iy - 6 - cap_height)
            assert iy - 6 - cap_height >= bottom - 1, (page_index, item_index)
        if page_index == 3:
            paragraph(pdf, "Estado: demo local. Verificación registrada el 22/10/2026: 103 pruebas de backend aprobadas y compilación de interfaz correcta. Preguntas, niveles y recursos requieren validación empresarial antes de un piloto.", SMALL, margin, 74, content)
        pdf.setFillColor(colors.HexColor("#58685f"))
        pdf.setFont("Segoe", 8)
        pdf.drawString(margin, 20, "Capturas propias · Datos ficticios · 23 de octubre de 2026")
        pdf.drawRightString(width - margin, 20, f"{page_index + 1} / 4")
        pdf.showPage()
    pdf.save()
    return dest


def create_html(paths):
    chunks = []
    for page_index, page in enumerate(PAGES):
        figures = []
        for item_index, (heading, caption) in enumerate(page["items"]):
            photo = paths[page_index * 2 + item_index]
            encoded = b64encode(photo.read_bytes()).decode("ascii")
            figures.append(f'<figure><h2>{escape(heading)}</h2><img src="data:image/jpeg;base64,{encoded}" alt="Captura real de {escape(heading)}"><figcaption>{escape(caption)}</figcaption></figure>')
        validation = '<p class="status">Estado: demo local. Verificación registrada el 22/10/2026: 103 pruebas de backend aprobadas y compilación de interfaz correcta. Preguntas, niveles y recursos requieren validación empresarial antes de un piloto.</p>' if page_index == 3 else ""
        chunks.append(f'<section class="page"><header>ICLOUDFLEX · CAPSTONE PROJECT 2026 · DEMOSTRACIÓN LOCAL</header><h1>{escape(page["title"])}</h1><p>{escape(page["intro"])}</p>{"".join(figures)}{validation}<footer>Capturas propias · Datos ficticios · 23 de octubre de 2026 <span>{page_index + 1} / 4</span></footer></section>')
    html = '''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>SkillPath · Miniinforme funcional</title><style>
    *{box-sizing:border-box}body{margin:0;background:#eaf0ed;color:#202b28;font-family:"Segoe UI",Arial,sans-serif;line-height:1.45}.page{max-width:816px;margin:24px auto;padding:36px 42px;background:#fff;box-shadow:0 4px 28px #163e2c15}header{font-size:10px;font-weight:700;letter-spacing:.5px;color:#285f4e}h1{font-size:27px;line-height:1.2;margin:12px 0 8px;color:#000}h2{font-size:17px;margin:18px 0 8px;color:#000}p,figcaption{font-size:14px}figure{margin:0 0 22px}img{display:block;max-width:100%;max-height:370px;width:auto;height:auto;margin:0 auto 8px;border:1px solid #d9e1dd}figcaption{text-align:left}.status{font-size:12px}footer{font-size:11px;color:#58685f;margin-top:18px}footer span{float:right}@page{size:letter;margin:12mm}@media print{body{background:white}.page{margin:0;padding:0;box-shadow:none;break-after:page}.page:last-child{break-after:auto}img{max-height:250px}h1{font-size:23px}p,figcaption{font-size:11px}figure{break-inside:avoid;margin-bottom:14px}}
    </style></head><body>''' + "".join(chunks) + "</body></html>"
    dest = OUT / "Miniinforme_SkillPath.html"
    dest.write_text(html, encoding="utf-8")
    return dest


if __name__ == "__main__":
    assets = create_assets()
    print(create_pdf(assets))
    print(create_html(assets))
