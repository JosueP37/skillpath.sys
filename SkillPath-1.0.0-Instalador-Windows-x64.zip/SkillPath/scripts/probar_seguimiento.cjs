const loginDemo = require('./login_demo.cjs');
const { chromium } = require(process.env.SKILLPATH_PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

(async () => {
  const output = path.resolve(__dirname, '../.logs/qa');
  await fs.mkdir(output, { recursive: true });
  const browser = await chromium.launch({ headless: true, ...(process.env.SKILLPATH_BROWSER_PATH ? { executablePath: process.env.SKILLPATH_BROWSER_PATH } : {}) });
  try {
    const page = await browser.newPage({ baseURL: 'http://127.0.0.1:5173', viewport: { width: 1440, height: 1040 } });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:5173');
    await loginDemo(page);
    await page.locator('[data-metric="evaluations"]').waitFor();
    const initial = await (await page.request.get('/api/dashboard')).json();
    assert.equal(Number(await page.locator('[data-metric="evaluations"]').innerText()), initial.metrics.evaluation_count);
    const filtered = page.waitForResponse(response => response.url().endsWith('/dashboard?profile_id=soporte-ti'));
    await page.locator('#dashboard-profile').selectOption('soporte-ti');
    await filtered;
    const junior = await (await page.request.get('/api/dashboard?profile_id=soporte-ti')).json();
    await page.locator('[data-metric="evaluations"]').waitFor();
    assert.equal(Number(await page.locator('[data-metric="evaluations"]').innerText()), junior.metrics.evaluation_count);
    await page.locator('#dashboard-profile').selectOption('');
    await page.locator('[data-metric="evaluations"]').waitFor();
    await page.route('**/api/dashboard', route => route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ detail: 'Panel temporalmente no disponible.' }) }));
    await page.getByRole('button', { name: 'Actualizar panel' }).click();
    await page.getByRole('button', { name: 'Reintentar panel' }).waitFor();
    await page.unroute('**/api/dashboard');
    await page.getByRole('button', { name: 'Reintentar panel' }).click();
    await page.locator('[data-metric="evaluations"]').waitFor();

    const assessment = await (await page.request.get('/api/profiles/desarrollo-web/assessment')).json();
    const wrong = [['web-1','a'],['web-2','b'],['web-3','a'],['js-1','a'],['js-2','b'],['js-3','a'],['http-1','b'],['http-2','a'],['http-3','a']];
    const created = await page.request.post('/api/evaluations', { data: { profile_id: assessment.profile_id, assessment_version: assessment.version, answers: wrong.map(([question_id, option_id]) => ({ question_id, option_id })) } });
    assert.equal(created.status(), 201);
    const evaluation = await created.json();
    const endpoint = '/api/evaluations/' + evaluation.id;
    const route = await (await page.request.post(endpoint + '/learning-path')).json();
    assert.equal(route.items.length, 6);
    await page.getByRole('button', { name: 'Actualizar panel' }).click();
    await page.locator('[data-metric="evaluations"]').waitFor();
    await page.locator('.recent-row').first().click();
    await page.locator('.activity-editor').last().waitFor();
    assert.equal(await page.locator('.path-card').count(), 6);
    const cards = page.locator('.path-card');
    await cards.nth(0).locator('select').selectOption('completed');
    assert(await cards.nth(0).getByRole('button', { name: 'Guardar avance' }).isDisabled());
    await cards.nth(0).locator('textarea').fill('Prueba de demostración: practiqué una solicitud HTTP y revisé la respuesta.');
    await cards.nth(0).getByRole('button', { name: 'Guardar avance' }).click();
    await page.getByRole('status').filter({ hasText: 'Avance guardado' }).waitFor();
    assert.match(await page.locator('[data-progress-percent]').innerText(), /16[.,]67/);
    assert.equal((await (await page.request.get(endpoint)).json()).overall_score, 0);
    await page.locator('.progress-history summary').click();
    assert((await page.locator('.progress-history').innerText()).includes('Pendiente → Completada'));

    await cards.nth(1).locator('select').selectOption('completed');
    await cards.nth(1).locator('textarea').fill('Prueba de demostración: comparé métodos y permisos HTTP.');
    const savePattern = '**/api/evaluations/*/progress/*';
    await page.route(savePattern, route => route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ detail: 'No se pudo guardar el avance. Intenta nuevamente.' }) }));
    await cards.nth(1).getByRole('button', { name: 'Guardar avance' }).click();
    await page.getByRole('alert').filter({ hasText: 'No se pudo guardar' }).waitFor();
    assert.equal((await (await page.request.get(endpoint + '/progress')).json()).completed_activities, 1);
    await page.unroute(savePattern);
    await cards.nth(1).getByRole('button', { name: 'Guardar avance' }).click();
    await page.getByRole('status').filter({ hasText: 'Avance guardado' }).waitFor();
    let progress = await (await page.request.get(endpoint + '/progress')).json();
    assert.equal(progress.completed_activities, 2);

    const otherWindow = await page.request.put(endpoint + '/progress/' + route.items[2].resource.id, { data: { status: 'in_progress', note: 'Prueba desde otra ventana.', expected_version: progress.version } });
    assert.equal(otherWindow.status(), 200);
    await cards.nth(3).locator('select').selectOption('completed');
    await cards.nth(3).locator('textarea').fill('Prueba de práctica guardada tras recargar.');
    await cards.nth(3).getByRole('button', { name: 'Guardar avance' }).click();
    await page.getByRole('alert').filter({ hasText: 'otra ventana' }).waitFor();
    const reloaded = page.waitForResponse(response => response.url().endsWith(endpoint + '/progress') && response.request().method() === 'GET');
    await page.getByRole('button', { name: 'Recargar avance', exact: true }).first().click();
    await reloaded;
    await page.waitForFunction(resourceId => document.querySelector('[data-resource-id="' + resourceId + '"] select')?.value === 'in_progress', route.items[2].resource.id);
    await page.getByRole('alert').filter({ hasText: 'otra ventana' }).waitFor({ state: 'hidden' });
    assert.equal(await cards.nth(2).locator('select').inputValue(), 'in_progress');
    await cards.nth(3).getByRole('button', { name: 'Guardar avance' }).click();
    await page.getByRole('status').filter({ hasText: 'Avance guardado' }).waitFor();
    progress = await (await page.request.get(endpoint + '/progress')).json();
    assert.equal(progress.completed_activities, 3);
    assert.deepEqual(await (await page.request.get(endpoint + '/learning-path')).json(), route);
    await page.screenshot({ path: path.join(output, 'rf07-avance-desktop.png'), fullPage: true });

    await page.reload();
    await page.locator('.recent-row').first().waitFor();
    await page.locator('.recent-row').first().click();
    await page.locator('.activity-editor').last().waitFor();
    assert.equal(await cards.nth(0).locator('select').inputValue(), 'completed');
    assert.equal(await cards.nth(0).locator('textarea').inputValue(), 'Prueba de demostración: practiqué una solicitud HTTP y revisé la respuesta.');
    assert.match(await page.locator('[data-progress-percent]').innerText(), /50/);
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await page.locator('.path-card').first().screenshot({ path: path.join(output, 'rf07-actividad-movil.png') });
    await page.getByRole('button', { name: 'Panel de seguimiento' }).click();
    await page.locator('[data-metric="completion"]').waitFor();
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await page.screenshot({ path: path.join(output, 'rf03-panel-movil.png'), fullPage: true });
    await page.setViewportSize({ width: 1440, height: 1040 });
    await page.screenshot({ path: path.join(output, 'rf03-panel-desktop.png'), fullPage: true });
    const updated = await (await page.request.get('/api/dashboard')).json();
    assert.equal(Number(await page.locator('[data-metric="evaluations"]').innerText()), updated.metrics.evaluation_count);
    assert(updated.metrics.completed_activities >= 3);

    await page.locator('.recent-row').first().click();
    await page.getByRole('button', { name: 'Reevaluar esta categoría' }).click();
    await page.getByRole('heading', { name: 'HTML, CSS y accesibilidad', exact: true }).waitFor();
    const correct = [['web-1','b'],['web-2','a'],['web-3','c'],['js-1','b'],['js-2','a'],['js-3','c'],['http-1','a'],['http-2','b'],['http-3','c']];
    const submissionPromise = page.waitForResponse(response => response.url().endsWith('/api/evaluations') && response.request().method() === 'POST');
    for (let group = 0; group < 3; group++) {
      for (const [id, option] of correct.slice(group * 3, group * 3 + 3)) await page.locator('input[name="' + id + '"][value="' + option + '"]').check();
      await page.getByRole('button', { name: group < 2 ? 'Continuar' : 'Ver mi diagnóstico', exact: true }).click();
    }
    const reevaluation = await (await submissionPromise).json();
    assert.equal(reevaluation.previous_evaluation_id, evaluation.id);
    assert.equal(reevaluation.comparison.score_delta, 100);
    await page.getByRole('heading', { name: 'No tienes brechas en esta evaluación' }).waitFor();
    assert((await page.locator('.reevaluation-summary').innerText()).includes('+100 puntos'));
    assert.equal((await (await page.request.get(endpoint + '/progress')).json()).completed_activities, 3);
    await page.screenshot({ path: path.join(output, 'rf07-reevaluacion.png'), fullPage: true });
    await page.getByRole('button', { name: 'Panel de seguimiento' }).click();
    await page.locator('[data-metric="evaluations"]').waitFor();
    assert.equal(errors.length, 0, errors.join('\n'));
    await fs.writeFile(path.join(output, 'rf03-rf07-ui.json'), JSON.stringify({
      evaluation_id: evaluation.id, path_id: route.id, reevaluation_id: reevaluation.id,
      activities: 6, completed_activities: 3, in_progress_activities: 1,
      completion_percent: 50, linked_score_delta: 100, dashboard_matches_api: true,
      dashboard_filter: true, dashboard_retry: true, save_retry: true,
      concurrent_conflict: true, reload_preserved: true, original_diagnosis_preserved: true,
      mobile_overflow: false, javascript_errors: errors,
    }, null, 2));
    console.log('RF-03/RF-07 verificadas: filtros, indicadores, avance, nota, persistencia, 503, 409, reevaluación y móvil.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
