"""Carga idempotente de ejemplos; conserva cuentas y diagnósticos existentes."""
import os
import sys
from pathlib import Path
from pymongo import MongoClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
from app.demo_seed import seed_demo

if __name__ == '__main__':
    with MongoClient(os.getenv('MONGODB_URI', 'mongodb://127.0.0.1:27018'), serverSelectionTimeoutMS=3000) as client:
        result = seed_demo(client[os.getenv('MONGODB_DATABASE', 'skillpath_demo')])
        print('Cuentas de ejemplo disponibles: 2 administradores y 3 usuarios; 6 diagnósticos propios.')
        print('Consulta README.md para los correos, claves y reparto de equipos.')
