"""Mide el instalador local con cuentas ficticias y verifica sus escrituras."""

import argparse
import asyncio
from collections import Counter
from math import ceil
import json
from pathlib import Path
from statistics import median
from time import perf_counter

import httpx
from pymongo import MongoClient


BASE = 'http://127.0.0.1:5173'
PROFILE = 'redes-ciberseguridad'
LEVELS = (1, 15, 45, 90)


def statistics(samples):
    elapsed = sorted(sample['ms'] for sample in samples)
    return {
        'requests': len(samples), 'passed': sum(sample['ok'] for sample in samples),
        'median_ms': round(median(elapsed), 2),
        'p95_ms': round(elapsed[ceil(len(elapsed) * 0.95) - 1], 2),
        'max_ms': round(elapsed[-1], 2),
    }


async def exercise(client, user_headers, admin_headers, assessment):
    results = []
    evaluation_ids = []

    async def request(label, method, endpoint, headers, expected, **kwargs):
        started = perf_counter()
        try:
            response = await client.request(method, '/api' + endpoint, headers=headers, **kwargs)
            status = response.status_code
            data = response.json() if status == expected else None
        except (httpx.HTTPError, ValueError) as error:
            status = type(error).__name__
            data = None
        results.append({'operation': label, 'ms': (perf_counter() - started) * 1000, 'status': status, 'ok': data is not None})
        return data

    for _ in range(2):
        await request('panel', 'GET', '/dashboard', user_headers, 200)
        await request('reporte', 'GET', '/reports/team', admin_headers, 200)
        await request('cuestionario', 'GET', f'/profiles/{PROFILE}/assessment', user_headers, 200)
        evaluation = await request('diagnostico', 'POST', '/evaluations', user_headers, 201, json=assessment)
        if evaluation is None:
            continue
        evaluation_ids.append(evaluation['id'])
        endpoint = '/evaluations/' + evaluation['id']
        path = await request('ruta', 'POST', endpoint + '/learning-path', user_headers, 201)
        if path is not None:
            await request('avance', 'GET', endpoint + '/progress', user_headers, 200)
    return results, evaluation_ids


async def login(email, password):
    async with httpx.AsyncClient(base_url=BASE, trust_env=False) as client:
        response = await client.post('/api/auth/login', json={'email': email, 'password': password})
        response.raise_for_status()
        return {'Cookie': 'skillpath_session=' + client.cookies['skillpath_session'], 'X-CSRF-Token': response.json()['csrf_token']}


async def measure(db):
    collaborator = await login('carla@skillpath.test', 'UsuarioDemo!2026')
    administrator = await login('ana.admin@skillpath.test', 'AdminDemo!2026')
    async with httpx.AsyncClient(base_url=BASE, trust_env=False) as client:
        response = await client.get(f'/api/profiles/{PROFILE}/assessment', headers=collaborator)
        response.raise_for_status()
        catalog = response.json()
    assessment = {
        'profile_id': PROFILE, 'assessment_version': catalog['version'],
        'answers': [{'question_id': question['id'], 'option_id': question['options'][0]['id']} for question in catalog['questions']],
    }
    waves = []
    for count in LEVELS:
        limits = httpx.Limits(max_connections=count, max_keepalive_connections=count)
        async with httpx.AsyncClient(base_url=BASE, trust_env=False, timeout=15, limits=limits) as client:
            started = perf_counter()
            outcomes = await asyncio.gather(*(exercise(client, collaborator, administrator, assessment) for _ in range(count)))
            elapsed = perf_counter() - started
        samples = [sample for results, _ in outcomes for sample in results]
        ids = [identifier for _, identifiers in outcomes for identifier in identifiers]
        assert len(set(ids)) == len(ids), 'Se repitieron identificadores de evaluación.'
        wave = {
            'clients': count, 'expected_requests': count * 12, **statistics(samples),
            'elapsed_s': round(elapsed, 2), 'requests_per_s': round(len(samples) / elapsed, 2),
            'statuses': dict(Counter(str(sample['status']) for sample in samples)),
            'operations': {name: statistics([sample for sample in samples if sample['operation'] == name])
                           for name in sorted({sample['operation'] for sample in samples})},
            'evaluations_written': db.evaluations.count_documents({'_id': {'$in': ids}}),
            'routes_written': db.learning_paths.count_documents({'evaluation_id': {'$in': ids}}),
        }
        waves.append(wave)
        print(json.dumps({k: v for k, v in wave.items() if k != 'operations'}), flush=True)
    async with httpx.AsyncClient(base_url=BASE, trust_env=False, timeout=5) as client:
        health = await client.get('/api/health')
        dashboard = await client.get('/api/dashboard', headers=collaborator)
    return {'waves': waves, 'recovery': {'health': health.status_code, 'dashboard': dashboard.status_code}}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('installation', type=Path, help='Copia de instalación limpia dedicada a QA.')
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    installation = args.installation.resolve()
    original = Path(__file__).resolve().parents[1]
    if installation == original or not (installation / 'INSTALAR_Y_ABRIR.cmd').is_file():
        parser.error('Indica una copia de QA separada de la aplicación original.')
    with MongoClient('mongodb://127.0.0.1:27018', serverSelectionTimeoutMS=2000) as mongo:
        live_path = Path(mongo.admin.command('getCmdLineOpts')['parsed']['storage']['dbPath']).resolve()
        if live_path != installation / 'data' / 'mongodb':
            parser.error('La instancia local no pertenece a la instalación limpia indicada.')
        report = asyncio.run(measure(mongo.skillpath_demo))
    args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    assert report['recovery'] == {'health': 200, 'dashboard': 200}
    for wave in report['waves']:
        if wave['clients'] <= 45:
            assert wave['expected_requests'] == wave['requests'] == wave['passed']
            assert wave['evaluations_written'] == wave['routes_written'] == wave['clients'] * 2
            assert wave['max_ms'] < 3000
