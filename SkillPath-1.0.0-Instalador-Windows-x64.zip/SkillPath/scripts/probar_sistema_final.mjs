import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { createRequire } from 'node:module'
import { performance } from 'node:perf_hooks'

const require = createRequire(import.meta.url)
const { chromium } = require(process.env.SKILLPATH_PLAYWRIGHT_MODULE || 'playwright')
const baseURL = 'http://127.0.0.1:5173'
const output = path.resolve(process.argv[2] || '.logs/qa')
const cases = []
const run = Date.now().toString(36)
const name = `Pruebas de componentes ${run}`
const job = `Analista de calidad web ${run}`
const material = `Práctica de verificación de componentes ${run}`
const feedback = 'Agrega el resultado esperado.'
const evidenceUrl = 'https://example.test/practica'
const errors = []
let browser

async function open(email, password, width) {
  const context = await browser.newContext({ viewport: { width, height: 980 }, baseURL })
  const page = await context.newPage()
  page.setDefaultTimeout(12000)
  page.on('pageerror', error => errors.push(error.message))
  await page.goto('/')
  await page.getByLabel('Correo electrónico').fill(email)
  await page.getByLabel('Contraseña', { exact: true }).fill(password)
  await page.getByRole('button', { name: 'Ingresar', exact: true }).click()
  await page.getByRole('button', { name: 'Cerrar sesión' }).waitFor()
  return page
}

async function noOverflow(page) {
  assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1))
}

try {
  browser = await chromium.launch({
    headless: true, executablePath: process.env.SKILLPATH_BROWSER_PATH,
  })
  const health = await fetch(baseURL + '/api/health')
  assert.equal(health.status, 200)
  assert.equal((await health.json()).database, 'mongodb')
  const index = await (await fetch(baseURL)).text()
  assert.match(index, /src="\/assets\/[^"]+\.js"/)
  const smoke = { frontend: 200, compiledAssets: true, api: 200, database: 'mongodb' }

  const admin = await open('ana.admin@skillpath.test', 'AdminDemo!2026', 1366)
  await admin.getByRole('button', { name: 'Puestos y competencias' }).click()
  await admin.getByRole('button', { name: 'Banco de preguntas' }).click()
  await admin.getByLabel('Categoría', { exact: true }).selectOption('desarrollo-web')
  await admin.getByRole('button', { name: 'Nueva competencia' }).click()
  await admin.getByLabel('Nombre de la competencia').fill(name)
  await admin.getByLabel('Enunciado').fill('¿Qué se verifica en una prueba funcional?')
  await admin.getByRole('textbox', { name: 'Opción 1', exact: true }).fill('El comportamiento esperado')
  await admin.getByRole('textbox', { name: 'Opción 2', exact: true }).fill('Solo el nombre del archivo')
  await admin.getByRole('button', { name: 'Guardar competencia' }).click()
  const card = admin.locator('.catalog-card').filter({ has: admin.getByRole('heading', { name, exact: true }) })
  await card.getByRole('button', { name: 'Editar competencia' }).click()
  await admin.getByLabel('Enunciado').fill('¿Qué comprueba una prueba funcional?')
  await admin.getByRole('button', { name: 'Guardar competencia' }).click()
  await admin.locator('.save-notice').getByText('Competencia y preguntas guardadas.').waitFor()
  await noOverflow(admin)
  await admin.getByRole('button', { name: 'Volver a puestos' }).click()
  await admin.getByRole('button', { name: 'Nuevo puesto' }).click()
  await admin.getByLabel('Nombre del puesto').fill(job)
  await admin.locator('[name=job-category]').selectOption('desarrollo-web')
  const checkedCompetencies = admin.locator('.matrix-check input:checked')
  while (await checkedCompetencies.count()) await checkedCompetencies.first().uncheck()
  await admin.getByRole('checkbox', { name }).check()
  await admin.getByRole('button', { name: 'Guardar puesto' }).click()
  await admin.getByRole('heading', { name: job }).waitFor()

  await admin.getByRole('button', { name: 'Recursos de aprendizaje' }).click()
  await admin.getByRole('button', { name: 'Nuevo recurso' }).click()
  await admin.getByLabel('Título').fill(material)
  await admin.locator('[name=resource-competency]').selectOption({ label: name })
  await admin.getByLabel('Proveedor').fill('Equipo de calidad')
  await admin.getByLabel('Práctica propuesta').fill('Registra el resultado esperado y el observado.')
  await admin.getByLabel('URL HTTP/HTTPS').fill('https://example.test/recurso')
  await admin.getByLabel('Motivo del cambio').fill('Alta de material ficticio de prueba.')
  await admin.getByRole('button', { name: 'Guardar recurso' }).click()
  await admin.getByRole('heading', { name: material }).waitFor()
  cases.push('S01')

  const user = await open('carla@skillpath.test', 'UsuarioDemo!2026', 390)
  await user.getByRole('button', { name: 'Abrir menú' }).click()
  await user.getByRole('button', { name: 'Evaluación', exact: true }).click()
  await user.locator('input[value=desarrollo-web]').check()
  await user.getByLabel('Puesto objetivo (opcional)').selectOption({ label: job })
  await user.getByRole('button', { name: 'Comenzar evaluación' }).click()
  await user.getByText('¿Qué comprueba una prueba funcional?', { exact: false }).waitFor()
  await user.getByRole('radio', { name: 'Solo el nombre del archivo' }).check()
  await user.getByRole('button', { name: 'Ver mi diagnóstico' }).click()
  await user.getByRole('heading', { name: material }).waitFor()
  await user.getByLabel('Estado de la actividad').selectOption('completed')
  await user.getByLabel('Nota de práctica').fill('Ejecuté la práctica.')
  await user.getByLabel('Enlace de evidencia').fill(evidenceUrl)
  await user.getByRole('button', { name: 'Guardar avance' }).click()
  await user.getByText('Evidencia pendiente de revisión').waitFor()
  await noOverflow(user)
  cases.push('S02')

  await admin.getByRole('button', { name: 'Mi equipo' }).click()
  await admin.getByRole('button', { name: 'Ver seguimiento de Carla Ruiz' }).click()
  await admin.locator('.history-row').filter({ hasText: job }).click()
  assert.equal(await admin.getByRole('link', { name: 'Abrir evidencia' }).getAttribute('href'), evidenceUrl)
  await admin.getByLabel('Decisión sobre la evidencia').selectOption('changes_requested')
  await admin.getByLabel('Comentario').fill(feedback)
  await admin.getByRole('button', { name: 'Guardar revisión' }).click()
  await admin.getByText('Se solicitaron cambios', { exact: true }).first().waitFor()
  await user.getByRole('button', { name: 'Recargar avance' }).click()
  await user.getByText(feedback, { exact: true }).first().waitFor()
  await user.getByLabel('Nota de práctica').fill('Resultado esperado: mensaje visible. Resultado observado: correcto.')
  await user.getByRole('button', { name: 'Guardar avance' }).click()
  await user.getByText('Evidencia pendiente de revisión').waitFor()
  await admin.getByRole('button', { name: 'Recargar avance' }).click()
  await admin.getByText('Evidencia pendiente de revisión').waitFor()
  await admin.getByLabel('Decisión sobre la evidencia').selectOption('approved')
  await admin.getByRole('button', { name: 'Guardar revisión' }).click()
  await admin.getByText('1 de 1 evidencias validadas').waitFor()
  await user.getByRole('button', { name: 'Recargar avance' }).click()
  await user.getByText('1 de 1 evidencias validadas').waitFor()
  await user.getByText('Evidencia validada', { exact: true }).first().scrollIntoViewIfNeeded()
  await noOverflow(user)
  await user.screenshot({ path: path.join(output, 'evidencia-movil.png') })
  cases.push('S03')

  await admin.getByRole('button', { name: 'Panel de seguimiento' }).click()
  const dashboardTimes = []
  for (let sample = 0; sample < 10; sample++) {
    await admin.locator('.dashboard[aria-busy="false"]').waitFor()
    const started = performance.now()
    const refreshed = admin.waitForResponse(response => new URL(response.url()).pathname === '/api/dashboard' && response.ok())
    await admin.getByRole('button', { name: 'Actualizar panel' }).click()
    await refreshed
    await admin.locator('.dashboard[aria-busy="false"]').waitFor()
    await admin.getByText('Diagnósticos recientes', { exact: false }).first().waitFor()
    dashboardTimes.push(Math.round(performance.now() - started))
  }
  await admin.getByRole('button', { name: 'Reportes del equipo' }).click()
  await admin.locator('[data-report-users]').waitFor()
  const report = await admin.evaluate(async () => (await fetch('/api/reports/team')).json())
  assert.equal(report.summary.user_count, 2)
  assert.equal(await admin.locator('.report-table tbody tr').count(), report.rows.length)
  assert(report.rows.some(row => row.job_profile_name === job && row.user_name === 'Carla Ruiz'))
  const download = admin.waitForEvent('download')
  await admin.getByRole('button', { name: 'Exportar reporte CSV' }).click()
  const reportPath = path.join(output, 'reporte-equipo.csv')
  await (await download).saveAs(reportPath)
  const csv = await readFile(reportPath, 'utf8')
  assert(csv.includes('Carla Ruiz') && csv.includes('Diego Pérez') && !csv.includes('Lucía Gómez'))
  assert.equal(await user.evaluate(async () => (await fetch('/api/reports/team')).status), 403)
  await noOverflow(admin)
  await admin.screenshot({ path: path.join(output, 'reporte-escritorio.png') })
  cases.push('S04')

  await user.reload()
  await user.getByRole('button', { name: 'Abrir menú' }).click()
  await user.getByRole('button', { name: 'Historial' }).click()
  await user.locator('.history-row').first().click()
  await user.getByText('1 de 1 evidencias validadas').waitFor()
  await user.getByRole('button', { name: 'Reevaluar esta categoría' }).click()
  await user.getByRole('radio', { name: 'El comportamiento esperado' }).check()
  await user.getByRole('button', { name: 'Ver mi diagnóstico' }).click()
  await user.getByRole('region', { name: 'Comparación con la evaluación anterior' }).waitFor()
  cases.push('S05')

  await admin.getByRole('button', { name: 'Ayuda y manual' }).click()
  await admin.getByRole('heading', { name: 'Ayuda y manual', exact: true }).waitFor()
  const popup = admin.waitForEvent('popup')
  await admin.getByRole('link', { name: 'Abrir manual completo' }).click()
  const manual = await popup
  await manual.getByText('SkillPath 1.0.0', { exact: false }).first().waitFor()
  const manualDownload = admin.waitForEvent('download')
  await admin.getByRole('link', { name: 'Descargar manual para consultar sin conexión' }).click()
  assert.match((await manualDownload).suggestedFilename(), /SkillPath\.html$/)
  await admin.getByRole('button', { name: 'Cerrar sesión' }).click()
  await admin.getByRole('button', { name: 'Ingresar', exact: true }).waitFor()
  cases.push('S06')

  assert.deepEqual(errors, [])
  await writeFile(path.join(output, 'sistema.json'), JSON.stringify({
    browser: await browser.version(), viewports: [1366, 390], smoke, cases,
    dashboardRefreshMs: dashboardTimes, horizontalOverflow: false, errors,
  }, null, 2))
  console.log('Sistema: aprobados ' + cases.join(', '))
} catch (error) {
  console.error('Casos aprobados antes de la interrupción:', cases)
  for (const context of browser?.contexts() || []) {
    for (const [index, page] of context.pages().entries()) {
      const name = `fallo-${page.viewportSize()?.width}-${index}.png`
      await page.screenshot({ path: path.join(output, name) }).catch(() => {})
    }
  }
  throw error
} finally {
  await browser?.close()
}
