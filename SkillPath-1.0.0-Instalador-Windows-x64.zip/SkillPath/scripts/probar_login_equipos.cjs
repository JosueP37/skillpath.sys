const { chromium } = require(process.env.SKILLPATH_PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

(async () => {
  assert(process.env.SKILLPATH_QA_API, 'Ejecutar mediante probar_login_equipos.py para aislar los datos.');
  const output = path.resolve(__dirname, '../.logs/qa');
  const browser = await chromium.launch({ headless: true, executablePath: process.env.SKILLPATH_BROWSER_PATH });
  const errors = [];
  const evidence = { adminTeams: [], categories: [], registration: false, logout: false, isolation: false, mobile: false };
  const correct = JSON.parse(process.env.SKILLPATH_QA_ANSWERS);
  async function pageFor(width = 1440) {
    const context = await browser.newContext({ baseURL: 'http://127.0.0.1:5173', viewport: { width, height: 1000 } });
    await context.route('**/api/**', async route => {
      const incoming = new URL(route.request().url());
      const response = await route.fetch({ url: process.env.SKILLPATH_QA_API + incoming.pathname + incoming.search });
      await route.fulfill({ response });
    });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('/');
    await page.getByRole('button', { name: 'Ingresar', exact: true }).waitFor();
    return page;
  }
  async function login(page, email, password) {
    await page.getByLabel('Correo electrónico').fill(email);
    await page.getByLabel('Contraseña', { exact: true }).fill(password);
    await page.getByRole('button', { name: 'Ingresar', exact: true }).click();
    await page.getByRole('button', { name: 'Cerrar sesión' }).waitFor();
  }
  async function api(page, endpoint, method = 'GET', data) {
    return page.evaluate(async ({ endpoint, method, data }) => {
      const session = await (await fetch('/api/auth/me')).json();
      const response = await fetch('/api' + endpoint, { method, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': session.csrf_token }, ...(data ? { body: JSON.stringify(data) } : {}) });
      return { status: response.status, data: await response.json().catch(() => null) };
    }, { endpoint, method, data });
  }
  async function noOverflow(page) {
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true);
  }
  try {
    const anonymous = await pageFor();
    await anonymous.screenshot({ path: path.join(output, 'login-escritorio.png'), fullPage: true });
    await anonymous.getByRole('tab', { name: 'Crear cuenta' }).click();
    await anonymous.getByLabel('Administrador a cargo').waitFor();
    await anonymous.locator('#auth-administrator option').nth(2).waitFor({ state: 'attached' });
    assert.equal(await anonymous.locator('#auth-administrator').inputValue(), '');
    await anonymous.screenshot({ path: path.join(output, 'registro-escritorio.png'), fullPage: true });

    const ana = await pageFor();
    await login(ana, 'ana.admin@skillpath.test', 'AdminDemo!2026');
    await ana.locator('.team-card').nth(1).waitFor();
    assert.equal(await ana.locator('.team-card').count(), 2);
    assert.equal(await ana.getByRole('button', { name: 'Evaluación', exact: true }).count(), 0);
    evidence.adminTeams.push({ admin: 'Ana Torres', users: 2 });
    await ana.screenshot({ path: path.join(output, 'equipo-ana-escritorio.png'), fullPage: true });
    await ana.locator('.team-card').filter({ hasText: 'Carla Ruiz' }).click();
    await ana.locator('.evolution-card').waitFor();
    assert.match(await ana.locator('.evolution-card').innerText(), /\+100 puntos/);
    await ana.screenshot({ path: path.join(output, 'evolucion-carla-escritorio.png'), fullPage: true });
    await ana.locator('.history-row').last().click();
    await ana.locator('.activity-readonly').last().waitFor();
    assert.equal(await ana.locator('.activity-editor').count(), 0);
    const carlaId = (await api(ana, '/evaluations')).data.find(row => row.overall_score === 0).id;
    await ana.reload();
    await ana.getByRole('button', { name: 'Mi equipo', exact: true }).waitFor();
    await noOverflow(ana);

    const luis = await pageFor();
    await login(luis, 'luis.admin@skillpath.test', 'AdminDemo!2026');
    await luis.locator('.team-card').waitFor();
    assert.equal(await luis.locator('.team-card').count(), 1);
    assert.match(await luis.locator('.team-card').innerText(), /Lucía Gómez/);
    assert.equal((await api(luis, '/evaluations/' + carlaId)).status, 404);
    evidence.adminTeams.push({ admin: 'Luis Medina', users: 1 });
    evidence.isolation = true;

    const carla = await pageFor();
    await login(carla, 'carla@skillpath.test', 'UsuarioDemo!2026');
    await carla.locator('[data-metric="evaluations"]').waitFor();
    assert.equal(await carla.locator('[data-metric="evaluations"]').innerText(), '2');
    assert.equal((await api(carla, '/team')).status, 403);
    await carla.getByRole('button', { name: 'Historial', exact: true }).click();
    await carla.locator('.history-row').last().waitFor();
    assert.equal(await carla.locator('.history-row').count(), 2);
    await carla.getByRole('button', { name: 'Cerrar sesión' }).click();
    await carla.getByRole('button', { name: 'Ingresar', exact: true }).waitFor();
    assert.equal(await carla.locator('.history-row').count(), 0);
    evidence.logout = true;

    await anonymous.getByLabel('Nombre completo').fill('Usuario QA');
    await anonymous.getByLabel('Correo electrónico').fill('nuevo.qa@skillpath.test');
    await anonymous.getByLabel('Contraseña', { exact: true }).fill('UsuarioQA!2026');
    await anonymous.getByLabel('Confirmar contraseña').fill('UsuarioQA!2026');
    await anonymous.getByLabel('Administrador a cargo').selectOption({ label: 'Ana Torres' });
    await anonymous.getByRole('button', { name: 'Crear mi cuenta', exact: true }).click();
    await anonymous.locator('[data-metric="evaluations"]').waitFor();
    assert.equal(await anonymous.locator('[data-metric="evaluations"]').innerText(), '0');
    const me = (await api(anonymous, '/auth/me')).data;
    assert.equal(me.user.administrator.name, 'Ana Torres');
    evidence.registration = true;
    await anonymous.reload();
    await anonymous.getByRole('button', { name: 'Cerrar sesión' }).waitFor();
    const profiles = (await api(anonymous, '/profiles')).data;
    for (const profile of profiles) {
      await anonymous.getByRole('button', { name: 'Evaluación', exact: true }).click();
      await anonymous.locator('input[name="profile"][value="' + profile.id + '"]').check();
      await anonymous.getByRole('button', { name: 'Comenzar evaluación', exact: true }).click();
      const assessment = (await api(anonymous, '/profiles/' + profile.id + '/assessment')).data;
      assert(assessment.questions.every(q => !('correct' in q)));
      for (let step = 0; step < assessment.competencies.length; step++) {
        for (const q of assessment.questions.filter(q => q.competency_id === assessment.competencies[step].id)) {
          const wrong = q.options.find(option => option.id !== correct[q.id]).id;
          await anonymous.locator('input[name="' + q.id + '"][value="' + wrong + '"]').check();
        }
        await anonymous.getByRole('button', { name: step < 2 ? 'Continuar' : 'Ver mi diagnóstico', exact: true }).click();
      }
      await anonymous.locator('.activity-editor').last().waitFor();
      assert.equal(await anonymous.locator('.path-card').count(), 6);
      const recent = (await api(anonymous, '/evaluations')).data[0];
      assert.equal(recent.overall_score, 0);
      assert.equal(recent.user_id, me.user.id);
      const card = anonymous.locator('.path-card').first();
      await card.locator('select').selectOption('completed');
      await card.locator('textarea').fill('Ejemplo QA aislado: completé la práctica.');
      await card.getByRole('button', { name: 'Guardar avance' }).click();
      await anonymous.getByRole('status').filter({ hasText: 'Avance guardado' }).waitFor();
      assert.match(await anonymous.locator('[data-progress-percent]').innerText(), /16[.,]67/);
      evidence.categories.push({ category: profile.name, evaluation: recent.id, score: 0, completed: 1 });
      await anonymous.getByRole('button', { name: 'Realizar otra evaluación' }).click();
    }
    const history = (await api(anonymous, '/evaluations')).data;
    const web = history.find(item => item.profile_id === 'desarrollo-web');
    await anonymous.getByRole('button', { name: 'Historial', exact: true }).click();
    await anonymous.locator('.history-row').filter({ hasText: 'Desarrollo Web Moderno' }).click();
    await anonymous.getByRole('button', { name: 'Reevaluar esta categoría' }).click();
    const webAssessment = (await api(anonymous, '/profiles/desarrollo-web/assessment')).data;
    for (let step = 0; step < 3; step++) {
      for (const q of webAssessment.questions.filter(q => q.competency_id === webAssessment.competencies[step].id)) {
        await anonymous.locator('input[name="' + q.id + '"][value="' + correct[q.id] + '"]').check();
      }
      await anonymous.getByRole('button', { name: step < 2 ? 'Continuar' : 'Ver mi diagnóstico', exact: true }).click();
    }
    await anonymous.locator('.reevaluation-summary').waitFor();
    await anonymous.locator('.path-empty').waitFor();
    const reevaluation = (await api(anonymous, '/evaluations')).data[0];
    assert.equal(reevaluation.previous_evaluation_id, web.id);
    assert.equal(reevaluation.comparison.score_delta, 100);
    assert.equal((await api(anonymous, '/evaluations/' + web.id + '/progress')).data.completed_activities, 1);
    const download = anonymous.waitForEvent('download');
    await anonymous.getByRole('button', { name: 'Exportar resultados' }).click();
    assert.match((await download).suggestedFilename(), /\.csv$/);
    evidence.reevaluation = { from: 0, to: 100, previousProgressPreserved: true };

    const mobile = await pageFor(390);
    await noOverflow(mobile);
    await mobile.screenshot({ path: path.join(output, 'login-movil.png'), fullPage: true });
    await login(mobile, 'ana.admin@skillpath.test', 'AdminDemo!2026');
    await mobile.locator('.team-card').last().waitFor();
    assert.equal(await mobile.locator('.team-card').count(), 3);
    await noOverflow(mobile);
    await mobile.screenshot({ path: path.join(output, 'equipo-ana-movil.png'), fullPage: true });
    await mobile.locator('.team-card').filter({ hasText: 'Usuario QA' }).click();
    await mobile.locator('.evolution-card').last().waitFor();
    await noOverflow(mobile);
    await mobile.screenshot({ path: path.join(output, 'evolucion-movil.png'), fullPage: true });
    evidence.mobile = true;
    assert.deepEqual(errors, []);
    evidence.javascriptErrors = errors;
    await fs.writeFile(path.join(output, 'login-equipos-ui.json'), JSON.stringify(evidence, null, 2));
    console.log(JSON.stringify(evidence, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
