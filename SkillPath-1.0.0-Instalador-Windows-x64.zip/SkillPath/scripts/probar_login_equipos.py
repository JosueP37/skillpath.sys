"""Ejecuta UI contra una base aislada; la demo del usuario no se modifica."""
import json
import os
from pathlib import Path
import subprocess
import time
from uuid import uuid4
import sys
import httpx
from pymongo import MongoClient

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'backend'))
from app.demo_seed import seed_demo
from app.catalog import QUESTIONS

name = 'test_skillpath_ui_' + uuid4().hex
env = os.environ.copy()
env['MONGODB_DATABASE'] = name
env['SKILLPATH_QA_API'] = 'http://127.0.0.1:8001'
env['SKILLPATH_QA_ANSWERS'] = json.dumps({q['id']: q['correct'] for q in QUESTIONS})
output = root / '.logs/qa'
output.mkdir(parents=True, exist_ok=True)
server = None
with MongoClient('mongodb://127.0.0.1:27018', serverSelectionTimeoutMS=3000) as mongo, (output/'login-ui-servidor.log').open('w',encoding='utf-8') as log:
    try:
        seed_demo(mongo[name])
        server = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', '8001'], cwd=root/'backend', env=env, stdout=log, stderr=log)
        deadline = time.monotonic() + 20
        while True:
            try:
                response = httpx.get(env['SKILLPATH_QA_API'] + '/api/health', timeout=1)
                if response.status_code == 200:
                    break
            except httpx.HTTPError:
                pass
            if server.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError('No inició el backend aislado de UI; consulta login-ui-servidor.log.')
            time.sleep(.25)
        node = env.get('SKILLPATH_NODE_PATH', r'C:\nvm4w\nodejs\node.exe')
        script_name = env.get('SKILLPATH_QA_SCRIPT', 'probar_login_equipos.cjs')
        assert script_name in {'probar_login_equipos.cjs', 'probar_catalogos_reportes.cjs'}
        subprocess.run([node, str(root/'scripts'/script_name)], cwd=root, env=env, check=True)
        assert mongo[name].users.count_documents({'role': 'admin'}) == 2
        assert mongo[name].users.count_documents({'role': 'user'}) == (4 if script_name == 'probar_login_equipos.cjs' else 3)
    finally:
        if server:
            server.terminate()
            try:
                server.wait(timeout=10)
            except subprocess.TimeoutExpired:
                server.kill(); server.wait(timeout=5)
        assert name.startswith('test_skillpath_ui_') and len(name) == len('test_skillpath_ui_') + 32
        mongo.drop_database(name)
