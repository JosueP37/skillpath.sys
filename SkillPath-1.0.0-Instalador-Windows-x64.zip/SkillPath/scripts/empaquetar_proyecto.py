"""Paquete de código transferible, sin datos, entornos virtuales ni secretos."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'node_modules', '.venv', '__pycache__', '.pytest_cache', 'dist', '_fuentes', '.logs', '.git', '.tools', 'data', 'entrega'}
TOP = {'README.md', 'CONTEXTO.md', 'AGENTS.md', '.gitignore', 'INICIAR_DEMO.ps1', 'DETENER_DEMO.ps1', 'PREPARAR_EQUIPO.ps1', 'INICIAR_DEMO.cmd', 'DETENER_DEMO.cmd', 'PREPARAR_EQUIPO.cmd', 'INSTALAR_Y_ABRIR.cmd', 'ABRIR_MANUAL.cmd', 'MANUAL_DE_USO.md', 'MANUAL_DE_USO.html', 'INSTALACION_OTRA_MAQUINA.md', 'AVANCE_REQUISITOS.md'}


def source_files():
    for path in ROOT.iterdir():
        if path.is_file() and path.name in TOP:
            yield path
    for directory in ['frontend', 'backend', 'scripts', 'analisis']:
        for current, directories, filenames in os.walk(ROOT / directory):
            directories[:] = [name for name in directories if name not in EXCLUDED and not name.startswith('.venv')]
            for filename in filenames:
                path = Path(current) / filename
                relative = path.relative_to(ROOT)
                if path.name.startswith('.env') and path.name != '.env.example':
                    continue
                if directory == 'analisis' and (len(relative.parts) != 2 or path.suffix != '.md' and path.name != 'preparar_mongodb.py'):
                    continue
                if path.suffix in {'.py', '.cjs', '.mjs', '.md', '.json', '.ts', '.tsx', '.css', '.html', '.txt', '.ps1', '.svg', '.example'} or path.name == '.gitignore':
                    yield path


def build(output=None):
    destination = output or ROOT / 'entrega' / 'SkillPath-codigo.zip'
    destination.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(source_files())
    with ZipFile(destination, 'w', ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, Path('SkillPath') / path.relative_to(ROOT))
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    info = {'file': destination.name, 'sha256': digest, 'source_files': len(files), 'contains_database': False, 'contains_virtual_environment': False}
    destination.with_suffix('.sha256').write_text(digest + '  ' + destination.name + '\n', encoding='ascii')
    destination.with_suffix('.json').write_text(json.dumps(info, indent=2), encoding='utf-8')
    print(json.dumps(info, indent=2))
    return destination


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    build(parser.parse_args().output)
