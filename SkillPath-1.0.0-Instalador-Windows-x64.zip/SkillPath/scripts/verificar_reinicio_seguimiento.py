"""Comparación de registros de demo antes/después de reiniciar los servicios."""
import json
from pathlib import Path
import sys
from urllib.request import urlopen
from pymongo import MongoClient

root = Path(__file__).resolve().parents[1]
qa = root / '.logs' / 'qa'
case = json.loads((qa / 'rf03-rf07-ui.json').read_text(encoding='utf-8'))


def get(path):
    with urlopen('http://127.0.0.1:5173/api/' + path, timeout=10) as response:
        return json.load(response)


mongo = MongoClient('mongodb://127.0.0.1:27018', serverSelectionTimeoutMS=3000)
try:
    db = mongo.skillpath_demo
    dashboard = get('dashboard')
    snapshot = {
        'counts': {name: db[name].count_documents({}) for name in ['evaluations', 'learning_paths', 'learning_progress']},
        'evaluation': get('evaluations/' + case['evaluation_id']),
        'path': get('evaluations/' + case['evaluation_id'] + '/learning-path'),
        'progress': get('evaluations/' + case['evaluation_id'] + '/progress'),
        'reevaluation': get('evaluations/' + case['reevaluation_id']),
        'dashboard_metrics': dashboard['metrics'],
        'dashboard_competencies': dashboard['competencies'],
    }
finally:
    mongo.close()

before_path = qa / 'antes-reinicio-rf03-rf07.json'
if sys.argv[1] == 'before':
    before_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Snapshot guardado:', snapshot['counts'])
else:
    before = json.loads(before_path.read_text(encoding='utf-8'))
    assert snapshot == before, 'Los registros o indicadores cambiaron después del reinicio.'
    evidence = {
        'status': 'passed', 'counts_before': before['counts'], 'counts_after': snapshot['counts'],
        'evaluation_id': case['evaluation_id'], 'reevaluation_id': case['reevaluation_id'],
        'path_id': case['path_id'], 'progress_version': snapshot['progress']['version'],
        'completion_percent': snapshot['progress']['completion_percent'],
        'score_delta': snapshot['reevaluation']['comparison']['score_delta'],
        'diagnosis_path_progress_comparison_and_dashboard_preserved': True,
    }
    (qa / 'reinicio-rf03-rf07.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Reinicio real verificado:', evidence)
